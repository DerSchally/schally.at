<?php
/***************************************************************************
 *                       wm_stats.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
//
// End session management
//

//
// Init arrays               Array contains:
//                           ---------------
$wm_config     = array();  // Config values
$wm_users_data = array();  // All userdata from users with at least 1 WM point
$arr_avatars = array();

$wm_config     = get_wm_config();
$wm_users_data = get_wm_users();
$team_data     = get_wm_teams();
$all_user_data = get_all_the_users();
$champion_tips = get_wm_champion_tipps();
$scorer_tips = get_wm_scorer_tipps();
$game_times = get_first_game();
$wmtipp_delay = $wm_config['wmtipp_delay'];
if ($wm_config['user_see_set'] == 0)
{
	$first_game[0] = $game_times[0][1] + $wmtipp_delay * 86400;
}
else
{
	$first_game[0] = $game_times + $wmtipp_delay * 86400;
}
include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

if ( !$userdata['session_logged_in'] )
{
   redirect(append_sid("login.$phpEx?redirect=wm_stats.$phpEx"));
}

//
// Set pagetitle, pageheader and templatefile
//
$page_title = $lang['wm_title_home'];

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'wm_stats_body.tpl')
);

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

// filter disallowed users
if (!empty($wm_config['disallow_users']))
{
	$arr_disallowusers = array();
	$arr_disallowusers = explode(",", $wm_config['disallow_users']);
	if (in_array($userdata['user_id'], $arr_disallowusers))
	{
		message_die(GENERAL_MESSAGE, 'You are not allowed here.', '', '', '', '');
	}
}

$int_userpkt = -1;
$int_userpos = 0;
$admin_sees_all = 0;
$user_see_all = 0;
If ($userdata['user_level'] == ADMIN && $wm_config['admin_sees_all'] == 1)
{
	$admin_sees_all = true;
}
If ($userdata['user_level'] != ADMIN && $wm_config['user_see_all'] == 1)
{
	$user_see_all = true;
}

If ($admin_sees_all == true || $user_see_all == true)
{
	$show_tipps = true;
}

$arr_oldranks = array();
$arr_oldranks = get_wm_user_points_up_to_yesterday();

for ( $i = 0; $i < count($wm_users_data); $i++ )
{
	$int_userposalt = $int_userpos; 
	$int_userpos = ($int_userpkt != $wm_users_data[$i]['user_points']) ? $i + 1 : $int_userpos; 
	// user position yesterday 
	if (empty($arr_oldranks[$wm_users_data[$i]['tipp_user']]))
	{
		$arr_oldranks[$wm_users_data[$i]['tipp_user']] = $int_userpos;
	}
	$int_userpos_yesterday = $arr_oldranks[$wm_users_data[$i]['tipp_user']];
	// compare the absolute positions 
	if($int_userpos_yesterday < $int_userpos )
	{ 
		$userpos_change = '<img src="./images/wm/down.gif" alt="verschlechtert" title="verschlechtert" border="0" />'; 
	} 
	else if ($int_userpos_yesterday == $int_userpos )
	{ 
		$userpos_change = '<img src="./images/wm/stay.gif" alt="unver�ndert" title="unver�ndert" border="0" />'; 
	} 
	else if ($int_userpos_yesterday > $int_userpos )
	{ 
		$userpos_change = '<img src="./images/wm/up.gif" alt="verbessert" title="verbessert" border="0" />'; 
	}
	$str_avatar = ''; 
	if ( $wm_users_data[$i]['user_avatar_type'] && $wm_users_data[$i]['user_allowavatar'] ) 
	{ 
		switch( $wm_users_data[$i]['user_avatar_type'] ) 
		{ 
			case USER_AVATAR_UPLOAD: 
			$str_avatar = ( $board_config['allow_avatar_upload'] ) ? $board_config['avatar_path'] . '/' . $wm_users_data[$i]['user_avatar'] : ''; 
			break; 
			case USER_AVATAR_REMOTE: 
			$str_avatar = ( $board_config['allow_avatar_remote'] ) ? $wm_users_data[$i]['user_avatar'] : ''; 
			break; 
			case USER_AVATAR_GALLERY: 
			$str_avatar = ( $board_config['allow_avatar_local'] ) ? $board_config['avatar_gallery_path'] . '/' . $wm_users_data[$i]['user_avatar'] : ''; 
			break; 
		} 
	} 
	//
	// Default Avatar MOD - Begin
	//
	if ( empty($poster_avatar) && $poster_id != ANONYMOUS)
	{
		$poster_avatar = '<img src="'.  $images['default_avatar'] .'" alt="" border="0" />';
	}
	if ( $poster_id == ANONYMOUS )
	{
		$poster_avatar = '<img src="'.  $images['guest_avatar'] .'" alt="" border="0" />';
	}
	//
	// Default Avatar MOD - End
	//
	$str_avatar = (!empty($str_avatar)) ? '<img src="' . $str_avatar . '" alt="' . $all_user_data[$wm_users_data[$i]['tipp_user']] . '" title="' . $all_user_data[$wm_users_data[$i]['tipp_user']] . '" width="40" height="40" />' : '&nbsp;';
	$arr_avatars[$wm_users_data[$i]['tipp_user']] = $str_avatar;
		if ($wm_config['user_see_set'] == 0)
		{
			$usertipps = ((time() < $first_game[0] + $wmtipp_delay * 86400 ) && ($wm_users_data[$i]['tipp_user'] != $userdata['user_id']) && !$show_tipps) ? $lang['Hidden_email'] : '<a href="'.append_sid('wm_usertipps.'.$phpEx.'?user_id='.$wm_users_data[$i]['tipp_user']).'" onclick="window.open(\''.append_sid('wm_usertipps.'.$phpEx.'?user_id='.$wm_users_data[$i]['tipp_user']).'\', \'_wm_usertipps\', \'height=700,resizable=yes,scrollbars=yes,width=900\');return false;" target="_wm_usertipps" class="nav"">'.$lang['wm_showtipps'].'</a>';
		}
		else
		{
			$usertipps  = '<a href="'.append_sid('wm_usertipps.'.$phpEx.'?user_id='.$wm_users_data[$i]['tipp_user']).'" onclick="window.open(\''.append_sid('wm_usertipps.'.$phpEx.'?user_id='.$wm_users_data[$i]['tipp_user']).'\', \'_wm_usertipps\', \'height=700,resizable=yes,scrollbars=yes,width=900\');return false;" target="_wm_usertipps" class="nav"">'.$lang['wm_showtipps'].'</a>';
		}

	// Group loop switches
	$template->assign_block_vars('userrow', array(
		'USERTIPPS'              => $usertipps,
		'USER_AVATAR'            => $str_avatar, 
		'USER_NAME'              => $all_user_data[$wm_users_data[$i]['tipp_user']],
		'USER_PROFILE_LINK'      => append_sid("profile.".$phpEx."?mode=viewprofile&u=".$wm_users_data[$i]['tipp_user']),
		'USER_POINTS'            => $wm_users_data[$i]['user_points'],
		'USER_POINTS_DIFFERENCE' => $wm_users_data[$i]['user_points_difference'],
		'USER_POINTS_RESULT'     => $wm_users_data[$i]['user_points_result'],
		'USER_POINTS_TENDENCY'   => $wm_users_data[$i]['user_points_tendency'],
		'USER_POS'               => $int_userpos,
		'USER_SCORER_TIPP'       => ( array_key_exists($wm_users_data[$i]['tipp_user'] , $scorer_tips) ) ? ((time() < $first_game[0]) && ($wm_users_data[$i]['tipp_user'] != $userdata['user_id']) && !$show_tipps) ? $lang['Hidden_email'] : '<span style="color:006699;">'.$scorer_tips[$wm_users_data[$i]['tipp_user']].'</span>' : '<span style="color:Red;">'.$lang['l_wm_winner_not_set'].'</span>',
		'USER_WM_MADE'           => $wm_users_data[$i]['user_total_tipps'] + (!empty($scorer_tips[$wm_users_data[$i]['tipp_user']])),
		'USER_WM_POS_CHANGE'     => $userpos_change,
		'USER_WM_TIPP'           => ( array_key_exists($wm_users_data[$i]['tipp_user'] , $champion_tips) ) ? ((time() < $first_game[0]) && ($wm_users_data[$i]['tipp_user'] != $userdata['user_id']) && !$show_tipps) ? $lang['Hidden_email'] : "<a href=\"" . $team_data[$champion_tips[$wm_users_data[$i]['tipp_user']]]['team_link'] . "\" target=\"_blank\">" . $team_data[$champion_tips[$wm_users_data[$i]['tipp_user']]]['team_name'] . "</a>" : '<span style="color:Red;">'.$lang['l_wm_winner_not_set'].'</span>'
		)
	);
	$int_userpkt = $wm_users_data[$i]['user_points'];
}
$template->assign_block_vars('round1', array());

// Check if tippforum is enabled
if ( $wm_config['wm_forum_id'] != 0 )
{
	$template->assign_block_vars('forum_enabled', array());
	if ( $wm_config['wm_forum_special_id'] != 0 )
	{
		$template->assign_block_vars('forum_enabled.special_enabled', array(
			'L_WM_FORUM_SPECIAL'     => $lang['l_wm_nav_forum_special'],
			'U_WM_FORUM_SPECIAL'     => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_special_id']),
			)
		);
	}
}

if ( $wm_config['wm_special'] == 1 )
{
	$template->assign_block_vars('special_enabled', array());
}

if ( $wm_config['stats_general'] == 1 )
{
	$template->assign_block_vars('stats_general', array());
}

// Assign vars
$template->assign_vars(array(
	'L_PICTURE_BALL'     => 'ball.gif',
	'L_PICTURE_CUP'      => 'cup.gif',
	'L_PICTURE_SHOE'     => 'shoe.gif',
	'L_WM_EXP'           => $lang['l_wm_stats_exp'],
	'L_WM_FINALS'        => $lang['l_wm_nav_finals'],
	'L_WM_FORUM'         => $lang['l_wm_nav_forum'],
	'L_WM_GOALDIFF'      => $lang['l_wm_goaldiff'],
	'L_WM_HITS'          => $lang['l_wm_hits'],
	'L_WM_MOD'           => $lang['l_wm_nav_mod'],
	'L_WM_MORESTATS'	 => $lang['l_wmms_title'],
	'L_WM_POINTSMATCH'   => $lang['l_wm_pointsmatch'], 
	'L_WM_POINTSTEND'    => $lang['l_wm_pointstend'], 
	'L_WM_POINTSTORDIFF'    => $lang['l_wm_pointstordiff'], 
	'L_WM_POINTSTREFFERALONE'    => $lang['l_wm_pointstrefferalone'], 
	'L_WM_POINTSWINNER'  => $lang['l_wm_pointswinner'], 
	'L_WM_POINTSWINNERSCORER'    => $lang['l_wm_pointswinnerscorer'], 
	'L_WM_POINTSYSTEM'   => $lang['l_wm_pointssystem'], 
	'L_WM_ROUND1'        => $lang['l_wm_nav_round1'],
	'L_WM_RULES'		 => $lang['wm_rules'],
	'L_WM_STATS_COMPLETE' => $lang['l_wm_nav_stats_complete'],
	'L_WM_STATS_MADE'    => $lang['l_wm_stats_made_tipps'],
	'L_WM_STATS_POINTS'  => $lang['l_wm_stats_points'],
	'L_WM_STATS_POS'     => $lang['l_wm_stats_pos'],
	'L_WM_STATS_SPECIAL' => $lang['l_wm_nav_stats_special'],
	'L_WM_STATS_USER'    => $lang['l_wm_stats_user'],
	'L_WM_STATS_WINNER'  => $lang['l_wm_stats_winnertipp'],
	'L_WM_TENDENCY'      => $lang['l_wm_tendency'],
	'L_WM_TITLE'         => $lang['l_wm_stats_title'],
	'L_WM_TJSTAT'   	 => 'Torj�ger-Tipps',
	'L_WM_WELCOME_TITLE' => $lang['l_wm_round1_welcome_title'],
	'L_WM_WINNERSTAT'	 => $lang['wm_st_winnertips'],
	'PKT_WM_POINTSMATCH' => $wm_config['points_match'], 
	'PKT_WM_POINTSTEND' => $wm_config['points_tendency'], 
	'PKT_WM_POINTSTORDIFF' => $wm_config['points_tordiff'], 
	'PKT_WM_POINTSTREFFERALONE'    => $wm_config['points_trefferalone'], 
	'PKT_WM_POINTSWINNER' => $wm_config['points_winner'], 
	'PKT_WM_POINTSWINNERSCORER'    => $wm_config['points_winnerscorer'], 
	'S_FORM_ACTION'          => append_sid("./wm_round1.".$phpEx),
	'U_WM_FINALS'        => append_sid("./wm_finals.".$phpEx),
	'U_WM_FORUM'         => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_id']),
	'U_WM_MOD'           => append_sid("./privmsg.".$phpEx."?mode=post&u=".$admin_id),
	'U_WM_MORESTATS'	 => append_sid("./wm_morestats.".$phpEx),
	'U_WM_ROUND1'        => append_sid("./wm_round1.".$phpEx),
	'U_WM_RULES'			=> append_sid("./wm_rules.".$phpEx),
	'U_WM_STATS'         => append_sid("./wm_stats.".$phpEx),
	'U_WM_STATS_SPECIAL'     => append_sid("./wm_stats_special.".$phpEx),
	'U_WM_TJSTAT'		 => append_sid("./wm_tjstat.".$phpEx),
	'U_WM_WINNERSTAT'	 => append_sid("./wm_winnerstat.".$phpEx),
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

if ($wm_config['stats_general'] == 1) 
{
	$template->assign_block_vars('switch_stats_general', array()); 
	if ($wm_config['stats_rainbowcup'] == 1) 
	{
		$template->assign_block_vars('switch_stats_general.switch_rainbowcup', array(
			'RB_TITLE' => $lang['wm_stats_rainbow'],
			'RB_EXP'   => $lang['wm_stats_rainbowcup_exp'],
			'RB_RANK'  => $lang['l_wm_stats_pos'],
			'RB_USER'  => $lang['l_wm_stats_user'],
			'RB_GOALSUM' => $lang['l_wm_stats_goalsum'],
			'RB_NUMBER'  => $lang['wm_st_number'],
			'RB_QUOTE'   => $lang['l_wmms_quote'],
			'RB_MAXDEV'  => $lang['l_wmms_maxdev']
			)
		); 
		// Regenbogentipper 
		$arr_rainbow = array(); 
		$sql_tipps = "SELECT tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game <> 65 AND tipp_points >= " . $wm_config['points_match'] . " GROUP BY tipp_user limit " . $wm_config['stats_ranksize']; 
		if (!($result_tipps = $db->sql_query($sql_tipps))) 
		{ 
			message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_tipps); 
		} 
		while ($row_tipps = $db->sql_fetchrow($result_tipps)) 
		{ 
			$sql_user = "SELECT *, (tipp_home + tipp_away) AS summe, ABS(tipp_home - tipp_away) as differenz FROM " . WM_TIPPS_TABLE . " 
				WHERE tipp_user = " . $row_tipps['tipp_user'] . " AND tipp_game <> 65 AND tipp_points >= " . $wm_config['points_match'] . " 
				ORDER BY summe DESC, differenz DESC LIMIT 3"; 
			if (!($result_user = $db->sql_query($sql_user))) 
			{ 
				message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_user); 
			} 
			while ($row_user = $db->sql_fetchrow($result_user)) 
			{ 
				$arr_rainbow[$row_user['tipp_user']]["torsumme"] += $row_user['summe']; 
				$arr_rainbow[$row_user['tipp_user']]["anzahl"]++; 
				$arr_rainbow[$row_user['tipp_user']]["quote"] = ($arr_rainbow[$row_user['tipp_user']]["torsumme"] / $arr_rainbow[$row_user['tipp_user']]["anzahl"]); 
				$arr_rainbow[$row_user['tipp_user']]["maxabw"] = max($arr_rainbow[$row_user['tipp_user']]["maxabw"], abs($row_user['tipp_home'] - $row_user['tipp_away'])) ; 
			} 
		} 
		arsort($arr_rainbow); 
		$int_rang = 0; 
		$int_quote = 0; 
		$int_quotealt = 0; 
		$pos_count = 0;
		$count = 1;
		foreach($arr_rainbow as $key => $value) 
		{
			$pos_count++;
			$int_quote = $value["quote"] + ($value["anzahl"] / 10) + ($value["maxabw"] / 100); 
			if ($int_quote == $int_quotealt) 
			{
				if ($count == 1)
				{
					$int_rang = $pos_count -1; 
					$count = 0;
				}
			}
			else
			{
				$count = 1;
			}
			$template->assign_block_vars('switch_stats_general.switch_rainbowcup.rainbowrow', array( 
				'RB_RANK'      => ($int_quote != $int_quotealt) ? $pos_count : $int_rang, 
				'RB_USERNAME'   => $all_user_data[$key], 
				'RB_AVATAR'   => $arr_avatars[$key],
				'RB_USERLINK'   => append_sid("profile.".$phpEx."?mode=viewprofile&u=".$key), 
				'RB_GOALSUM'   => $value["torsumme"], 
				'RB_NUMBER'   => $value["anzahl"], 
				'RB_QUOTE'   => number_format($value["quote"], 2, ",", "."), 
				'RB_MAXABW'   => $value["maxabw"] 
				) 
			); 
			$int_quotealt = $int_quote; 
		} 
	}

	if ($wm_config['stats_bestloser'] == 1) 
	{
		$template->assign_block_vars('switch_stats_general.switch_bestloser', array()); 
		// Best loser 
		$arr_bestloser = array(); 
		// Ergebnisse holen 
		$resultdata = array(); 
		$resultdata = get_wm_results();
		$ranksize = $wm_config['stats_ranksize'] + 2;
		// alle User mit "daneben"-Tipps holen 
		$sql_alluser = "SELECT tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game <> 65 AND tipp_points = 0 GROUP BY tipp_user limit " . $ranksize; 
		if (!($result_alluser = $db->sql_query($sql_alluser))) 
		{ 
			message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_alluser); 
		} 
		while ($row_alluser = $db->sql_fetchrow($result_alluser)) 
		{ 
			// alle "daneben"-Tipps eines Users holen 
			$sql_tipps = "SELECT * FROM " . WM_TIPPS_TABLE . " WHERE tipp_user = " . $row_alluser['tipp_user'] . " AND tipp_points = 0 AND tipp_game <> 65"; 
			if (!($result_tipps = $db->sql_query($sql_tipps)))
			{ 
				message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_tipps); 
			} 
			$int_count = 0; 
			while ($row_tipps = $db->sql_fetchrow($result_tipps)) 
			{ 
				// Ergebnis des Spiels holen und ausrechnen, "wie daneben" der Tipp ist 
				if (!empty($resultdata[$row_tipps['tipp_game']])) 
				{ 
					$int_daneben = (abs($row_tipps['tipp_home'] - $resultdata[$row_tipps['tipp_game']]['result_home']) + abs($row_tipps['tipp_away'] - $resultdata[$row_tipps['tipp_game']]['result_away'])); 
					if ($int_daneben < 4) 
					{ 
						$int_count++; 
						$arr_bestloser[$row_alluser['tipp_user']]["tore"] += $int_daneben; 
					} 
				} 
			} 
			$arr_bestloser[$row_alluser['tipp_user']]["daneben"] = $int_count; 
		} 
		$arr_bestlosersort = array(); 
		foreach($arr_bestloser as $key => $value) 
		{ 
			if ($value["daneben"] > 0) 
			{ 
				$arr_bestlosersort[$key]["daneben"] = (0 - $value["daneben"]); 
				$arr_bestlosersort[$key]["quote"] = ($value["tore"] / $value["daneben"]); 
				$arr_bestlosersort[$key]["tore"] = $value["tore"]; 
			} 
		} 
		asort($arr_bestlosersort); 
		$int_rang = 0; 
		$int_quote = 0; 
		$int_quotealt = 0; 
		foreach($arr_bestlosersort as $key => $value) 
		{ 
			$int_quote = $value["quote"]; 
			if ($int_quote != $int_quotealt) 
			{ 
				$int_rang++;
			} 
			$template->assign_block_vars('switch_stats_general.switch_bestloser.bestloserrow', array( 
				'BL_RANK'      => $int_rang, 
				'BL_USERNAME'   => $all_user_data[$key], 
				'BL_AVATAR'   => $arr_avatars[$key],
				'BL_USERLINK'   => append_sid("profile.".$phpEx."?mode=viewprofile&u=".$key), 
				'BL_DANEBEN'   => abs($value["daneben"]), 
				'BL_TORE'      => abs($value["tore"]), 
				'BL_QUOTE'   => number_format(round(abs($value["quote"]), 2), 2, ",", ".") 
				) 
			); 
			$int_rang = ($int_quote != $int_quotealt) ? $int_rang : $int_rang + 1;
			$int_quotealt = $int_quote; 
		} 
	} 
}

$template->pparse('body');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>