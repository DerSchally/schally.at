<?php
/***************************************************************************
 *                       admin_wm_config.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
	$filename = basename(__FILE__);
	$module['wm_acp_menu_webtipp']['wm_acp_menu_config'] = $filename;
	return;
}

define('CT_SECLEVEL', 'MEDIUM');
$ct_ignorepvar = array('spielername');

//
// Load default header
//
$phpbb_root_path = "../";
require($phpbb_root_path . 'extension.inc');
require('pagestart.' . $phpEx);
include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.' . $phpEx);
include($phpbb_root_path . 'includes/functions_wm.' . $phpEx);

$page_title =  $lang['wm_title_home'];

$koenigid = $_POST["koenigid"];
$isking = (empty($_POST["isking"])) ? array() : $_POST["isking"];
$tore = $_POST["tore"];
$koenig = $_POST["koenig"];
$spielerverein = $_POST["spielerteam"];
$kingteam = $_POST["koenigteam"];
$spielername = $_POST["spielername"];
$spielervorname = $_POST["spielervorname"];
$Link = $_POST["link"];
$spielerdelete = $_POST["delete"];

//
// Pull all config data
//
$sql = "SELECT * FROM " . WM_CONFIG_TABLE;
if(!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, "Could not query config information in wm configuration", "", __LINE__, __FILE__, $sql);
}
else
{
	while( $row = $db->sql_fetchrow($result) )
	{
		$config_name = $row['config_name'];
		$config_value = $row['config_value'];
		$default_config[$config_name] = isset($HTTP_POST_VARS['submit']) ? str_replace("'", "\'", $config_value) : $config_value;
		$new[$config_name] = ( isset($HTTP_POST_VARS[$config_name]) ) ? $HTTP_POST_VARS[$config_name] : $default_config[$config_name];
		if( isset($HTTP_POST_VARS['submit']) )
		{
			$sql = "UPDATE " . WM_CONFIG_TABLE . " SET config_value = '" . str_replace("\'", "''", $new[$config_name]) . "' WHERE config_name = '$config_name'";
			if( !$db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Failed to update configuration for $config_name", "", __LINE__, __FILE__, $sql);
			}
		}
	}

	if( isset($HTTP_POST_VARS['addplayer']) )
	{
		$sql = "INSERT INTO " . WM_TJAEGER_TABLE . " (Name, Vorname, link, tore, verein ) VALUES('$spielername', '$spielervorname', '$Link', '$tore', '$kingteam')";
				if( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
				}
	}
	
	if( isset($HTTP_POST_VARS['submit']) )
	{
		$message = $lang['wm_acp_config_updated'] . "<br /><br />" . sprintf($lang['Click_return_config'], "<a href=\"" . append_sid("admin_wm_config.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		message_die(GENERAL_MESSAGE, $message);
	}
	elseif( isset($HTTP_POST_VARS['submitgoals']) || isset($HTTP_POST_VARS['submitgoalswithout']) )
	{
		for ($i = 0; $i < count($koenigid); $i++)
		{
			$sql = "UPDATE " . WM_TJAEGER_TABLE . "
						SET
							tore = '" . $tore[$i] ."',
							Name = '" . $spielername[$i] ."',
							Vorname = '" . $spielervorname[$i] ."',
							Verein = '" . $spielerverein[$i] ."',
							Link = '" . $Link[$i] ."',
							isking = '" . in_array($koenigid[$i], $isking) ."'
						WHERE spielerid = '" . $koenigid[$i]. "'";
				if( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
				}
		}
		for ($m = 0; $m < count($spielerdelete); $m++)
		{
			$sql = "DELETE FROM " . WM_TJAEGER_TABLE . " WHERE spielerid = '$spielerdelete[$m]' ";
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
			}
			$sql = "DELETE FROM " . WM_TJAEGERTIPPS_TABLE . " WHERE spielerid = '$spielerdelete[$m]' ";
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
			}
		}
		$message = $lang['wm_acp_config_updated'] . "<br /><br />" . sprintf($lang['Click_return_config'], "<a href=\"" . append_sid("admin_wm_config.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		message_die(GENERAL_MESSAGE, $message);
	}
}

$template->set_filenames(array(
	'body' => 'admin/admin_wm_config_body.tpl')
);

//
// Get all group data
//
$combo_groups_entries = '';
$sql = "SELECT * FROM " . GROUPS_TABLE . " WHERE group_single_user = 0";
if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, 'Could not query groups data', '', __LINE__, __FILE__, $sql);
}
while ($row = $db->sql_fetchrow($result))
{
	$selected = ( $row['group_id'] == $new['restrict_to'] ) ? 'selected' : '';
	$combo_groups_entries .= '<option value="' . $row['group_id'] . '" ' . $selected . '>' . $row['group_name'] . '</option>';
}
$db->sql_freeresult($result);

//
// Generate groups combobox
//
$selected = ( $new['restrict_to'] == 0 ) ? 'selected' : '';
$group_combo  = '<select name="restrict_to">';
$group_combo .= '<option value="0" ' . $selected . '>' . $lang['wm_acp_deactivated'] . '</option>';
$group_combo .= $combo_groups_entries;
$group_combo .= '</select>';

//
// Get all forum data
//
$combo_forums_entries = '';
$sql = "SELECT * FROM " . FORUMS_TABLE . " ORDER BY forum_order ASC";
if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, 'Could not query forums data', '', __LINE__, __FILE__, $sql);
}
while ($row = $db->sql_fetchrow($result))
{
	$selected = ( $row['forum_id'] == $new['wm_forum_id'] ) ? 'selected' : '';
	$selected2 = ( $row['forum_id'] == $new['wm_forum_special_id'] ) ? 'selected' : '';
	$combo_forums_entries .= '<option value="' . $row['forum_id'] . '" ' . $selected . '>' . $row['forum_name'] . '</option>';
	$combo_forums_special_entries .= '<option value="' . $row['forum_id'] . '" ' . $selected2 . '>' . $row['forum_name'] . '</option>';
}
$db->sql_freeresult($result);

//
// Generate forums combobox
//
$selected = ( $new['forum_id'] == 0 ) ? 'selected' : '';
$forums_combo  = '<select name="wm_forum_id">';
$forums_combo .= '<option value="0" ' . $selected . '>' . $lang['wm_acp_deactivated'] . '</option>';
$forums_combo .= $combo_forums_entries;
$forums_combo .= '</select>';

//
// Generate forums special combobox
//
$selected = ( $new['forum_id'] == 0 ) ? 'selected' : '';
$forums_special_combo  = '<select name="wm_forum_special_id">';
$forums_special_combo .= '<option value="0" ' . $selected . '>' . $lang['wm_acp_deactivated'] . '</option>';
$forums_special_combo .= $combo_forums_special_entries;
$forums_special_combo .= '</select>';


//
// Get possible mods data
//
$combo_mod_entries = '';
$sql = "SELECT * FROM " . USERS_TABLE . " ORDER BY username ASC";
if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, 'Could not query user data', '', __LINE__, __FILE__, $sql);
}
while ($row = $db->sql_fetchrow($result))
{
	$selected = ( $row['user_id'] == $new['wm_mod_id'] ) ? 'selected' : '';
	$combo_mod_entries .= '<option value="' . $row['user_id'] . '" ' . $selected . '>' . $row['username'] . '</option>';
}
$db->sql_freeresult($result);

//
// Generate possible mods combobox
//
$mods_combo  = '<select name="wm_mod_id">';
$mods_combo .= '<option value="0" ' . $selected . '>' . $lang['wm_acp_deactivated'] . '</option>';
$mods_combo .= $combo_mod_entries;
$mods_combo .= '</select>';

$teams_data = array();
$teams_data = get_wm_teams_as_row();

$combo_wa = build_group_winner_combo('wa', $new['wa'], $teams_data, "A");
$combo_ra = build_group_winner_combo('ra', $new['ra'], $teams_data, "A");
$combo_wb = build_group_winner_combo('wb', $new['wb'], $teams_data, "B");
$combo_rb = build_group_winner_combo('rb', $new['rb'], $teams_data, "B");
$combo_wc = build_group_winner_combo('wc', $new['wc'], $teams_data, "C");
$combo_rc = build_group_winner_combo('rc', $new['rc'], $teams_data, "C");
$combo_wd = build_group_winner_combo('wd', $new['wd'], $teams_data, "D");
$combo_rd = build_group_winner_combo('rd', $new['rd'], $teams_data, "D");
$combo_we = build_group_winner_combo('we', $new['we'], $teams_data, "E");
$combo_re = build_group_winner_combo('re', $new['re'], $teams_data, "E");
$combo_wf = build_group_winner_combo('wf', $new['wf'], $teams_data, "F");
$combo_rf = build_group_winner_combo('rf', $new['rf'], $teams_data, "F");
$combo_wg = build_group_winner_combo('wg', $new['wg'], $teams_data, "G");
$combo_rg = build_group_winner_combo('rg', $new['rg'], $teams_data, "G");
$combo_wh = build_group_winner_combo('wh', $new['wh'], $teams_data, "H");
$combo_rh = build_group_winner_combo('rh', $new['rh'], $teams_data, "H");

//
// Generate points gfx active ComboBox
//
$pts_gfx_combo_entries  = '';
$selected1 = ( $new['points_grafical'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['points_grafical'] == '0' ) ? ' selected' : '';
$pts_gfx_combo_entries .= '<option value="1" ' . $selected1 . '>' . $lang['l_wm_grafical'] . '</option>';
$pts_gfx_combo_entries .= '<option value="0" ' . $selected0 . '>' . $lang['l_wm_textual'] . '</option>';
$pts_gfx_combo  = '<select name="points_grafical">';
$pts_gfx_combo .= $pts_gfx_combo_entries;
$pts_gfx_combo .= '</select>';

$Adminseetipps  = '';
$selected1 = ( $new['admin_sees_all'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['admin_sees_all'] == '0' ) ? ' selected' : '';
$Adminseetipps .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$Adminseetipps .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$adminseetipps_combo  = '<select name="admin_sees_all">';
$adminseetipps_combo .= $Adminseetipps;
$adminseetipps_combo .= '</select>';

$userseetipps  = '';
$selected1 = ( $new['user_see_all'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['user_see_all'] == '0' ) ? ' selected' : '';
$userseetipps .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$userseetipps .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$userseetipps_combo  = '<select name="user_see_all">';
$userseetipps_combo .= $userseetipps;
$userseetipps_combo .= '</select>';

$specialactive  = '';
$selected1 = ( $new['wm_special'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['wm_special'] == '0' ) ? ' selected' : '';
$specialactive .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$specialactive .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$special_combo  = '<select name="wm_special">';
$special_combo .= $specialactive;
$special_combo .= '</select>';

$usertrefferalone  = '';
$selected1 = ( $new['user_trefferalone'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['user_trefferalone'] == '0' ) ? ' selected' : '';
$usertrefferalone .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$usertrefferalone .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$usertrefferalone_combo  = '<select name="user_trefferalone">';
$usertrefferalone_combo .= $usertrefferalone;
$usertrefferalone_combo .= '</select>';

$statistik  = '';
$selected1 = ( $new['stats_general'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_general'] == '0' ) ? ' selected' : '';
$statistik .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$statistik .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$statistik_combo  = '<select name="stats_general">';
$statistik_combo .= $statistik;
$statistik_combo .= '</select>';

$rainbowcup  = '';
$selected1 = ( $new['stats_rainbowcup'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_rainbowcup'] == '0' ) ? ' selected' : '';
$rainbowcup .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$rainbowcup .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_rainbowcup_combo  = '<select name="stats_rainbowcup">';
$stats_rainbowcup_combo .= $rainbowcup;
$stats_rainbowcup_combo .= '</select>';

$bestloser  = '';
$selected1 = ( $new['stats_bestloser'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_bestloser'] == '0' ) ? ' selected' : '';
$bestloser .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$bestloser .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_bestloser_combo  = '<select name="stats_bestloser">';
$stats_bestloser_combo .= $bestloser;
$stats_bestloser_combo .= '</select>';

$most_goals  = '';
$selected1 = ( $new['stats_most_goals'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_goals'] == '0' ) ? ' selected' : '';
$most_goals .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_goals .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_goals_combo  = '<select name="stats_most_goals">';
$stats_most_goals_combo .= $most_goals;
$stats_most_goals_combo .= '</select>';

$most_correct_goals  = '';
$selected1 = ( $new['stats_most_correct_goals'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_correct_goals'] == '0' ) ? ' selected' : '';
$most_correct_goals .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_correct_goals .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_correct_goals_combo  = '<select name="stats_most_correct_goals">';
$stats_most_correct_goals_combo .= $most_correct_goals;
$stats_most_correct_goals_combo .= '</select>';

$most_wrong_tips  = '';
$selected1 = ( $new['stats_most_wrong_tips'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_wrong_tips'] == '0' ) ? ' selected' : '';
$most_wrong_tips .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_wrong_tips .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_wrong_tips_combo  = '<select name="stats_most_wrong_tips">';
$stats_most_wrong_tips_combo .= $most_wrong_tips;
$stats_most_wrong_tips_combo .= '</select>';

$most_worst_tips  = '';
$selected1 = ( $new['stats_most_worst_tips'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_worst_tips'] == '0' ) ? ' selected' : '';
$most_worst_tips .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_worst_tips .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_worst_tips_combo  = '<select name="stats_most_worst_tips">';
$stats_most_worst_tips_combo .= $most_worst_tips;
$stats_most_worst_tips_combo .= '</select>';

$most_tips_voted  = '';
$selected1 = ( $new['stats_most_tips_voted'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_tips_voted'] == '0' ) ? ' selected' : '';
$most_tips_voted .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_tips_voted .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_tips_voted_combo  = '<select name="stats_most_tips_voted">';
$stats_most_tips_voted_combo .= $most_tips_voted;
$stats_most_tips_voted_combo .= '</select>';

$most_tips_voted2  = '';
$selected1 = ( $new['stats_most_tips_voted2'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_tips_voted2'] == '0' ) ? ' selected' : '';
$most_tips_voted2 .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_tips_voted2 .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_tips_voted2_combo  = '<select name="stats_most_tips_voted2">';
$stats_most_tips_voted2_combo .= $most_tips_voted2;
$stats_most_tips_voted2_combo .= '</select>';

$most_tips_voted_user  = '';
$selected1 = ( $new['stats_most_tips_voted_user'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_tips_voted_user'] == '0' ) ? ' selected' : '';
$most_tips_voted_user .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_tips_voted_user .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_tips_voted_user_combo  = '<select name="stats_most_tips_voted_user">';
$stats_most_tips_voted_user_combo .= $most_tips_voted_user;
$stats_most_tips_voted_user_combo .= '</select>';

$most_results  = '';
$selected1 = ( $new['stats_most_results'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_results'] == '0' ) ? ' selected' : '';
$most_results .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_results .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_results_combo  = '<select name="stats_most_results">';
$stats_most_results_combo .= $most_results;
$stats_most_results_combo .= '</select>';

$most_results2  = '';
$selected1 = ( $new['stats_most_results2'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_most_results2'] == '0' ) ? ' selected' : '';
$most_results2 .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$most_results2 .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_most_results2_combo  = '<select name="stats_most_results2">';
$stats_most_results2_combo .= $most_results2;
$stats_most_results2_combo .= '</select>';

$points_tipp  = '';
$selected1 = ( $new['stats_points_tipp'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_points_tipp'] == '0' ) ? ' selected' : '';
$points_tipp .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$points_tipp .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_points_tipp_combo  = '<select name="stats_points_tipp">';
$stats_points_tipp_combo .= $points_tipp;
$stats_points_tipp_combo .= '</select>';

$points_nowrong_tipp  = '';
$selected1 = ( $new['stats_points_nowrong_tipp'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['stats_points_nowrong_tipp'] == '0' ) ? ' selected' : '';
$points_nowrong_tipp .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$points_nowrong_tipp .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$stats_points_nowrong_tipp_combo  = '<select name="stats_points_nowrong_tipp">';
$stats_points_nowrong_tipp_combo .= $points_nowrong_tipp;
$stats_points_nowrong_tipp_combo .= '</select>';

$tjlist_show  = '';
$selected1 = ( $new['tjlist_show'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['tjlist_show'] == '0' ) ? ' selected' : '';
$tjlist_show .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$tjlist_show .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$tjlist_show_combo  = '<select name="tjlist_show">';
$tjlist_show_combo .= $tjlist_show;
$tjlist_show_combo .= '</select>';

$delete_tipps  = '';
$selected1 = ( $new['delete_tipps'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['delete_tipps'] == '0' ) ? ' selected' : '';
$delete_tipps .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$delete_tipps .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$delete_tipps_combo  = '<select name="delete_tipps">';
$delete_tipps_combo .= $delete_tipps;
$delete_tipps_combo .= '</select>';

$show_allteams  = '';
$selected1 = ( $new['show_allteams'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['show_allteams'] == '0' ) ? ' selected' : '';
$show_allteams .= '<option value="1" ' . $selected1 . '>' . 'Alle Teams' . '</option>';
$show_allteams .= '<option value="0" ' . $selected0 . '>' . 'Nur Teams mit Tipps' . '</option>';
$show_allteams_combo  = '<select name="show_allteams">';
$show_allteams_combo .= $show_allteams;
$show_allteams_combo .= '</select>';

$notify_post_rankmsg  = '';
$selected1 = ( $new['notify_post_rankmsg'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['notify_post_rankmsg'] == '0' ) ? ' selected' : '';
$notify_post_rankmsg .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$notify_post_rankmsg .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$notify_post_rankmsg_combo  = '<select name="notify_post_rankmsg">';
$notify_post_rankmsg_combo .= $notify_post_rankmsg;
$notify_post_rankmsg_combo .= '</select>';

$notify_write_mails  = '';
$selected1 = ( $new['notify_write_mails'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['notify_write_mails'] == '0' ) ? ' selected' : '';
$notify_write_mails .= '<option value="1" ' . $selected1 . '>' . 'ja' . '</option>';
$notify_write_mails .= '<option value="0" ' . $selected0 . '>' . 'nein' . '</option>';
$notify_write_mails_combo  = '<select name="notify_write_mails">';
$notify_write_mails_combo .= $notify_write_mails;
$notify_write_mails_combo .= '</select>';

$finals_result  = '';
$selected1 = ( $new['finals_result'] == '1' ) ? ' selected' : '';
$selected0 = ( $new['finals_result'] == '0' ) ? ' selected' : '';
$finals_result .= '<option value="1" ' . $selected1 . '>' . 'Endergebnis' . '</option>';
$finals_result .= '<option value="0" ' . $selected0 . '>' . 'Ergebnis nach 90min' . '</option>';
$finals_result_combo  = '<select name="finals_result">';
$finals_result_combo .= $finals_result;
$finals_result_combo .= '</select>';

$sql = "SELECT team_name FROM " . WM_TEAMS_TABLE . " order by team_name";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$verein[] = $row['team_name'];
	$select[] = '';
}

// get players with tipps
$str_playerids = "";
$sql = "SELECT DISTINCT spielerid FROM " . WM_TJAEGERTIPPS_TABLE;
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$str_playerids .= (empty($str_playerids)) ? $row['spielerid'] : ",".$row['spielerid'];
}
if ($str_playerids == ""){$str_playerids = 0;}
$sql = "SELECT * FROM " . WM_TJAEGER_TABLE . " WHERE spielerid IN ( " . $str_playerids . " ) ORDER BY tore DESC ";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$koenig[] = $row['spielerid'];
	$team[] = $row['verein'];
	$KOENIGVEREIN = '<select name="spielerteam[]">';
	for($e = 0; $e < count($verein);$e++)
	{
		if ($row['verein'] == $verein[$e]) {$select[$e] = 'selected';} else {$select[$e] = '';}
		$KOENIGVEREIN .= '<option value="' . $verein[$e]. '" '.$select[$e].'>' . $verein[$e]. '</option>';
	}
	$KOENIGVEREIN .=  '</select>';
	unset($username);
	$sql2 = "SELECT username FROM " . WM_TJAEGERTIPPS_TABLE . " t LEFT JOIN ". USERS_TABLE ." u ON u.user_id = t.userid WHERE spielerid = '". $row['spielerid'] . "' ORDER BY username";
	if( !$result2 = $db->sql_query($sql2) )
		message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql2);
	while($row2 = $db->sql_fetchrow($result2))
	{
		$username[] = $row2['username'];
	}
	if (count($username)<1) {$usernametext='Keine Tipps auf diesen Spieler'; $username[] ='';} else {$usernametext = 'Tipps von ';}
	$rowcount++;
	$row_countercheck = $rowcount % 2;
	if ($row_countercheck == '0')
	{
		$coloruser = 'row2';
	}
	else
	{
		$coloruser = 'row3';
	}
	$template->assign_block_vars('koenig_block', array(
		'S_KOENIGID'	=> $row['spielerid'],
		'S_ISKING'		=> ($row['isking'] == 1) ? 'checked="checked"' : '',
		'KOENIGNAME'	=> '<input type="text" value="'.$row['Name'].'" name="spielername[]" size="20">',
		'KOENIGVORNAME'	=> '<input type="text" value="'.$row['Vorname'].'" name="spielervorname[]" size="20">',
		'KOENIGVEREIN'	=> $KOENIGVEREIN,
		'LINK'			=> '<input type="text" value="'.$row['link'].'" name="link[]" size="80">',
		'S_KOENIGTORE'	=> $row['tore'],
		'S_USERNAMES'	=> $usernametext . implode(",", $username),
		'COLOR'			=> $coloruser
		)
	);
}

# Spieler ohne Tipp
$rowcount = 0;
$sql = "SELECT * FROM " . WM_TJAEGER_TABLE . " WHERE spielerid NOT IN ( " . $str_playerids . " ) ORDER BY tore DESC ";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$koenig[] = $row['spielerid'];
	$team[] = $row['verein'];
	$KOENIGVEREIN = '<select name="spielerteam[]">';
	for($e = 0; $e < count($verein);$e++)
	{
		if ($row['verein'] == $verein[$e])
		{
			$select[$e] = 'selected';
		}
		else
		{
			$select[$e] = '';
		}
		$KOENIGVEREIN .= '<option value="' . $verein[$e]. '" '.$select[$e].'>' . $verein[$e]. '</option>';
	}
	$KOENIGVEREIN .=  '</select>';
	$rowcount++;
	$row_countercheck = $rowcount % 2;
	if ($row_countercheck == '0')
	{
		$coloruser = 'row2';
	}
	else
	{
		$coloruser = 'row3';
	}
	$template->assign_block_vars('koenignotip_block', array(
		'S_KOENIGID'	=> $row['spielerid'],
		'S_ISKING'		=> ($row['isking'] == 1) ? 'checked="checked"' : '',
		'KOENIGNAME'	=> '<input type="text" value="'.$row['Name'].'" name="spielername[]" size="20">',
		'KOENIGVORNAME'	=> '<input type="text" value="'.$row['Vorname'].'" name="spielervorname[]" size="20">',
		'KOENIGVEREIN'	=> $KOENIGVEREIN,
		'LINK'			=> '<input type="text" value="'.$row['link'].'" name="link[]" size="80">',
		'S_KOENIGTORE'	=> $row['tore'],
		'COLOR'			=> $coloruser
		)
	);
}

$wm_teams = array();
$wm_teams = get_wm_teams_as_row();
$team_combo  = '<select name="koenigteam">';
$team_combo .= '<option value="0">' . $lang['tipp_admin_select'] . '</option>';
$team_combo .= '<option value="0">--------------</option>';
for ( $r = 0; $r < count($wm_teams); $r++ )
{
	$team_combo .= '<option value="' . $wm_teams[$r]['team_name'] . '" ' . $wm_teams[$r]['team_name'] . '>' . $wm_teams[$r]['team_name'] . '</option>';
}
$team_combo .= '</select>';
$addplayerteam = $team_combo;

$template->assign_vars(array(
	'ADMIN_WM_CONFIG_GROUP'						=> $group_combo,
	'ADMIN_WM_CONFIG_FORUM'						=> $forums_combo,
	'ADMIN_WM_CONFIG_FORUM_SPECIAL'				=> $forums_special_combo,
	'ADMIN_WM_CONFIG_MOD'						=> $mods_combo,
	'ADMIN_WM_CONFIG_PTS_GFX'					=> $pts_gfx_combo,
	'ADMIN_WM_SEE_TIPPS'						=> $adminseetipps_combo,
	'ADMIN_WM_SPECIAL'							=> $special_combo,
	'ADMIN_WM_USE_TREFFERALONE'					=> $usertrefferalone_combo,
	'ADMIN_WM_CONFIG_POINTSWINNER'				=> $new['points_winner'],
	'ADMIN_WM_CONFIG_POINTSWINNERSCORE'			=> $new['points_winnerscorer'],
	'ADMIN_WM_CONFIG_POINTSTEND'				=> $new['points_tendency'],
	'ADMIN_WM_CONFIG_POINTSMATCH'				=> $new['points_match'],
	'ADMIN_WM_CONFIG_POINTSTORDIFF'				=> $new['points_tordiff'],
	'ADMIN_WM_CONFIG_TREFFERALONE'				=> $new['points_trefferalone'],
	'ADMIN_WM_CONFIG_TEAMWA'					=> $combo_wa,
	'ADMIN_WM_CONFIG_TEAMRA'					=> $combo_ra,
	'ADMIN_WM_CONFIG_TEAMWB'					=> $combo_wb,
	'ADMIN_WM_CONFIG_TEAMRB'					=> $combo_rb,
	'ADMIN_WM_CONFIG_TEAMWC'					=> $combo_wc,
	'ADMIN_WM_CONFIG_TEAMRC'					=> $combo_rc,
	'ADMIN_WM_CONFIG_TEAMWD'					=> $combo_wd,
	'ADMIN_WM_CONFIG_TEAMRD'					=> $combo_rd,
	'ADMIN_WM_CONFIG_TEAMWE'					=> $combo_we,
	'ADMIN_WM_CONFIG_TEAMRE'					=> $combo_re,
	'ADMIN_WM_CONFIG_TEAMWF'					=> $combo_wf,
	'ADMIN_WM_CONFIG_TEAMRF'					=> $combo_rf,
	'ADMIN_WM_CONFIG_TEAMWG'					=> $combo_wg,
	'ADMIN_WM_CONFIG_TEAMRG'					=> $combo_rg,
	'ADMIN_WM_CONFIG_TEAMWH'					=> $combo_wh,
	'ADMIN_WM_CONFIG_TEAMRH'					=> $combo_rh,
	'ADMIN_WM_END_TIPPTIME'						=> $new['end_tipptime'],
	'ADMIN_WM_TIPP_DELAY'						=> $new['wmtipp_delay'],
	'KOENIG'									=> $koenig['0'],
	'L_ADMIN_WM_CONFIG_ADMIN'					=> $lang['wm_acp_config_admin'],
	'L_ADMIN_WM_CONFIG_ADMIN_EXP'				=> $lang['wm_acp_config_admin_exp'],
	'L_ADMIN_WM_CONFIG_USER'					=> $lang['wm_acp_config_user'],
	'L_ADMIN_WM_CONFIG_USER_EXP'				=> $lang['wm_acp_config_user_exp'],
	'L_ADMIN_WM_CONFIG_USERSET'					=> $lang['wm_acp_config_userset'],
	'L_ADMIN_WM_CONFIG_USERSET_EXP'				=> $lang['wm_acp_config_userset_exp'],
	'L_ADMIN_WM_CONFIG_SPECIAL'					=> $lang['wm_acp_config_special'],
	'L_ADMIN_WM_CONFIG_SPECIAL_EXP'				=> $lang['wm_acp_config_special_exp'],
	'L_ADMIN_WM_CONFIG_TITLE'					=> $lang['wm_acp_config_title'],
	'L_ADMIN_WM_CONFIG_TITLE_EXP'				=> $lang['wm_acp_config_title_exp'],
	'L_ADMIN_WM_CONFIG_BUTTON'					=> $lang['wm_acp_config_button'],
	'L_ADMIN_WM_CONFIG_GENERAL'					=> $lang['wm_acp_config_general'],
	'L_ADMIN_WM_CONFIG_GROUPWINNER'				=> $lang['wm_acp_config_groupwinner'],
	'L_ADMIN_WM_CONFIG_GROUP'					=> $lang['wm_acp_config_group'],
	'L_ADMIN_WM_CONFIG_GROUP_EXP'				=> $lang['wm_acp_config_group_exp'],
	'L_ADMIN_WM_CONFIG_FORUM'					=> $lang['wm_acp_config_forum'],
	'L_ADMIN_WM_CONFIG_FORUM_EXP'				=> $lang['wm_acp_config_forum_exp'],
	'L_ADMIN_WM_CONFIG_FORUM_SPECIAL'			=> $lang['wm_acp_config_forum_special'],
	'L_ADMIN_WM_CONFIG_FORUM_EXP_SPECIAL'		=> $lang['wm_acp_config_forum_exp_special'],
	'L_ADMIN_WM_CONFIG_MOD'						=> $lang['wm_acp_config_mod'],
	'L_ADMIN_WM_CONFIG_MOD_EXP'					=> $lang['wm_acp_config_mod_exp'],
	'L_ADMIN_WM_CONFIG_PTS_GFX'					=> $lang['wm_acp_config_pts_gfx'],
	'L_ADMIN_WM_CONFIG_PTS_GFX_EXP'				=> $lang['wm_acp_config_pts_gfx_exp'],
	'L_ADMIN_WM_CONFIG_POINTSWINNER'			=> $lang['wm_acp_config_pointswinner'],
	'L_ADMIN_WM_CONFIG_POINTSWINNER_EXP'		=> $lang['wm_acp_config_pointswinner_exp'],
	'L_ADMIN_WM_CONFIG_POINTSWINNERSCORER'		=> $lang['wm_acp_config_pointswinnerscorer'],
	'L_ADMIN_WM_CONFIG_POINTSWINNERSCORE_EXP'	=> $lang['wm_acp_config_pointswinnerscorer_exp'],
	'L_ADMIN_WM_CONFIG_USERTREFFERALONE'		=> $lang['wm_acp_config_usertrefferalone'],
	'L_ADMIN_WM_CONFIG_USERTREFFERALONE_EXP'	=> $lang['wm_acp_config_usertrefferalone'],
	'L_ADMIN_WM_CONFIG_POINTSTREFFERALONE'		=> $lang['wm_acp_config_pointstrefferalone'],
	'L_ADMIN_WM_CONFIG_POINTSTREFFERALONE_EXP'	=> $lang['wm_acp_config_pointstrefferalone_exp'],
	'L_ADMIN_WM_CONFIG_POINTSMATCH'				=> $lang['wm_acp_config_pointsmatch'],
	'L_ADMIN_WM_CONFIG_POINTSMATCH_EXP'			=> $lang['wm_acp_config_pointsmatch_exp'],
	'L_ADMIN_WM_CONFIG_POINTSTORDIFF'			=> $lang['wm_acp_config_pointstordiff'],
	'L_ADMIN_WM_CONFIG_POINTSTORDIFF_EXP'		=> $lang['wm_acp_config_pointstordiff_exp'],
	'L_ADMIN_WM_CONFIG_POINTSTEND'				=> $lang['wm_acp_config_pointstend'],
	'L_ADMIN_WM_CONFIG_POINTSTEND_EXP'			=> $lang['wm_acp_config_pointstend_exp'],
	'L_ADMIN_WM_CONFIG_TEAMS'					=> $lang['wm_acp_config_teams'],
	'L_ADMIN_WM_CONFIG_TEAMS_EXP'				=> $lang['wm_acp_config_teams_exp'],
	'L_ADMIN_WM_CONFIG_WA' 						=> $lang['wm_acp_config_wa'],
	'L_ADMIN_WM_CONFIG_RA' 						=> $lang['wm_acp_config_ra'],
	'L_ADMIN_WM_CONFIG_WB' 						=> $lang['wm_acp_config_wb'],
	'L_ADMIN_WM_CONFIG_RB' 						=> $lang['wm_acp_config_rb'],
	'L_ADMIN_WM_CONFIG_WC' 						=> $lang['wm_acp_config_wc'],
	'L_ADMIN_WM_CONFIG_RC' 						=> $lang['wm_acp_config_rc'],
	'L_ADMIN_WM_CONFIG_WD' 						=> $lang['wm_acp_config_wd'],
	'L_ADMIN_WM_CONFIG_RD' 						=> $lang['wm_acp_config_rd'],
	'L_ADMIN_WM_CONFIG_WE' 						=> $lang['wm_acp_config_we'],
	'L_ADMIN_WM_CONFIG_RE' 						=> $lang['wm_acp_config_re'],
	'L_ADMIN_WM_CONFIG_WF' 						=> $lang['wm_acp_config_wf'],
	'L_ADMIN_WM_CONFIG_RF' 						=> $lang['wm_acp_config_rf'],
	'L_ADMIN_WM_CONFIG_WG' 						=> $lang['wm_acp_config_wg'],
	'L_ADMIN_WM_CONFIG_RG' 						=> $lang['wm_acp_config_rg'],
	'L_ADMIN_WM_CONFIG_WH' 						=> $lang['wm_acp_config_wh'],
	'L_ADMIN_WM_CONFIG_RH' 						=> $lang['wm_acp_config_rh'],
	'L_ADMIN_WM_END_TIPPTIME'					=> $lang['wm_acp_end_tipptime'],
	'L_ADMIN_WM_END_TIPPTIME_EXP'				=> $lang['wm_acp_end_tipptime_exp'],
	'L_ADMIN_WM_TIPP_DELAY'						=> $lang['wm_acp_wmtipp_delay'],
	'L_ADMIN_WM_TIPP_DELAY_EXP'					=> $lang['wm_acp_wmtipp_delay_exp'],
	'L_KOENIGLISTE'								=> $lang['tipp_admin_koenigliste'],
	'L_TORESAVE'								=> $lang['tipp_admin_toresave'],
	'L_FINALIZE'								=> $lang['tipp_admin_finalize'],
	'L_DELETE'									=> $lang['tipp_admin_delete'],
	'L_KING'									=> $lang['tipp_admin_king'],
	'L_KING_EXP'								=> $lang['tipp_admin_king_exp'],
	'L_NOTIPKING' 								=> $lang['tipp_admin_notipkoenig'],
	'L_ADDKING' 								=> $lang['tipp_admin_addkoenig'],
	'L_CONFIRM'									=> $lang['tipp_admin_changeconfirm'],
	'L_NAME'									=> $lang['wm_acp_config_name'],
	'L_VORNAME'									=> $lang['wm_acp_config_vorname'],
	'L_IMAGE' 									=> $lang['wm_acp_config_image'],
	'L_GOALS' 									=> $lang['l_wmms_tore'],
	'L_COUNTRY'								 	=> $lang['wm_acp_config_country'],
	'U_FORM_ACTION'								=> append_sid("admin_wm_config.$phpEx"),
	'USER_SEE_TIPPS'							=> $userseetipps_combo,
	'USER_SEE_TIPPSSET'							=> $new['user_see_set'],
	'L_STATISTIK_GENERAL'						=> $lang['wm_stats_general'],
	'L_STATS_AKTIV'								=> $lang['wm_stats_general_activ'],
	'L_STATS_AKTIV_EXP'							=> $lang['wm_stats_general_activ_exp'],
	'S_STATISTIK'								=> $statistik_combo,
	'L_STATS_RAINBOWCUP'						=> $lang['wm_stats_rainbowcup'],
	'L_STATS_RAINBOWCUP_EXP'					=> $lang['wm_stats_rainbowcup_exp'],
	'S_STATS_RAINBOWCUP'						=> $stats_rainbowcup_combo,
	'L_STATS_BESTLOSER'							=> $lang['wm_stats_bestloser'],
	'L_STATS_BESTLOSER_EXP'						=> $lang['wm_stats_bestloser_exp'],
	'S_STATS_BESTLOSER'							=> $stats_bestloser_combo,
	'L_STATS_MOST_GOALS'						=> $lang['wm_stats_most_goals'],
	'L_STATS_MOST_GOALS_EXP'					=> $lang['wm_stats_most_goals_exp'],
	'S_STATS_MOST_GOALS'						=> $stats_most_goals_combo,
	'L_STATS_MOST_CORRECT_GOALS'				=> $lang['wm_stats_most_correct_goals'],
	'L_STATS_MOST_CORRECT_GOALS_EXP'			=> $lang['wm_stats_most_correct_goals_exp'],
	'S_STATS_MOST_CORRECT_GOALS'				=> $stats_most_correct_goals_combo,
	'L_STATS_MOST_WRONG_TIPS'					=> $lang['wm_stats_most_wrong_tips'],
	'L_STATS_MOST_WRONG_TIPS_EXP'				=> $lang['wm_stats_most_wrong_tips_exp'],
	'S_STATS_MOST_WRONG_TIPS'					=> $stats_most_wrong_tips_combo,
	'L_STATS_MOST_WORST_TIPS'					=> $lang['wm_stats_most_worst_tips'],
	'L_STATS_MOST_WORST_TIPS_EXP'				=> $lang['wm_stats_most_worst_tips_exp'],
	'S_STATS_MOST_WORST_TIPS'					=> $stats_most_worst_tips_combo,
	'L_STATS_MOST_TIPS_VOTED'					=> $lang['wm_stats_most_tips_voted'],
	'L_STATS_MOST_TIPS_VOTED_EXP'				=> $lang['wm_stats_most_tips_voted_exp'],
	'S_STATS_MOST_TIPS_VOTED'					=> $stats_most_tips_voted_combo,
	'L_STATS_MOST_TIPS_VOTED2'					=> $lang['wm_stats_most_tips_voted2'],
	'L_STATS_MOST_TIPS_VOTED2_EXP'				=> $lang['wm_stats_most_tips_voted2_exp'],
	'S_STATS_MOST_TIPS_VOTED2'					=> $stats_most_tips_voted2_combo,
	'L_STATS_MOST_TIPS_VOTED_USER'				=> $lang['wm_stats_most_tips_voted_user'],
	'L_STATS_MOST_TIPS_VOTED_USER_EXP'			=> $lang['wm_stats_most_tips_voted_user_exp'],
	'S_STATS_MOST_TIPS_VOTED_USER'				=> $stats_most_tips_voted_user_combo,
	'L_STATS_MOST_RESULTS'						=> $lang['wm_stats_most_results'],
	'L_STATS_MOST_RESULTS_EXP'					=> $lang['wm_stats_most_results_exp'],
	'S_STATS_MOST_RESULTS'						=> $stats_most_results_combo,
	'L_STATS_MOST_RESULTS2'						=> $lang['wm_stats_most_results2'],
	'L_STATS_MOST_RESULTS2_EXP'					=> $lang['wm_stats_most_results2_exp'],
	'S_STATS_MOST_RESULTS2'						=> $stats_most_results2_combo,
	'L_STATS_POINTS_TIPP'						=> $lang['wm_stats_points_tipp'],
	'L_STATS_POINTS_TIPP_EXP'					=> $lang['wm_stats_points_tipp_exp'],
	'S_STATS_POINTS_TIPP'						=> $stats_points_tipp_combo,
	'L_STATS_POINTS_NOWRONG_TIPP'				=> $lang['wm_stats_points_nowrong_tipp'],
	'L_STATS_POINTS_NOWRONG_TIPP_EXP'			=> $lang['wm_stats_points_nowrong_tipp_exp'],
	'S_STATS_POINTS_NOWRONG_TIPP'				=> $stats_points_nowrong_tipp_combo,
	'L_STATS_RANKSIZE'							=> $lang['wm_stats_ranksize'],
	'L_STATS_RANKSIZE_EXP'						=> $lang['wm_stats_ranksize_exp'],
	'S_STATS_RANKSIZE'							=> $new['stats_ranksize'],
	'L_TJLIST_LINK'								=> $lang['tjlist_link'],
	'L_TJLIST_LINK_EXP'							=> $lang['tjlist_link_exp'],
	'S_TJLIST_LINK'								=> $new['tjlist_link'],
	'L_TJLIST_SHOW'								=> $lang['tjlist_show'],
	'L_TJLIST_SHOW_EXP'							=> $lang['tjlist_show_exp'],
	'S_TJLIST_SHOW'								=> $tjlist_show_combo,
	'L_VOTEBARSIZE'								=> $lang['wm_acp_votebarsize'],
	'L_VOTEBARSIZE_EXP'							=> $lang['wm_acp_votebarsize_exp'],
	'S_VOTEBARSIZE'								=> $new['votebarsize'],
	'L_DELETE_TIPPS'							=> $lang['notify_delete_tipps'],
	'L_DELETE_TIPPS_EXP'						=> $lang['notify_delete_tipps_exp'],
	'S_DELETE_TIPPS'							=> $delete_tipps_combo,
	'L_NOTIFY'									=> $lang['notify'],
	'L_SHOW_ALLTEAMS'							=> $lang['wm_acp_show_allteams'],
	'L_SHOW_ALLTEAMS_EXP'						=> $lang['wm_acp_show_allteams_exp'],
	'S_SHOW_ALLTEAMS'							=> $show_allteams_combo,
	'L_NOTIFY_RANKSIZE'							=> $lang['notify_ranksize'],
	'L_NOTIFY_RANKSIZE_EXP'						=> $lang['notify_ranksize_exp'],
	'S_NOTIFY_RANKSIZE'							=> $new['notify_ranksize'],
	'L_NOTIFY_CODE'								=> $lang['notify_code'],
	'L_NOTIFY_CODE_EXP'							=> $lang['notify_code_exp'],
	'S_NOTIFY_CODE'								=> $new['notify_code'],
	'L_NOTIFY_POST_RANKMSG'						=> $lang['notify_post_rankmsg'],
	'L_NOTIFY_POST_RANKMSG_EXP'					=> $lang['notify_post_rankmsg_exp'],
	'S_NOTIFY_POST_RANKMSG'						=> $notify_post_rankmsg_combo,
	'L_NOTIFY_REPLY_TOPIC'						=> $lang['notify_reply_topic'],
	'L_NOTIFY_REPLY_TOPIC_EXP'					=> $lang['notify_reply_topic_exp'],
	'S_NOTIFY_REPLY_TOPIC'						=> $new['notify_reply_topic'],
	'L_NOTIFY_REPLY_SPECIAL_TOPIC'				=> $lang['notify_reply_special_topic'],
	'L_NOTIFY_REPLY_SPECIAL_TOPIC_EXP'			=> $lang['notify_reply_special_topic_exp'],
	'S_NOTIFY_REPLY_SPECIAL_TOPIC'				=> $new['notify_reply_special_topic'],
	'L_NOTIFY_WRITE_MAILS'						=> $lang['notify_write_mails'],
	'L_NOTIFY_WRITE_MAILS_EXP'					=> $lang['notify_write_mails_exp'],
	'S_NOTIFY_WRITE_MAILS'						=> $notify_write_mails_combo,
	'L_NOTIFY_FINALSTART'						=> $lang['notify_finalstart'],
	'L_NOTIFY_FINALSTART_EXP'					=> $lang['notify_finalstart_exp'],
	'S_NOTIFY_FINALSTART'						=> $new['notify_finalstart'],
	'L_NOTIFY_EXP'								=> $lang['notify_exp'],
	'L_FINALS_RESULT'							=> $lang['wm_acp_finals_result'],
	'L_FINALS_RESULT_EXP'						=> $lang['wm_acp_finals_result_exp'],
	'S_FINALS_RESULT'							=> $finals_result_combo,
	'KOENIG_TEAM'								=> $addplayerteam
	)
);

$template->pparse('body');
include('./page_footer_admin.'.$phpEx);

?>