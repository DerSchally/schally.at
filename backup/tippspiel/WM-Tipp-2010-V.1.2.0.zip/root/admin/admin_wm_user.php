<?php
/***************************************************************************
 *		       admin_wm_user.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
   $filename = basename(__FILE__);
   $module['wm_acp_menu_webtipp']['wm_acp_menu_users'] = $filename;
   return;
}

//
// Load default header
//
$phpbb_root_path = "../";
require($phpbb_root_path . 'extension.inc');
require('pagestart.' . $phpEx);
include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.' . $phpEx);
include($phpbb_root_path . 'includes/functions_wm.' . $phpEx);
$page_title =  $lang['wm_title_home'];

// Load Config
$wm_config    = array();  // Config values
$wm_config    = get_wm_config();

$template->set_filenames(array(
	"body" => "admin/admin_wm_user.tpl")
);

if( isset($HTTP_POST_VARS['Userid']))
{
	$userid = mysql_real_escape_string($_POST["Userid"]);
}
else
{
	$userid = '';
}

if( isset($HTTP_POST_VARS['specialuserid']))
{
	$specialuserid = mysql_real_escape_string($_POST["specialuserid"]);
}
else
{
	$specialuserid = '';
}

$sql = "SELECT user_id, username FROM  ". USERS_TABLE ." where username != 'Anonymous' ORDER BY username ASC ";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$usernameform[] = $row['username'];
	$useridform[] = $row['user_id'];
}

for ($s = 0 ; $s < count($useridform); $s++)
{
	if ($useridform[$s] == $userid)
	{
		$selected='selected';
	}
	else
	{
		$selected='';
	}

	$template->assign_block_vars('userform_block', array(
		"S_USERNAME" => $usernameform[$s],
		"S_USERID" => $useridform[$s],
		"S_SELECTED" => $selected
		)
	);
}

//DELETE USER

$sql = "SELECT tipp_user, username, wm_special FROM " . WM_TIPPS_TABLE . " inner join ". USERS_TABLE ." on tipp_user = user_id where tipp_id > 0 group by tipp_user ORDER BY username ASC ";
if( !$result = $db->sql_query($sql) )
{
	message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
}
while($row = $db->sql_fetchrow($result))
{
	$usernameformdelete[] = $row['username'];
	$useridformdelete[] = $row['tipp_user'];
}

for ($s = 0 ; $s < count($useridformdelete); $s++)
{
	$template->assign_block_vars('deleteuserform_block', array(
		"S_USERNAMEDELETE" => $usernameformdelete[$s],
		"S_USERIDDELETE" => $useridformdelete[$s]
		)
	);
}

//User f�r Specialrangliste aktivieren

if ( $wm_config['wm_special'] == 1 )
{
	$sql = "SELECT user_id, username FROM  ". USERS_TABLE ." where username != 'Anonymous' and wm_special = 0 ORDER BY username ASC ";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
	}
	while($row = $db->sql_fetchrow($result))
	{
		$useridspecialnotact[] = $row['user_id'];
		$usernamespecialnotact[] = $row['username'];
	}
	$template->assign_block_vars('specialrankingyes_block', array());
	for ($d = 0 ; $d < count($useridspecialnotact); $d++)
	{
		if ($useridspecialnotact[$d] == $specialuserid)
		{
			$selected='selected';
		}
		else
		{
			$selected='';
		}
		$template->assign_block_vars('specialrankingyes_block.specialrankingformyes_block', array(
			"S_SPECIALID" => $useridspecialnotact[$d],
			"S_SPECIALNAME" => $usernamespecialnotact[$d],
			"S_SELECTEDSPECIAL" => $selected
			)
		);
	}
}

//User f�r Specialrangliste deaktivieren

if ( $wm_config['wm_special'] == 1 )
{
	$sql = "SELECT user_id, username FROM  ". USERS_TABLE ." where username != 'Anonymous' and wm_special = 1 ORDER BY username ASC ";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
	}
	while($row = $db->sql_fetchrow($result))
	{
		$useridspecialact[] = $row['user_id'];
		$usernamespecialact[] = $row['username'];
	}
	$template->assign_block_vars('specialrankingno_block', array());
	for ($d = 0 ; $d < count($useridspecialact); $d++)
	{
		if ($useridspecialact[$d] == $specialuserid)
		{
			$selected='selected';
		}
		else
		{
			$selected='';
		}
		$template->assign_block_vars('specialrankingno_block.specialrankingformno_block', array(
			"S_SPECIALID" => $useridspecialact[$d],
			"S_SPECIALNAME" => $usernamespecialact[$d],
			"S_SELECTEDSPECIAL" => $selected
			)
		);
	}
}

//F�r Specialrangliste aktivierte User ausw�hlen

if ( $wm_config['wm_special'] == 1 )
{
	$sql = "SELECT user_id, username, wm_special FROM  ". USERS_TABLE ." where wm_special = '1' order by username ASC";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
	}
	while($row = $db->sql_fetchrow($result))
	{
		$useridspecialsel[] = $row['user_id'];
		$usernamespecialsel[] = $row['username'];
		$specialranksel[] = $row['wm_special'];
	}
	$template->assign_block_vars('specialrankingsel_block', array());
	for ($d = 0 ; $d < count($useridspecialsel); $d++)
	{
		$rowcount++;
		$row_countercheck = $rowcount % 2;
		if ($row_countercheck == '0')
		{
			$coloruser = 'row2';
		}
		else
		{
			$coloruser = 'row3';
		}
		$template->assign_block_vars('specialrankingsel_block.specialrankingselform_block', array(
			"S_SPECIALIDSEL" => $useridspecialsel[$d],
			"S_SPECIALNAMESEL" => $usernamespecialsel[$d],
			"S_SPECIALRANKSEL" => $specialranksel[$d],
			"USERCOLOR" => $coloruser
			)
		);
	}
}
$template->assign_vars(array(
	"S_FORMSELF" => append_sid("admin_wm_user.$phpEx"),
	"L_USERTIPPS_TITLE" => $lang['tipp_admin_usertipps_title'],
	"L_USERTIPPS_TEXT" => $lang['tipp_admin_usertipps_text'],
	"L_GAMEDAY_SELECT" => $lang['tipp_gameday_select'],
	"L_USERNAME_SELECT" => $lang['tipp_admin_username_select'],
	"L_DELETEUSER_SELECT" => $lang['tipp_admin_deleteuser_select'],
	"L_GO" => $lang['tipp_go'],
	"S_USERTIPPSPROCESS" => append_sid("wm_processuser.$phpEx"),
	"L_USERLISTYES" => $lang['tipp_admin_username_listyes'],
	"L_USERLISTNO" => $lang['tipp_admin_username_listno'],
	"L_USERLISTSEL" => $lang['tipp_admin_username_list_selected'],
	"L_USER_SELECT" => $lang['tipp_admin_username_select'],
	"L_SPECIALRANK_TITLE" => $lang['tipp_specialranking_title']
	)
);

$template->pparse('body');
include('./page_footer_admin.'.$phpEx);
?>