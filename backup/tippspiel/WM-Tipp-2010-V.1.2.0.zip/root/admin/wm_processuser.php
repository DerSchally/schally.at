<?php
/***************************************************************************
 *                       wm_processuser.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);
 
$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);
include($phpbb_root_path.'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

$sid = $_GET["sid"];
$userid = $_POST["userid"];
$mode = $_POST["mode"];
$specialid = $_POST["specialid"];

if ($mode == 'specialyes')
{
	$sql = "UPDATE ". USERS_TABLE ." SET wm_special = 1 WHERE user_id = $specialid ";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
	}
	?>
	<br>
	<table width="100%" cellpadding="4" cellspacing="1" border="0" class="forumline">
		<tr>
			<th class="thHead" align="center"><?php echo $lang['tipp_info'] ?></th>
		</tr>
		<tr>
			<td class="row1" width="100%" align="center"><span class="gensmall"><?php echo $lang['tipp_admin_useredit_specialyes'] ?>
				<br><br>
				<a href="<?echo "admin_wm_user.$phpEx?sid=$sid";?>"><?php echo $lang['tipp_admin_processusertipps_link'] ?></a>
				<br /><br />
				<a href="<?echo "../wm_round1.$phpEx";?>" target = "_parent" ><?php echo $lang['tipp_mainpage'] ?></a></span>
			</td>
			</td>
		</tr>
	</table>
	<?
}
if ($mode == 'specialno')
{
	$sql = "UPDATE ". USERS_TABLE ." SET wm_special = 0 WHERE user_id = $specialid";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
	}
	?>
	<br>
	<table width="100%" cellpadding="4" cellspacing="1" border="0" class="forumline">
		<tr>
			<th class="thHead" align="center"><?php echo $lang['tipp_info'] ?></th>
		</tr>
		<tr>
			<td class="row1" width="100%" align="center"><span class="gensmall"><?php echo $lang['tipp_admin_useredit_specialno'] ?>
				<br><br>
				<a href="<?echo "admin_wm_user.$phpEx?sid=$sid";?>"><?php echo $lang['tipp_admin_processusertipps_link'] ?></a>
				<br /><br />
				<a href="<?echo "../wm_round1.$phpEx";?>" target = "_parent" ><?php echo $lang['tipp_mainpage'] ?></a></span>
			</td>
		</tr>
	</table>
	<?
}

if ($mode == 'deleteuser')
{
	$deleteusername = $userid;
	$delusername = get_userdata($deleteusername);
	?>
	<table width="95%" height="40" cellpadding="2" cellspacing="1" border="0" class="forumline" align="center" valign="center">
		<form action="<?php echo append_sid("wm_processuser.$phpEx"); ?>" name='select' method="post">
		<tr>
			<td class="row3">
				<?php echo $lang['tipp_admin_deleteuser_question']; echo $delusername['username'];?>
			</td>
			<td class="row3">
				<input type="hidden" name="mode" value="deleteuseryes">
				<input type="hidden" name="userid" value="<?php echo $userid; ?>">
				<input type="submit" CLASS=BUTTON value="<?php echo $lang['tipp_go']; ?>" name="submit">
			</td>
		</tr>
		</form>
	</table>
	<?
}

if ($mode == 'deleteuseryes')
{
	$sql = "UPDATE ". USERS_TABLE ." SET wm_special = 0  WHERE user_id = '$userid' ";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
	}
	$sql = "DELETE FROM ". WM_TIPPS_TABLE ." WHERE tipp_user = '$userid' ";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
	}
	$sql = "DELETE FROM ". WM_TJAEGERTIPPS_TABLE ." WHERE userid = '$userid' ";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
	}
	?>
	<br>
	<table width="100%" cellpadding="4" cellspacing="1" border="0" class="forumline">
		<tr>
			<th class="thHead" align="center"><?php echo $lang['tipp_info'] ?></th>
		</tr>
		<tr>
			<td class="row1" width="100%" align="center"><span class="gensmall"><?php echo $lang['tipp_admin_deleteuser_success']; ?>
				<br><br>
				<a href="<?echo "admin_wm_user.$phpEx?sid=$sid";?>"><?php echo $lang['tipp_admin_processusertipps_link'] ?></a>
				<br /><br />
				<a href="<?echo "../wm_round1.$phpEx";?>" target = "_parent" ><?php echo $lang['tipp_mainpage'] ?></a></span>
			</td>
		</tr>
	</table>
	<?
}

include('./page_footer_admin.'.$phpEx);
?>