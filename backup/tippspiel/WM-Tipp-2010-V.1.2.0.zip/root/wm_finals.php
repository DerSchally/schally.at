<?php
/***************************************************************************
 *                       wm_finals.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
//
// End session management
//

// Load Config
$wm_config    = array();  // Config values
$wm_config    = get_wm_config();

If ($userdata['user_level'] == ADMIN && $wm_config['admin_sees_all'] == 1)
{
	$admin_sees_all = true;
}
If ($userdata['user_level'] != ADMIN && $wm_config['user_see_all'] == 1)
{
	$user_see_all = true;
}

If ($admin_sees_all == true || $user_see_all == true)
{
	$show_tipps = true;
}

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

$save_wmtipp   = ( isset($HTTP_POST_VARS['add_wm_winner']) ) ? $HTTP_POST_VARS['add_wm_winner'] : '';
if ( $save_wmtipp != '' )
{
	$tipped_winner  = ( isset($HTTP_POST_VARS['wm_winner']) ) ? $HTTP_POST_VARS['wm_winner']         : 0;
	$tipped_scorer  = ( isset($HTTP_POST_VARS['torjaegerid']) ) ? $HTTP_POST_VARS['torjaegerid']         : 0;
	$tipped_user_id = $userdata['user_id'];
	$koenigname = '';
	$koenigname = $_POST["koenigname"];
	$koenigvorname = $_POST["koenigvorname"];
	$koenigverein = $_POST["spielerteam"];
	$bildlink = $_POST["bildlink"];
	if ($koenigname != '')
	{
		$playerid = 0;
		$sql = "SELECT spielerid FROM " . WM_TJAEGER_TABLE . " WHERE name = '$koenigname' and vorname = '$koenigvorname' and verein = '$koenigverein' ";
		if (!$result = $db->sql_query($sql))
		{
			message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
		}
		while ($row = $db->sql_fetchrow($result))
		{
			$playerid = $row['spielerid'];
		}
		if ($playerid > 0)
		{
			$tipped_scorer = $playerid;
		}
		else #EINTRAGEN UND ALS TIPP W�HLEN
		{
			$sql = "INSERT INTO " . WM_TJAEGER_TABLE . " (Name, Vorname, Verein, link) VALUES('$koenigname', '$koenigvorname', '$koenigverein', '$bildlink')";
			if (!($result = $db->sql_query($sql)))
			{
				message_die(GENERAL_ERROR, 'Konnte keine Verbindung erstellen', '', __LINE__, __FILE__, $sql);
			}
			$sql = "SELECT spielerid FROM " . WM_TJAEGER_TABLE . " WHERE name = '$koenigname' and vorname = '$koenigvorname' and verein = '$koenigverein' ";
			if (!$result = $db->sql_query($sql))
			{
				message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
			}
			while ($row = $db->sql_fetchrow($result))
			{
				$tipped_scorer = $row['spielerid'];
			}
		}
	}
	save_wm_tipp($tipped_user_id, $tipped_winner, $tipped_scorer);
}

include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

//
// Check login status
//
if ( !$userdata['session_logged_in'] )
{
	redirect(append_sid("login.$phpEx?redirect=wm_finals.$phpEx"));
}

// filter disallowed users
if (!empty($wm_config['disallow_users']))
{
	$arr_disallowusers = array();
	$arr_disallowusers = explode(",", $wm_config['disallow_users']);
	if (in_array($userdata['user_id'], $arr_disallowusers))
	{
		message_die(GENERAL_MESSAGE, 'You are not allowed here.', '', '', '', '');
	}
}

//
// Check auth status
//
if ( $wm_config['restrict_to'] != 0 && !get_wm_auth() && $userdata['user_level'] != ADMIN && $userdata['user_id'] != $admin_id )
{
	$auth_msg = sprintf($lang['wm_access_denied'], '<a href="' . append_sid("groupcp.$phpEx?g=".$wm_config['restrict_to']) . '" class="gen">', '</a>', '<a href="'.append_sid("index.$phpEx").'" class="gen">', '</a>');
	message_die(GENERAL_MESSAGE, $auth_msg);
}

//
// Set pagetitle, pageheader and templatefile
//
$page_title = $lang['wm_title_home'];

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'wm_tipp_body.tpl')
);

// Check buttons
$moderation    = ( isset($HTTP_POST_VARS['edit_results']) )  ? $HTTP_POST_VARS['edit_results']  : '';
$save_tipp     = ( isset($HTTP_POST_VARS['save_tipp']) )     ? $HTTP_POST_VARS['save_tipp']     : '';
$save_results  = ( isset($HTTP_POST_VARS['save_results']) )  ? $HTTP_POST_VARS['save_results']  : '';

//
// Init arrays               Array contains:
//                           ---------------
$games_data   = array();  // All games data
$wm_teams     = array();  // All teama data (order by teamname)
$games_row    = array();  // Current games data
$teams_data   = array();  // All teams data
$tipps_data   = array();  // All tipps data
$results_data = array();  // All usertipps
$table_teams  = array();  // Team order by group
$tabCount     = 1;

//
// Update database
//
if ( $save_tipp != '' )
{
	clear_tipps($userdata['user_id'], 1);
	$current_time = time();
	for ( $i = 49; $i < 65; $i++ )
	{
		$tipp_home_val = ( isset($HTTP_POST_VARS['tipp_home'.$i]) )  ? $HTTP_POST_VARS['tipp_home'.$i] : '';
		$tipp_away_val = ( isset($HTTP_POST_VARS['tipp_away'.$i]) )  ? $HTTP_POST_VARS['tipp_away'.$i] : '';
		$tipp_time     = ( isset($HTTP_POST_VARS['tipp_time'.$i]) )  ? $HTTP_POST_VARS['tipp_time'.$i] : '';
		if ( $tipp_home_val != '' && $tipp_away_val != '' && $tipp_time != '' && $tipp_time > $current_time )
		{
			save_tipp($i, $userdata['user_id'], abs(intval($tipp_home_val)), abs(intval($tipp_away_val)), intval($current_time), intval($tipp_time));
		}
	}
}
if ( $save_results != '' )
{
	$home_val = ( isset($HTTP_POST_VARS['home']) )    ? $HTTP_POST_VARS['home']    : '';
	$away_val = ( isset($HTTP_POST_VARS['away']) )    ? $HTTP_POST_VARS['away']    : '';
	$home_id  = ( isset($HTTP_POST_VARS['home_id']) ) ? $HTTP_POST_VARS['home_id'] : '';
	$away_id  = ( isset($HTTP_POST_VARS['away_id']) ) ? $HTTP_POST_VARS['away_id'] : '';
	$game_id  = ( isset($HTTP_POST_VARS['game_id']) ) ? $HTTP_POST_VARS['game_id'] : '';

	// wenn keine Eingabe, dann vornstehendes Team nehmen
	$teamweiter = ( isset($HTTP_POST_VARS['winner_after']) ) ? $HTTP_POST_VARS['winner_after'] : 1;
	clear_result($game_id);
	if ( $home_val != '' && $away_val != '' )
	{
		if ( $wm_config['finals_result'] == 0 )
		{
			if ( abs(intval($home_val)) > abs(intval($away_val)) )
			{
				save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($home_id), intval($away_id), intval($HTTP_POST_VARS['game_status']));
				if ($game_id == 64)
				{
					clear_result(65);
					save_result(65, intval($home_id), 0);
				}
			}
			else if ( abs(intval($away_val)) > abs(intval($home_val)) )
			{
				save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($away_id), intval($home_id), intval($HTTP_POST_VARS['game_status']));
				if ($game_id == 64)
				{
					clear_result(65);
					save_result(65, intval($away_id), 0);
				}
			}
			else if ( abs(intval($away_val)) == abs(intval($home_val)) )
			{
				if ( $teamweiter == 1 )
				{
					save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($home_id), intval($away_id), intval($HTTP_POST_VARS['game_status']));
					if ($game_id == 64)
					{
						clear_result(65);
						save_result(65, intval($home_id), 0);
					}
				}
				else
				{
					save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($away_id), intval($home_id), intval($HTTP_POST_VARS['game_status']));
					if ($game_id == 64)
					{
						clear_result(65);
						save_result(65, intval($away_id), 0);
					}
				}
			}
		}
		else
		{
			if ( abs(intval($home_val)) != abs(intval($away_val)) )
			{
				if ( abs(intval($home_val)) > abs(intval($away_val)) )
				{
					save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($home_id), intval($away_id), intval($HTTP_POST_VARS['game_status']));
					if ($game_id == 64)
					{
						clear_result(65);
						save_result(65, intval($home_id), 0);
					}
				}
				else
				{
					save_result($game_id, abs(intval($home_val)), abs(intval($away_val)), intval($away_id), intval($home_id), intval($HTTP_POST_VARS['game_status']));
					if ($game_id == 64)
					{
						clear_result(65);
						save_result(65, intval($away_id), 0);
					}
				}
			}
		}
	}
	calculate_user_points();
}

//
// Load data
//
$teams_data   = get_wm_teams();
$results_data = get_wm_results();
$games_data   = get_wm_finalgames();
$wm_teams     = get_wm_teams_as_row();
$tipps_data   = get_wm_tipps();

$tippende = $wm_config['end_tipptime'] * 60;
//
// Listing
//
// Group loop
for ( $i = 0; $i < count($games_data); $i++ )
{
	// Get current game data
	$games_row = ( $i == 0 ) ? current($games_data) : next($games_data);
	// Group loop switches
	$template->assign_block_vars('grouprow', array(
		'GROUP_NAME'   => $games_row[0]['game_group'],
		'GROUP_AC'     => $games_row[0]['game_group']
		)
	);
	// Games loop
	for ( $j = 0; $j < count($games_row); $j++ )
	{
		// Init some vars
		$game_id            = $games_row[$j]['game_id'];
		$game_time          = $games_row[$j]['game_time'];
		$goals_home         = '';
		$goals_away         = '';
		$goals_tipp_home    = '';
		$goals_tipp_away    = '';
		$wm_tipps_pts       = '';
		$wm_tipps_pts_align = 'center';
		// Get results for the game
		if ( isset($results_data[$game_id]) )
		{
			$goals_home = $results_data[$game_id]['result_home'];
			$goals_away = $results_data[$game_id]['result_away'];
		}
		// Get tipps for the game
		if ( isset($tipps_data[$userdata['user_id']][$game_id]) )
		{
			$goals_tipp_home = $tipps_data[$userdata['user_id']][$game_id]['tipp_home'];
			$goals_tipp_away = $tipps_data[$userdata['user_id']][$game_id]['tipp_away'];
			$wm_tipps_pts1    = $tipps_data[$userdata['user_id']][$game_id]['tipp_points'];
			if ( $wm_config['points_grafical'] == 1 )
			{
				for ( $points = 0; $points < $wm_tipps_pts1; $points++ )
				{
					$wm_tipps_pts .= '<img src="./images/wm/euro_cup_small.png" alt="Punkte" border="0" />';
				}
				$wm_tipps_pts_align = 'left';
			}
			else
			{
				$wm_tipps_pts  = ( $wm_tipps_pts1 != 0 ) ? $wm_tipps_pts1 : '';
			}
		}
		// Build result entries
		if ( $moderation != '' )
		{
			$status_reg = (intval($results_data[$game_id]['result_status'] == 0)) ? ' checked="checked"' : '';
			$status_nv = ($results_data[$game_id]['result_status'] == 1) ? ' checked="checked"' : '';
			$status_ne = ($results_data[$game_id]['result_status'] == 2) ? ' checked="checked"' : '';
			if ( $wm_config['finals_result'] == 1 )
			{
				$wm_results  = '<form action="' . append_sid("./wm_finals.".$phpEx) . '" name="save_a_result" method="POST" enctype="multipart/form-data"><input type="hidden" name="game_id" value="' . $game_id . '" /><input type="hidden" name="home_id" value="' . $teams_data[$games_row[$j]['game_home']]['team_id'] . '" /><input type="hidden" name="away_id" value="' . $teams_data[$games_row[$j]['game_away']]['team_id'] . '" /><input type="text" name="home" value="' . $goals_home . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />&nbsp;&nbsp;<b>:</b>&nbsp;&nbsp;<input type="text" name="away" value="' . $goals_away . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />&nbsp;<input type="submit" class="liteoption" name="save_results" value="' . $lang['l_wm_round1_editresults1'] . '"><br />' . $lang['wm_finalreg'] . '<input name="game_status" type="radio" value="0" ' . $status_reg . '> &nbsp;|&nbsp;' . $lang['wm_finalnv'] . '<input name="game_status" type="radio" value="1"' . $status_nv . '>&nbsp;|&nbsp;' . $lang['wm_finalne'] . '<input name="game_status" type="radio" value="2"' . $status_ne . '></form>';
			}
			else
			{
				// Patch 08.05.2010
				$wm_resultsAfter90 = '<br /><hr><i>Nur bei Unentschieden notwendig:</i><br />Weiter ist<br /><input type="radio" name="winner_after" value=1> ' . $teams_data[$games_row[$j]['game_home']]['team_name'] . ' oder <input type="radio" name="winner_after" value=2> ' . $teams_data[$games_row[$j]['game_away']]['team_name'];
				$wm_results  = '<form action="' . append_sid("./wm_finals.".$phpEx) . '" name="save_a_result" method="POST" enctype="multipart/form-data"><input type="hidden" name="game_id" value="' . $game_id . '" /><input type="hidden" name="home_id" value="' . $teams_data[$games_row[$j]['game_home']]['team_id'] . '" /><input type="hidden" name="away_id" value="' . $teams_data[$games_row[$j]['game_away']]['team_id'] . '" /><input type="text" name="home" value="' . $goals_home . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />&nbsp;&nbsp;<b>:</b>&nbsp;&nbsp;<input type="text" name="away" value="' . $goals_away . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />&nbsp;<input type="submit" class="liteoption" name="save_results" value="' . $lang['l_wm_round1_editresults1'] . '"><br />' . $lang['wm_finalreg'] . '<input name="game_status" type="radio" value="0" ' . $status_reg . '> &nbsp;|&nbsp;' . $lang['wm_finalnv'] . '<input name="game_status" type="radio" value="1"' . $status_nv . '>&nbsp;|&nbsp;' . $lang['wm_finalne'] . '<input name="game_status" type="radio" value="2"' . $status_ne . '>' .$wm_resultsAfter90 . '</form>';
			}
		}
		else
		{
			$goals_home = ( $goals_home == '' ) ? '-' : $goals_home;
			$goals_away = ( $goals_away == '' ) ? '-' : $goals_away;
			$wm_results  = $goals_home . '&nbsp;<b>:</b>&nbsp;' . $goals_away;
		}
		// Build tipps entries
		if ( $moderation != '' )
		{
			$goals_tipp_home = ( $goals_tipp_home == '' ) ? '-' : $goals_tipp_home;
			$goals_tipp_away = ( $goals_tipp_away == '' ) ? '-' : $goals_tipp_away;
			$wm_tipps  = $goals_tipp_home . '&nbsp;<b>:</b>&nbsp;' . $goals_tipp_away;
		}
		else
		{
			if ( $game_time - $tippende < time() )
			{
				$wm_tipps  = $goals_tipp_home . '&nbsp;<b>:</b>&nbsp;' . $goals_tipp_away . '<input type="hidden" name="tipp_time' . $game_id . '" value="' . $games_row[$j]['game_time'] . '" /><input type="hidden" name="tipp_home' . $game_id . '" value="' . $goals_tipp_home . '" /><input type="hidden" name="tipp_away' . $game_id . '" value="' . $goals_tipp_away . '" />';
			}
			else
			{
				$wm_tipps    = '<input type="hidden" name="tipp_time' . $game_id . '" value="' . $games_row[$j]['game_time'] . '" /><input type="text" name="tipp_home' . $game_id . '" value="' . $goals_tipp_home . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />&nbsp;&nbsp;<b>:</b>&nbsp;&nbsp;<input type="text" name="tipp_away' . $game_id . '" value="' . $goals_tipp_away . '" maxlength="2" size="2" class="post" tabindex="' . $tabCount++ . '" />';
				if ( $wm_config['finals_result'] == 1 )
				{
					$wm_tipps .= ($goals_tipp_home != '' && $goals_tipp_away != '' && $goals_tipp_home == $goals_tipp_away) ? '&nbsp;&nbsp;<img src="./images/wm/warnung.gif" width="14" height="14" alt="Unentschieden kann in den Endspielen nicht vorkommen!" title="Unentschieden kann in den Endspielen nicht vorkommen!" />' : '';
				}
			}
		}
		// Game loop switches
		$template->assign_block_vars('grouprow.gamesrow', array(
			'GAME_DATE'           => create_date($board_config['default_dateformat'], $games_row[$j]['game_time'], $board_config['board_timezone']),
			'GAME_RESULT'         => $wm_results,
			'GAME_ID'             => $game_id,
			'GAME_STATUS'      => (($results_data[$game_id]['result_status'] != 0) && ($moderation == '')) ? ($results_data[$game_id]['result_status'] == 1) ? '&nbsp;('.$lang['wm_finalnv'].')' : '&nbsp;('.$lang['wm_finalne'].')' : '',
			'GAME_TIPP'           => $wm_tipps,
			'SHOWTIPPS'           => (($games_row[$j]['game_time'] < time()) || !$show_tipps) ? '<br /><a href="'.append_sid('wm_showtipps.'.$phpEx.'?game_id='.$games_row[$j]['game_id']).'" onclick="window.open(\''.append_sid('wm_showtipps.'.$phpEx.'?game_id='.$games_row[$j]['game_id']).'\', \'_wm_showtipps\', \'height=700,resizable=yes,scrollbars=yes,width=600\');return false;" target="_wm_showtipps" class="nav"">'.$lang['wm_showtipps'].'</a>' : '',
			'GAME_TIPP_PTS'       => $wm_tipps_pts,
			'GAME_TIPP_PTS_ALIGN' => $wm_tipps_pts_align,
			'GAME_LOC'            => $games_row[$j]['game_loc'],
			'GAME_LOCLINK'        => $games_row[$j]['game_loclink'],
			'GAME_AWAY_TEAM'      => ( $games_row[$j]['game_away'] == 0 ) ? '--------': $teams_data[$games_row[$j]['game_away']]['team_name'],
			'GAME_AWAY_IMG'       => ( $games_row[$j]['game_away'] == 0 ) ? 'none.gif': $teams_data[$games_row[$j]['game_away']]['team_img'],
			'GAME_AWAY_LINK'      => ( $games_row[$j]['game_away'] == 0 ) ? 'http://de.fifa.com/worldcup/teams/index.html': $teams_data[$games_row[$j]['game_away']]['team_link'],
			'GAME_HOME_TEAM'      => ( $games_row[$j]['game_home'] == 0 ) ? '--------': $teams_data[$games_row[$j]['game_home']]['team_name'],
			'GAME_HOME_IMG'       => ( $games_row[$j]['game_home'] == 0 ) ? 'none.gif': $teams_data[$games_row[$j]['game_home']]['team_img'],
			'GAME_HOME_LINK'      => ( $games_row[$j]['game_home'] == 0 ) ? 'http://de.fifa.com/worldcup/teams/index.html': $teams_data[$games_row[$j]['game_home']]['team_link']
			)
		);
	}
}

// WM moderator buttons switch
if ( ($userdata['user_level'] == ADMIN || $userdata['user_id'] == $admin_id) && $moderation == '' )
{
	$template->assign_block_vars('wm_moderator_edit', array());
}
if ( $moderation == '' )
{
	$template->assign_block_vars('wm_tipp_save', array());
}
$template->assign_block_vars('finals', array());

// Check if tippforum is enabled
if ( $wm_config['wm_forum_id'] != 0 )
{
	$template->assign_block_vars('forum_enabled', array());
	if ( $wm_config['wm_forum_special_id'] != 0 )
	{
		$template->assign_block_vars('forum_enabled.special_enabled', array(
			'L_WM_FORUM_SPECIAL'     => $lang['l_wm_nav_forum_special'],
			'U_WM_FORUM_SPECIAL'     => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_special_id']),
			)
		);
	}
}

if ( $wm_config['wm_special'] == 1 )
{
	$template->assign_block_vars('special_enabled', array());
}

if ( $wm_config['stats_general'] == 1 )
{
	$template->assign_block_vars('stats_general', array());
}

$wmtipp_delay = $wm_config['wmtipp_delay'];
// Build WM champion
$first_game = get_first_game();
$users_winner_tipp = get_wm_winner($userdata['user_id']);
if ( time() < $first_game[0]['game_time'] + $wmtipp_delay * 86400 )
{
	$wm_winner_combo  = $lang['l_wm_winner_is'] . ': <select name="wm_winner">';
	$wm_winner_combo .= '<option value="0">' . $lang['l_wm_winner_not_set'] . '</option>';
	$wm_winner_combo .= '<option value="0">--------------</option>';
	for ( $r = 0; $r < count($wm_teams); $r++ )
	{
		$selected = ( $wm_teams[$r]['team_id'] == $users_winner_tipp ) ? ' selected' : '';
		$wm_winner_combo .= '<option value="' . $wm_teams[$r]['team_id'] . '" ' . $selected . '>' . $wm_teams[$r]['team_name'] . '</option>';
	}
	$wm_winner_combo .= '</select>';
	$wm_winner = $wm_winner_combo;
}
else
{
	$wm_winner = ( $users_winner_tipp != 0 ) ? $lang['l_wm_winner_is'] . ": <a href=\"" . $teams_data[$users_winner_tipp]['team_link'] . "\" target=\"_blank\">" . $teams_data[$users_winner_tipp]['team_name'] . "</a>" : $lang['l_wm_winner_not_set'];
}

// WM Torsch�tze
if ($userdata['user_id'] != ANONYMOUS)
{
	$useridwinnertipp = $userdata['user_id'];
	if (time() < $first_game[0]['game_time'] + $wmtipp_delay * 86400 )
	{
		$spieleridtipp = '';
		$selectedspieler = array();
		$name = array();
		$spielerid = array();
		$sql = "SELECT * FROM " . WM_TJAEGERTIPPS_TABLE . " where userid = $useridwinnertipp";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
		}
		while($row = $db->sql_fetchrow($result))
		{
			$spieleridtipp = $row['spielerid'];
		}
		$playerimage = '/images/wm/fussballdribbler.gif';
		$sql = "SELECT * FROM `" . WM_TJAEGER_TABLE . "` order by name, vorname, verein";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
		}
		while($row = $db->sql_fetchrow($result))
		{
			if ($spieleridtipp == $row['spielerid'])
			{
				$selectedspieler[]='selected';
				$playerimage = $row['link'];
			}
			else
			{
				$selectedspieler[]='';
			}
			$name[] = ($row['Vorname'] == '') ?  $row['Name'] . ' (' .  $row['verein'] . ')' : $row['Name'] . ', ' . $row['Vorname'] . ' (' .  $row['verein'] . ')';
			$spielerid[] = $row['spielerid'];
			$playerimages .= '"' . $row['link'] . '", ';
		}
		if(!in_array("selected",$selectedspieler))
		{
			array_push($name,"-bitte w�hlen-");
			array_push($spielerid,"0");
			array_push($selectedspieler,"selected");
		}
		$playerimages = substr($playerimages,0,strlen($playerimages)-2);
		$TORJAEGER = '<td class="row1" width="50%" align="center" height="30"><span class="genmed">';
		$TORJAEGER .= 'Torsch�tzenk�nigtipp: </span><select name="torjaegerid" onchange="ChangeImage();">';
		for($e = 0; $e < count($spielerid);$e++)
		{
			$TORJAEGER .='<option value="'.$spielerid[$e].'" '.$selectedspieler[$e].'>'.$name[$e].'</option>';
		}
		$TORJAEGER .= '</select>';
		$TORJAEGER .='<br><br><span class="genmed">Spieler nicht vorhanden?&nbsp;</span>'; 
		$TORJAEGER .='<span class="smallfont">'; 
		$TORJAEGER .='<input type="button" value=" Spieler hinzuf�gen " class="liteoption" style="width:128;font-size:10px;margin:0px;padding:0px; height:21" onClick="if (document.getElementById(\'spoiler\').style.display != \'\') { document.getElementById(\'spoiler\').style.display = \'\'; this.innerText = \'\'; this.value = \' Ausblenden \'; } else { document.getElementById(\'spoiler\').style.display = \'none\'; this.innerText = \'\'; this.value = \' Spieler hinzuf�gen \'; }">'; 
		$TORJAEGER .='</span><div class="spoiler" id="spoiler" style="display: none;"> 
		<table border="0" width="100%"> 
			<tr> 
				<td width="85">Name:</td> 
				<td><input type="text" value="" name="koenigname" size="20"></td> 
			</tr> 
			<tr> 
				<td width="85">Vorname:</td> 
				<td><input type="text" value="" name="koenigvorname" size="20"></td>'; 
			$TORJAEGER .='   </tr> 
			<tr> 
				<td width="85">Bildlink:</td> 
				<td><input type="text" value="" name="bildlink" size="20"></td> 
			</tr> 
			<tr> 
				<td width="85">Land: </td> 
				<td><select name="spielerteam">'; 
		for ( $r = 0; $r < count($wm_teams); $r++ )
		{ 
			$TORJAEGER .= '<option value="' . $wm_teams[$r]['team_name'] . '">' . $wm_teams[$r]['team_name'] . '</option>'; 
		} 
		$TORJAEGER .='</select></td></tr>
		</table></div></div></td>';
		$TORJAEGER .= '<td  class="row1" width="94" align="center" height="30"><img width=90 boarder=0 src="'.$playerimage.'" name="Playerimage" /></td>';
		$tipp_save_button = ( $users_winner_tipp == 0 ) ? $lang['l_wm_winner_save'] : $lang['l_wm_winner_edit'];
		$sendbutton = '<input type="submit" name="add_wm_winner" value="' . $tipp_save_button . '">';
		$winnerstipp_exp = $lang['l_wm_winnerstipp_exp'];
	}
	# Nach eigestelltem Spieltag keine Auswahl mehr, nur noch anzeige
	else
	{
		$sendbutton = '';
		//Torsch�tze
		$spieleridtipp = '';
		$useridwinnertipp = $userdata['user_id'];
		$sql = "SELECT * FROM " . WM_TJAEGERTIPPS_TABLE . " where userid ='$useridwinnertipp'";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
		}
		while($row = $db->sql_fetchrow($result))
		{
			$spieleridtipp = $row['spielerid'];
		}
		$sql = "SELECT * FROM " . WM_TJAEGER_TABLE . " where spielerid = '$spieleridtipp'";
		if( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
		}
		while($row = $db->sql_fetchrow($result))
		{
			$name = ($row['Vorname'] == '') ? '<img width=100 boarder=0 src="'. $row['link'] .'" ><br>' . $row['Name'] . ' (' .  $row['verein'] . ')<br>Tore: ' . $row['tore']  : '<img width=100 boarder=0 src="'. $row['link'] .'" ><br>' . $row['Name'] . ', ' . $row['Vorname'] . ' (' .  $row['verein'] . ')<br>Tore: ' . $row['tore'];
		}
		$TORJAEGER = '<td class="row1" width="50%" align="center" height="30"><span class="genmed">'.$name.'</span></td>';
	}
}
// WM Torsch�tze ENDE

$end_tipptime		=$wm_config['end_tipptime'];
if ( $end_tipptime == '0' ) 
{
	$end_tipptime = $lang['wm_rules_coll-0'];
}
else
{
	if ( $end_tipptime == '1' )
	{
		$end_tipptime .= ' ' . $lang['wm_rules_coll-1'];
	}
	else
	{
		$end_tipptime .= ' ' . $lang['wm_rules_coll-2'];
	}
}
$inf_tipptime = sprintf($lang['l_wm_round1_exp'], $end_tipptime);

if ( time() < $first_game[0]['game_time'] )
{
	$winnertipp = $lang['l_wm_winner_exp'];
}
else
{
	$winnertipp = $lang['l_wm_winner_exp_set'];
}
// General template vars and output
$template->assign_vars(array(
	'L_WM_WELCOME_TITLE'	=> $lang['l_wm_round1_welcome_title'],
	'L_WM_TITLE'			=> $lang['l_wm_round1_title'],
	'L_WM_EXP'				=> $inf_tipptime,
	'L_WM_FINALS'			=> $lang['l_wm_nav_finals'],
	'L_WM_STATS_COMPLETE'	=> $lang['l_wm_nav_stats_complete'],
	'L_WM_STATS'			=> $lang['l_wm_nav_stats'],
	'L_WM_WINNER_EXP'		=> $winnertipp,
	'L_WM_WINNER'			=> $lang['l_wm_stats_winnertipp'],
	'WM_WINNER'				=> $wm_winner,
	'WM_SCORER'				=> $TORJAEGER,
	'WM_SENDBUTTON'			=> $sendbutton,
	'WM_TIPP_MSG' 			=> $winnerstipp_exp,
	'L_WM_DATE'				=> $lang['l_wm_round1_date'],
	'L_WM_LOCATION'			=> $lang['l_wm_round1_location'],
	'L_WM_EVENT'			=> $lang['l_wm_round1_event'],
	'L_WM_MOD'				=> $lang['l_wm_nav_mod'],
	'L_WM_FORUM'             => $lang['l_wm_nav_forum'],
	'L_WM_RESULT'            => $lang['l_wm_round1_result'],
	'L_WM_TIPP'              => $lang['l_wm_round1_tipp'],
	'L_WM_TABLE'             => $lang['l_wm_round1_table'],
	'L_WM_ROUND1'            => $lang['l_wm_nav_round1'],
	'L_WM_POS'               => $lang['l_wm_table_pos'],
	'L_WM_TEAM'              => $lang['l_wm_table_team'],
	'L_WM_GOALS'             => $lang['l_wm_table_goals'],
	'L_WM_PLEASE_WAIT'       => $lang['l_wm_please_wait'],
	'L_WM_POINTS'            => $lang['l_wm_table_points'],
	'L_WM_SAVERESULTS'       => $lang['l_wm_round1_saveresults'],
	'L_WM_EDITRESULTS'       => $lang['l_wm_round1_editresults'],
	'L_WM_SAVETIPP'          => $lang['l_wm_round1_savetipp'],
	'L_WM_WINNERSTAT'    => $lang['wm_st_winnertips'],
	'L_WM_TJSTAT'   	=> 'Torj�ger-Tipps',
	"PALYERIMAGE"			 => $playerimage,
	"PALYERIMAGES" 			=> $playerimages,
	'U_WM_WINNERSTAT'		=> append_sid("./wm_winnerstat.".$phpEx),
	'U_WM_TJSTAT'		=> append_sid("./wm_tjstat.".$phpEx),
	'U_WM_FINALS'            => append_sid("./wm_finals.".$phpEx),
	'U_WM_ROUND1'            => append_sid("./wm_round1.".$phpEx),
	'U_WM_MORESTATS'	=> append_sid("./wm_morestats.".$phpEx),
	'L_WM_MORESTATS'	=> $lang['l_wmms_title'],
	'U_WM_MOD'               => append_sid("./privmsg.".$phpEx."?mode=post&u=".$admin_id),
	'U_WM_FORUM'             => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_id']),
	'U_WM_STATS'             => append_sid("./wm_stats.".$phpEx),
	'L_WM_POINTSYSTEM'    => $lang['l_wm_pointssystem'],
	'L_WM_POINTSWINNER'    => $lang['l_wm_pointswinner'],
	'L_WM_POINTSMATCH'    => $lang['l_wm_pointsmatch'],
	'L_WM_POINTSTEND'    => $lang['l_wm_pointstend'],
	'L_WM_POINTSTORDIFF'    => $lang['l_wm_pointstordiff'],
	'L_WM_POINTSTREFFERALONE'    => $lang['l_wm_pointstrefferalone'],
	'L_WM_POINTSWINNERSCORER'    => $lang['l_wm_pointswinnerscorer'],
	'PKT_WM_POINTSWINNER' => $wm_config['points_winner'],
	'PKT_WM_POINTSMATCH' => $wm_config['points_match'],
	'PKT_WM_POINTSTEND' => $wm_config['points_tendency'],
	'PKT_WM_POINTSTORDIFF' => $wm_config['points_tordiff'],
	'PKT_WM_POINTSTREFFERALONE'    => $wm_config['points_trefferalone'],
	'PKT_WM_POINTSWINNERSCORER'    => $wm_config['points_winnerscorer'], 
	'S_FORM_ACTION'          => append_sid("./wm_finals.".$phpEx),
	'L_WM_RULES'		=> $lang['wm_rules'],
	'U_WM_RULES'		=> append_sid("./wm_rules.".$phpEx),
	'L_WM_STATS_SPECIAL'    => $lang['l_wm_nav_stats_special'],
	'U_WM_STATS_SPECIAL'     => append_sid("./wm_stats_special.".$phpEx),
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

$template->pparse('body');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
?>