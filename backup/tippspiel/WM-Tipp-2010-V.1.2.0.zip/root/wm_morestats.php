<?php
/***************************************************************************
 *                       wm_morestats.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) B.Funke (buegelfalte)
 *   URL              : http://forum.beehave.de
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Start
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

// Start session management
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
// End session management

include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

if ( !$userdata['session_logged_in'] )
{
	redirect(append_sid("login.$phpEx?redirect=wm_morestats.$phpEx"));
}

// load config
$wm_config	= array();
$wm_config	= get_wm_config();

$all_user_data = array();
$all_user_data = get_all_the_users();

// filter disallowed users
if (!empty($wm_config['disallow_users']))
{
	$arr_disallowusers = array();
	$arr_disallowusers = explode(",", $wm_config['disallow_users']);
	if (in_array($userdata['user_id'], $arr_disallowusers))
	{
		message_die(GENERAL_MESSAGE, 'You are not allowed here.', '', '', '', '');
	}
}

// Set pagetitle, pageheader and templatefile
$page_title = $lang['wm_title_home'];

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'wm_morestats.tpl')
);

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

// get games
$str_gameids = get_gameids(WM_GAMES_TABLE);
$str_finalids = get_gameids(WM_FINALS_TABLE);
$str_gameids .= (!empty($str_finalids)) ? ",".$str_finalids : '';
if ($str_gameids == ""){$str_gameids = 0;}

$str_gameids_done = get_gameids(WM_GAMES_TABLE, true);
$str_finalids = get_gameids(WM_FINALS_TABLE, true);
$str_gameids_done .= (!empty($str_finalids)) ? ",".$str_finalids : '';
if ($str_gameids_done == ""){$str_gameids_done = 0;}

// --- user with most goals -----------------------------------------------------------------
if ( $wm_config['stats_most_goals'] == 1 )
{
	$template->assign_block_vars('stats_most_goals', array());
	$sql = "SELECT (SUM(tipp_home) + SUM(tipp_away)) AS torsumme, COUNT(*) AS tippanzahl, tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids . ") GROUP BY tipp_user";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_results = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_results[$row['tipp_user']]["quote"] = $row['torsumme'] / $row['tippanzahl'];
		$arr_results[$row['tipp_user']]["tore"] = $row['torsumme'];
		$arr_results[$row['tipp_user']]["tipps"] = $row['tippanzahl'];
		$arr_results[$row['tipp_user']]["username"] = reverse_username($all_user_data[$row['tipp_user']]);
	}
	arsort($arr_results);
	$int_count = 0;
	$int_nralt = -1;
	$mg_toreges = 0;
	$mg_tippsges = 0;
	foreach ($arr_results as $user_id => $user_data)
	{
		$int_count++;
		$mg_toreges += $user_data["tore"];
		$mg_tippsges += $user_data["tipps"];
		$template->assign_block_vars('stats_most_goals.goalrow', array(
			'MG_POS'		=> ($user_data["quote"] != $int_nralt) ? $int_count : '',
			'MG_USERNAME'	=> $all_user_data[$user_id],
			'MG_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'MG_QUOTE'		=> number_format(round($user_data["quote"], 2), 2, ",", "."),
			'MG_TORE'		=> $user_data["tore"],
			'MG_TIPPS'		=> $user_data["tipps"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["quote"];
	}
	if ($mg_tippsges == 0)
	{
		$mg_quoteges = 0;
	}
	else
	{
		$mg_quoteges = number_format(round($mg_toreges / $mg_tippsges, 2), 2, ",", ".");
	}
	$db->sql_freeresult($result);
}
// --- user with most correct goals (not correct tips !) ------------------------------------
if ( $wm_config['stats_most_correct_goals'] == 1 )
{
	$template->assign_block_vars('stats_most_correct_goals', array());
	$arr_usergoals = array();
	get_usergoals("tipp_home", "result_home = tipp_home");
	get_usergoals("tipp_away", "result_away = tipp_away");
	$arr_goalquote = array();
	foreach($arr_usergoals as $user_id => $user_data)
	{
		$arr_goalquote[$user_id]["quote"] = $user_data["torsumme"] / $user_data["tippanzahl"];
		$arr_goalquote[$user_id]["tore"] = $user_data["torsumme"];
		$arr_goalquote[$user_id]["tipps"] = $user_data["tippanzahl"];
		$arr_goalquote[$user_id]["username"] = reverse_username($all_user_data[$user_id]);
	}
	arsort($arr_goalquote);
	$int_count = 0;
	$int_nralt = -1;
	$cg_toreges = 0;
	$cg_tippsges = 0;
	foreach ($arr_goalquote as $user_id => $user_data)
	{
		$int_count++;
		$cg_toreges += $user_data["tore"];
		$cg_tippsges += $user_data["tipps"];
		$template->assign_block_vars('stats_most_correct_goals.goalcorrectrow', array(
			'CG_POS'		=> ($user_data["quote"] != $int_nralt) ? $int_count : '',
			'CG_USERNAME'	=> $all_user_data[$user_id],
			'CG_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'CG_QUOTE'		=> number_format(round($user_data["quote"], 2), 2, ",", "."),
			'CG_TORE'		=> $user_data["tore"],
			'CG_TIPPS'		=> $user_data["tipps"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["quote"];
	}
	if ($cg_tippsges == 0)
	{
		$cg_quoteges = 0;
	}
	else
	{
		$cg_quoteges = number_format(round($cg_toreges / $cg_tippsges, 2), 2, ",", ".");
	}
}

// --- most points per tipp ----------------------------------------------------------------
if ( $wm_config['stats_points_tipp'] == 1 )
{
	$template->assign_block_vars('stats_points_tipp', array());
	$sql = "SELECT COUNT(*) AS anztipps, SUM(tipp_points) AS sumpoints, tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids_done . ") GROUP BY tipp_user";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_pptipp = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_pptipp[$row['tipp_user']]["quote"] = $row['sumpoints'] / $row['anztipps'];
		$arr_pptipp[$row['tipp_user']]["tipps"] = $row['anztipps'];
		$arr_pptipp[$row['tipp_user']]["points"] = $row['sumpoints'];
		$arr_pptipp[$row['tipp_user']]["username"] = reverse_username($all_user_data[$row['tipp_user']]);
	}
	arsort($arr_pptipp);
	$int_count = 0;
	$int_nralt = -1;
	$pp_tippsges = 0;
	$pp_pktges = 0;
	foreach ($arr_pptipp as $user_id => $user_data)
	{
		$int_count++;
		$pp_tippsges += $user_data["tipps"];
		$pp_pktges += $user_data["points"];
		$template->assign_block_vars('stats_points_tipp.pptipprow', array(
			'PP_POS'		=> ($user_data["quote"] != $int_nralt) ? $int_count : '',
			'PP_USERNAME'	=> $all_user_data[$user_id],
			'PP_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'PP_QUOTE'		=> number_format(round($user_data["quote"], 2), 2, ",", "."),
			'PP_PUNKTE'		=> $user_data["points"],
			'PP_TIPPS'		=> $user_data["tipps"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["quote"];
	}
	if ($pp_tippsges == 0)
	{
		$pp_quoteges = 0;
	}
	else
	{
		$pp_quoteges = number_format(round($pp_pktges / $pp_tippsges, 2), 2, ",", ".");
	}
}

// --- most points per not failed tipp -----------------------------------------------------
if ( $wm_config['stats_points_nowrong_tipp'] == 1 )
{
	$template->assign_block_vars('stats_points_nowrong_tipp', array());
	$sql = "SELECT COUNT(*) AS anztipps, SUM(tipp_points) AS sumpoints, tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids_done . ") AND tipp_points > 0 GROUP BY tipp_user";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_ppctipp = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_ppctipp[$row['tipp_user']]["quote"] = $row['sumpoints'] / $row['anztipps'];
		$arr_ppctipp[$row['tipp_user']]["tipps"] = $row['anztipps'];
		$arr_ppctipp[$row['tipp_user']]["points"] = $row['sumpoints'];
		$arr_ppctipp[$row['tipp_user']]["username"] = reverse_username($all_user_data[$row['tipp_user']]);
	}
	arsort($arr_ppctipp);
	$int_count = 0;
	$int_nralt = -1;
	$pc_tippsges = 0;
	$pc_pktges = 0;
	foreach ($arr_ppctipp as $user_id => $user_data)
	{
		$int_count++;
		$pc_tippsges += $user_data["tipps"];
		$pc_pktges += $user_data["points"];
		$template->assign_block_vars('stats_points_nowrong_tipp.ppctipprow', array(
			'PC_POS'		=> ($user_data["quote"] != $int_nralt) ? $int_count : '',
			'PC_USERNAME'	=> $all_user_data[$user_id],
			'PC_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'PC_QUOTE'		=> number_format(round($user_data["quote"], 2), 2, ",", "."),
			'PC_PUNKTE'		=> $user_data["points"],
			'PC_TIPPS'		=> $user_data["tipps"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["quote"];
	}
	if ($pc_tippsges == 0)
	{
		$pc_quoteges = 0;
	}
	else
	{
		$pc_quoteges = number_format(round($pc_pktges / $pc_tippsges, 2), 2, ",", ".");
	}
}

// --- most identical tip ------------------------------------------------------------------
if ( $wm_config['stats_most_tips_voted'] == 1 )
{
	$template->assign_block_vars('stats_most_tips_voted', array());
	$sql = "SELECT tipp_home, tipp_away, COUNT(*) AS anzahl FROM " . WM_TIPPS_TABLE . "	WHERE tipp_game IN (" . $str_gameids . ") GROUP BY tipp_home, tipp_away ORDER BY anzahl DESC LIMIT " . $wm_config['stats_ranksize'];
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$int_count = 0;
	$int_nralt = -1;
	$ta_anzges = 0;
	while ( $row = $db->sql_fetchrow($result) )
	{
		$int_count++;
		$ta_anzges += $row['anzahl'];
		$template->assign_block_vars('stats_most_tips_voted.tippanzrow', array(
			'TA_POS'	=> ($row['anzahl'] != $int_nralt) ? $int_count : '',
			'TA_TIPP'	=> $row['tipp_home'].":".$row['tipp_away'],
			'TA_ANZ'	=> $row['anzahl']
			)
		);
		$int_nralt = $row['anzahl'];
	}
}
// --- most identical tip (cumulated) ------------------------------------------------------
if ( $wm_config['stats_most_tips_voted2'] == 1 )
{
	$template->assign_block_vars('stats_most_tips_voted2', array());
	$sql = "SELECT tipp_home, tipp_away, COUNT(*) AS anzahl FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids . ") GROUP BY tipp_home, tipp_away ORDER BY anzahl DESC LIMIT " . $wm_config['stats_ranksize'];
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_tipsk = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$str_tipp = ($row['tipp_away'] > $row['tipp_home']) ? $row['tipp_away'].":".$row['tipp_home'] : $row['tipp_home'].":".$row['tipp_away'];
		$arr_tipsk[$str_tipp] += $row['anzahl'];
	}
	arsort($arr_tipsk);
	$int_count = 0;
	$int_nralt = -1;
	$tak_anzges = 0;
	foreach ($arr_tipsk as $str_tipp => $int_anz)
	{
		$int_count++;
		$tak_anzges += $int_anz;
		$template->assign_block_vars('stats_most_tips_voted2.tippanzkrow', array(
			'TAK_POS'	=> ($int_anz != $int_nralt) ? $int_count : '',
			'TAK_TIPP'	=> $str_tipp,
			'TAK_ANZ'	=> $int_anz
			)
		);
		$int_nralt = $int_anz;
	}
}

// --- most identical tip per user ----------------------------------------------------------
if ( $wm_config['stats_most_tips_voted_user'] == 1 )
{
	$template->assign_block_vars('stats_most_tips_voted_user', array());
	$sql = "SELECT tipp_user, tipp_home, tipp_away FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids . ")";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_usertipps = array();
	$arr_usertippsk = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$str_tipp = $row['tipp_home'].":".$row['tipp_away'];
		$arr_usertipps[$row['tipp_user']][$str_tipp]++;
		$str_tipp = ($row['tipp_away'] > $row['tipp_home']) ? $row['tipp_away'].":".$row['tipp_home'] : $row['tipp_home'].":".$row['tipp_away'];
		$arr_usertippsk[$row['tipp_user']][$str_tipp]++;
	}
	$arr_tippsmax = array();
	foreach ($arr_usertipps as $user_id => $user_tipps)
	{
		arsort($user_tipps);
		$arr_tippsmax[$user_id]["anz"] = current($user_tipps);
		$arr_tippsmax[$user_id]["tipp"] = key($user_tipps);
		$arr_tippsmax[$user_id]["username"] = reverse_username($all_user_data[$user_id]);
	}
	arsort($arr_tippsmax);
	$int_count = 0;
	$int_nralt = -1;
	$st_anzges = 0;
	foreach ($arr_tippsmax as $user_id => $user_data)
	{
		$int_count++;
		$st_anzges += $user_data["anz"];
		$template->assign_block_vars('stats_most_tips_voted_user.sametipprow', array(
			'ST_POS'		=> ($user_data["anz"] != $int_nralt) ? $int_count : '',
			'ST_USERNAME'	=> $all_user_data[$user_id],
			'ST_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'ST_TIPP'		=> $user_data["tipp"],
			'ST_ANZ'		=> $user_data["anz"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["anz"];
	}
	$arr_tippsmaxk = array();
	foreach ($arr_usertippsk as $user_id => $user_tipps)
	{
		arsort($user_tipps);
		$arr_tippsmaxk[$user_id]["anz"] = current($user_tipps);
		$arr_tippsmaxk[$user_id]["tipp"] = key($user_tipps);
		$arr_tippsmaxk[$user_id]["username"] = reverse_username($all_user_data[$user_id]);
	}
	arsort($arr_tippsmaxk);
	$int_count = 0;
	$int_nralt = -1;
	$stk_anzges = 0;
	foreach ($arr_tippsmaxk as $user_id => $user_data)
	{
		$int_count++;
		$stk_anzges += $user_data["anz"];
		$template->assign_block_vars('stats_most_tips_voted_user.sametippkrow', array(
			'STK_POS'		=> ($user_data["anz"] != $int_nralt) ? $int_count : '',
			'STK_USERNAME'	=> $all_user_data[$user_id],
			'STK_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'STK_TIPP'		=> $user_data["tipp"],
			'STK_ANZ'		=> $user_data["anz"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["anz"];
	}
}

// --- most identical result ---------------------------------------------------------------
if ( $wm_config['stats_most_results'] == 1 )
{
	$template->assign_block_vars('stats_most_results', array());
	$sql = "SELECT result_home, result_away, COUNT(*) AS anzahl FROM " . WM_RESULTS_TABLE . " WHERE result_game IN (" . $str_gameids . ") GROUP BY result_home, result_away	ORDER BY anzahl DESC LIMIT " . $wm_config['stats_ranksize'];
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$int_count = 0;
	$int_nralt = -1;
	$ra_anzges = 0;
	while ( $row = $db->sql_fetchrow($result) )
	{
		$int_count++;
		$ra_anzges += $row['anzahl'];
		$template->assign_block_vars('stats_most_results.resultanzrow', array(
			'RA_POS'	=> ($row['anzahl'] != $int_nralt) ? $int_count : '',
			'RA_RESULT'	=> $row['result_home'].":".$row['result_away'],
			'RA_ANZ'	=> $row['anzahl']
			)
		);
		$int_nralt = $row['anzahl'];
	}
}

// --- most identical result (cumulated) ---------------------------------------------------
if ( $wm_config['stats_most_results2'] == 1 )
{
	$template->assign_block_vars('stats_most_results2', array());
	$sql = "SELECT result_home, result_away, COUNT(*) AS anzahl FROM " . WM_RESULTS_TABLE . " WHERE result_game IN (" . $str_gameids . ") GROUP BY result_home, result_away ORDER BY anzahl DESC LIMIT " . $wm_config['stats_ranksize'];
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_resultsk = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$str_result = ($row['result_away'] > $row['result_home']) ? $row['result_away'].":".$row['result_home'] : $row['result_home'].":".$row['result_away'];
		$arr_resultsk[$str_result] += $row['anzahl'];
	}
	arsort($arr_resultsk);
	$int_count = 0;
	$int_nralt = -1;
	$rak_anzges = 0;
	foreach ($arr_resultsk as $str_result => $int_anz)
	{
		$int_count++;
		$rak_anzges += $int_anz;
		$template->assign_block_vars('stats_most_results2.resultanzkrow', array(
			'RAK_POS'		=> ($int_anz != $int_nralt) ? $int_count : '',
			'RAK_RESULT'	=> $str_result,
			'RAK_ANZ'		=> $int_anz
			)
		);
		$int_nralt = $int_anz;
	}
}

// --- most wrong tipps --------------------------------------------------------------------
if ( $wm_config['stats_most_wrong_tips'] == 1 )
{
	$template->assign_block_vars('stats_most_wrong_tips', array());
	$sql = "SELECT tipp_points, tipp_user FROM " . WM_TIPPS_TABLE . " WHERE tipp_game IN (" . $str_gameids_done . ")";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_wrongtipps = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_wrongtipps[$row['tipp_user']]["tipps"]++;
		if ($row['tipp_points'] == 0)
		{
			$arr_wrongtipps[$row['tipp_user']]["wrong"]++;
		}
	}
	$arr_wrongquote = array();
	foreach ($arr_wrongtipps as $user_id => $user_data)
	{
		$arr_wrongquote[$user_id]["quote"] = $user_data["wrong"] / $user_data["tipps"] * 100;
		$arr_wrongquote[$user_id]["wrong"] = $user_data["wrong"];
		$arr_wrongquote[$user_id]["tipps"] = $user_data["tipps"];
		$arr_wrongquote[$user_id]["username"] = reverse_username($all_user_data[$user_id]);
	}
	arsort($arr_wrongquote);
	$int_count = 0;
	$int_nralt = -1;
	$mw_tippsges = 0;
	$mw_wrongges = 0;
	foreach ($arr_wrongquote as $user_id => $user_data)
	{
		$int_count++;
		$mw_tippsges += $user_data["tipps"];
		$mw_wrongges += $user_data["wrong"];
		$template->assign_block_vars('stats_most_wrong_tips.mostwrongrow', array(
			'MW_POS'		=> ($user_data["quote"] != $int_nralt) ? $int_count : '',
			'MW_USERNAME'	=> $all_user_data[$user_id],
			'MW_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'MW_QUOTE'		=> number_format(round($user_data["quote"], 2), 2, ",", ".")."%",
			'MW_TIPPS'		=> $user_data["tipps"],
			'MW_WRONG'		=> $user_data["wrong"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["quote"];
	}
	if ($mw_tippsges == 0)
	{
		$mw_quoteges = 0;
	}
	else
	{
		$mw_quoteges = number_format(round($mw_wrongges / $mw_tippsges * 100, 2), 2, ",", ".")."%";
	}
}

// --- worst tipps -------------------------------------------------------------------------
if ( $wm_config['stats_most_worst_tips'] == 1 )
{
	$template->assign_block_vars('stats_most_worst_tips', array());
	$sql = "SELECT tipp_user, tipp_home, tipp_away, result_home, result_away FROM " . WM_TIPPS_TABLE . ", " . WM_RESULTS_TABLE ." WHERE tipp_game IN (" . $str_gameids_done . ") AND tipp_game = result_game AND tipp_points = 0";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	$arr_worsttipps = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$int_daneben = (abs($row['tipp_home'] - $row['result_home']) + abs($row['tipp_away'] - $row['result_away']));
		if ($int_daneben > $arr_worsttipps[$row['tipp_user']]["offset"])
		{
			$arr_worsttipps[$row['tipp_user']]["offset"] = $int_daneben;
			$arr_worsttipps[$row['tipp_user']]["username"] = reverse_username($all_user_data[$row['tipp_user']]);
			$arr_worsttipps[$row['tipp_user']]["ist"] = $row['tipp_home'].":".$row['tipp_away'];
			$arr_worsttipps[$row['tipp_user']]["soll"] = $row['result_home'].":".$row['result_away'];
		}
	}
	arsort($arr_worsttipps);
	$int_count = 0;
	$int_nralt = -1;
	$wt_offsetges = 0;
	foreach ($arr_worsttipps as $user_id => $user_data)
	{
		$int_count++;
		$wt_offsetges += $user_data["offset"];
		$template->assign_block_vars('stats_most_worst_tips.worsttippsrow', array(
			'WT_POS'		=> ($user_data["offset"] != $int_nralt) ? $int_count : '',
			'WT_USERNAME'	=> $all_user_data[$user_id],
			'WT_USERLINK'	=> append_sid("profile.".$phpEx."?mode=viewprofile&u=".$user_id),
			'WT_OFFSET'		=> $user_data["offset"],
			'WT_IST'		=> $user_data["ist"],
			'WT_SOLL'		=> $user_data["soll"]
			)
		);
		if ($int_count >= $wm_config['stats_ranksize']) { break; }
		$int_nralt = $user_data["offset"];
	}
	if ($mw_tippsges == 0)
	{
		$mw_quoteges = 0;
	}
	else
	{
		$mw_quoteges = number_format(round($mw_wrongges / $mw_tippsges * 100, 2), 2, ",", ".")."%";
	}
}
// Assign vars
$template->assign_vars(array(
	'L_WM_TITLE'		=> $lang['l_wmms_title'],
	'L_WM_ROUND1'		=> $lang['l_wm_nav_round1'],
	'L_WM_FINALS'		=> $lang['l_wm_nav_finals'],
	'L_WM_STATS'		=> $lang['l_wm_nav_stats'],
	'L_WM_FORUM'		=> $lang['l_wm_nav_forum'],
	'L_WM_WINNERSTAT'   => $lang['wm_st_winnertips'],
	'L_WM_TJSTAT'   	=> 'Torj�ger-Tipps',
	'L_WM_MOD'			=> $lang['l_wm_nav_mod'],
	'U_WM_MOD'			=> append_sid("./privmsg.".$phpEx."?mode=post&u=".$admin_id),
	'U_WM_FORUM'		=> append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_id']),
	'U_WM_FINALS'		=> append_sid("./wm_finals.".$phpEx),
	'U_WM_STATS'		=> append_sid("./wm_stats.".$phpEx),
	'U_WM_WINNERSTAT'	=> append_sid("./wm_winnerstat.".$phpEx),
	'U_WM_TJSTAT'		=> append_sid("./wm_tjstat.".$phpEx),
	'U_WM_ROUND1'		=> append_sid("./wm_round1.".$phpEx),
	'U_WM_MORESTATS'	=> append_sid("./wm_morestats.".$phpEx),
	'L_WM_MORESTATS'	=> $lang['l_wmms_title'],
	'L_PLAYER'			=> $lang['Username'],
	'L_QUOTE'			=> $lang['l_wmms_quote'],
	'L_ANZAHL'			=> $lang['wm_st_number'],
	'L_TORE'			=> $lang['l_wmms_tore'],
	'L_TIPP'			=> $lang['l_wm_round1_tipp'],
	'L_TIPPS'			=> $lang['l_wmms_tipps'],
	'L_ERGEBNIS'		=> $lang['l_wm_round1_result'],
	'L_GOALROW'			=> $lang['l_wmms_goalrow'],
	'L_GOALCORRECTROW'	=> $lang['l_wmms_goalcorrectrow'],
	'L_TIPPANZROW'		=> $lang['l_wmms_tippanzrow'],
	'L_TIPPANZKROW'		=> $lang['l_wmms_tippanzkrow'],
	'L_SAMETIPPROW'		=> $lang['l_wmms_sametipprow'],
	'L_SAMETIPPKROW'	=> $lang['l_wmms_sametippkrow'],
	'L_RESULTANZROW'	=> $lang['l_wmms_resultanzrow'],
	'L_RESULTANZKROW'	=> $lang['l_wmms_resultanzkrow'],
	'L_WM_STATS_COMPLETE'    => $lang['l_wm_nav_stats_complete'],
	'L_WM_STATS_SPECIAL'    => $lang['l_wm_nav_stats_special'],
	'U_WM_STATS_SPECIAL'     => append_sid("./wm_stats_special.".$phpEx),
	'MG_GESAMT'         => $lang['l_wm_stats_complete'],
	'MG_QUOTEGES'		=> $mg_quoteges,
	'MG_TOREGES'		=> $mg_toreges,
	'MG_TIPPSGES'		=> $mg_tippsges,
	'CG_QUOTEGES'		=> $cg_quoteges,
	'CG_TOREGES'		=> $cg_toreges,
	'CG_TIPPSGES'		=> $cg_tippsges,
	'TA_ANZGES'			=> $ta_anzges,
	'TAK_ANZGES'		=> $tak_anzges,
	'ST_ANZGES'			=> $st_anzges,
	'STK_ANZGES'		=> $stk_anzges,
	'RA_ANZGES'			=> $ra_anzges,
	'RAK_ANZGES'		=> $rak_anzges,
	'S_FORM_ACTION'          => append_sid("./wm_finals.".$phpEx),
	'L_WM_RULES'		=> $lang['wm_rules'],
	'L_WM_EXP'           =>  $lang['l_wm_stats_exp_statistics'],
	'L_MOSTWRONG'		=> $lang['l_wmms_mostwrong'],
	'L_WRONG'			=> $lang['wm_ut_null'],
	'MW_QUOTEGES'		=> $mw_quoteges,
	'MW_TIPPSGES'		=> $mw_tippsges,
	'MW_WRONGGES'		=> $mw_wrongges,
	'L_WORST'			=> $lang['l_wmms_worsttipps'],
	'L_IST'				=> $lang['l_wmms_ist'],
	'L_SOLL'			=> $lang['l_wmms_soll'],
	'WT_OFFSETGES'		=> $wt_offsetges,
	'L_PPTIPP'			=> $lang['l_wmms_pointspertipp'],
	'L_PUNKTE'			=> $lang['l_wm_table_points'],
	'PP_QUOTEGES'		=> $pp_quoteges,
	'PP_PUNKTEGES'		=> $pp_pktges,
	'PP_TIPPSGES'		=> $pp_tippsges,
	'L_PPCTIPP'			=> $lang['l_wmms_pointsperctipp'],
	'PC_QUOTEGES'		=> $pc_quoteges,
	'PC_PUNKTEGES'		=> $pc_pktges,
	'PC_TIPPSGES'		=> $pc_tippsges,
	'U_WM_RULES'			=> append_sid("./wm_rules.".$phpEx),
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

$template->assign_block_vars('round1', array());

// Check if tippforum is enabled
if ( $wm_config['wm_forum_id'] != 0 )
{
	$template->assign_block_vars('forum_enabled', array());
	if ( $wm_config['wm_forum_special_id'] != 0 )
	{
		$template->assign_block_vars('forum_enabled.special_enabled', array(
			'L_WM_FORUM_SPECIAL'     => $lang['l_wm_nav_forum_special'],
			'U_WM_FORUM_SPECIAL'     => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_special_id']),
			)
		);
	}
}

if ( $wm_config['wm_special'] == 1 )
{
	$template->assign_block_vars('special_enabled', array());
}

$template->pparse('body');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

function get_gameids($str_table)
{
	global $db, $userdata;
	$str_games = "";
	$sql = "SELECT game_id FROM " . $str_table . " WHERE game_time < " . time();
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	while ( $row = $db->sql_fetchrow($result) )
	{
		$str_games .= (empty($str_games)) ? $row['game_id'] : ",".$row['game_id'];
	}
	return $str_games;
}

function get_usergoals($str_field, $str_where)
{
	global $db, $arr_usergoals;

	$sql = "SELECT tipp_user, SUM(" . $str_field . ") AS torsumme, COUNT(*) AS tippanzahl FROM " . WM_TIPPS_TABLE . ", " . USERS_TABLE . ", " . WM_RESULTS_TABLE . " WHERE tipp_game <> 65 AND user_id = tipp_user AND tipp_game = result_game AND " . $str_where . " GROUP BY tipp_user";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Query failed.', '', __LINE__, __FILE__, $sql);
	}
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_usergoals[$row['tipp_user']]["torsumme"] += $row['torsumme'];
		$arr_usergoals[$row['tipp_user']]["tippanzahl"] += $row['tippanzahl'];
	}
	$db->sql_freeresult($result);
}

function reverse_username($str_name)
{
	$str_reverse = "";
	$str_name = strtoupper($str_name);
	for ($i=0; $i<strlen($str_name); $i++)
	{
		$str_reverse .= chr(155 - ord(substr($str_name, $i, 1)));
	}
	return $str_reverse;
}
?>