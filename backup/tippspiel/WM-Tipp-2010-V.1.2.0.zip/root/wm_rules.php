<?php
/***************************************************************************
 *                       wm_rules.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

// Start session management
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
// End session management

include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.' . $phpEx);

//
// Check login status
//
if ( !$userdata['session_logged_in'] )
{
	redirect(append_sid("login.$phpEx?redirect=wm_rules.$phpEx"));
}

// Load Config
$wm_config    = array();  // Config values
$wm_config    = get_wm_config();

$page_title = $lang['wm_title_home'];

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'wm_rules_body.tpl')
);

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

//
// Build rules
//
$points_winner		= $wm_config['points_winner'];
$points_scorer		= $wm_config['points_winnerscorer'];
$points_match		= $wm_config['points_match'];
$points_tordiff		= $wm_config['points_tordiff'];
$points_tendency	= $wm_config['points_tendency'];
$points_trefferalone	= $wm_config['points_trefferalone'];
$end_tipptime		=$wm_config['end_tipptime'];
$wmtipp_delay		=$wm_config['wmtipp_delay'];

$point 				= $lang['l_wm_table_point'];
$points 			= $lang['l_wm_table_points'];

if ( $points_winner == '1' ) 
{
	$points_winner .= ' ' . $point;
}
else 
{
	$points_winner .= ' ' . $points;
}

if ( $points_scorer == '1' ) 
{
	$points_scorer .= ' ' . $point;
}
else 
{
	$points_scorer .= ' ' . $points;
}

if ( $points_match == '1' ) 
{
	$points_match .= ' ' . $point;
}
else 
{
	$points_match .= ' ' . $points;
}

if ( $points_tordiff == '1' ) 
{
	$points_tordiff .= ' ' . $point;
}
else 
{
	$points_tordiff .= ' ' . $points;
}

if ( $points_tendency == '1' ) 
{
	$points_tendency .= ' ' . $point;
}
else 
{
	$points_tendency .= ' ' . $points;
}

if ( $points_trefferalone == '1' ) 
{
	$points_trefferalone .= ' ' . $point;
}
else 
{
	$points_trefferalone .= ' ' . $points;
}

if ( $end_tipptime == '0' ) 
{
	$end_tipptime = $lang['wm_rules_coll-0'];
}
else
{
	if ( $end_tipptime == '1' )
	{
		$end_tipptime .= ' ' . $lang['wm_rules_coll-1'];
	}
	else
	{
		$end_tipptime .= ' ' . $lang['wm_rules_coll-2'];
	}
}

if ( $wmtipp_delay == '0' )
{
	$wmtipp_delay = $lang['wm_rules_wmtipp_delay-0'];
}
else
{
	if ( $wmtipp_delay == '1' )
	{
		$wmtipp_delay .= ' ' . $lang['wm_rules_wmtipp_delay-1'];
	}
	else
	{
		$wmtipp_delay .= ' ' . $lang['wm_rules_wmtipp_delay-2'];
	}
}

$rules_winner = sprintf($lang['wm_rules_winner'], $points_winner);
$rules_scorer = sprintf($lang['wm_rules_scorer'], $points_scorer);
$rules_match = sprintf($lang['wm_rules_match'], $points_match);
$rules_tordiff = sprintf($lang['wm_rules_tordiff'], $points_tordiff);
$rules_tendency = sprintf($lang['wm_rules_tendency'], $points_tendency);
$rules_trefferalone = sprintf($lang['wm_rules_trefferalone'], $points_trefferalone);

if ( $wm_config['finals_result'] == 1 )
{
	$rules_tipptime = sprintf($lang['wm_rules_finals_result'], $lang['wm_rules_finals_final']);
}
else
{
	$rules_tipptime = sprintf($lang['wm_rules_finals_result'], $lang['wm_rules_finals_90']);
}

$rules_tipptime .= sprintf($lang['wm_rules_collection'], $end_tipptime);
$rules_tipptime .= sprintf($lang['wm_rules_wmtipp_delay'], $wmtipp_delay);


$template->assign_vars(array(
	'L_WM_WELCOME_TITLE'     => $lang['l_wm_round1_welcome_title'],
	'L_WM_TITLE'             => $lang['l_wm_round1_title'],
	'L_WM_EXP'               => $lang['l_wm_rules_inf'],
	'L_WM_FINALS'            => $lang['l_wm_nav_finals'],
	'L_WM_STATS_COMPLETE'    => $lang['l_wm_nav_stats_complete'],
	'L_WM_RULES'             =>	$lang['wm_rules'],
	'L_WM_ROUND1'            => $lang['l_wm_nav_round1'],
	'L_WM_FORUM'             => $lang['l_wm_nav_forum'],
	'U_WM_FORUM'             => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_id']),
	'U_WM_FINALS'            => append_sid("./wm_finals.".$phpEx),
	'U_WM_ROUND1'            => append_sid("./wm_round1.".$phpEx),
	'U_WM_MORESTATS'	=> append_sid("./wm_morestats.".$phpEx),
	'L_WM_MORESTATS'	=> $lang['l_wmms_title'],
	'U_WM_STATS'             => append_sid("./wm_stats.".$phpEx),
	'L_WM_WINNERSTAT'		=>$lang['wm_st_winnertips'],
	'U_WM_WINNERSTAT'		=> append_sid("./wm_winnerstat.".$phpEx),
	'L_WM_TJSTAT'   	=> 'Torj�ger-Tipps',
	'U_WM_TJSTAT'		=> append_sid("./wm_tjstat.".$phpEx),
	'L_WM_RULES_POINTS' 	=> $lang['wm_rules_score'],
	'L_WM_RULES_GEN' 		=> $lang['wm_rules_general'],
	'WM_RULES_WINNER' 		=> $rules_winner,
	'WM_RULES_SCORER' 		=> $rules_scorer,
	'WM_RULES_MATCH' 		=> $rules_match,
	'WM_RULES_TORDIFF' 		=> $rules_tordiff,
	'WM_RULES_TENDENCY' 	=> $rules_tendency,
	'WM_RULES_TREFFERALONE' 	=> $rules_trefferalone,
	'WM_RULES_COLL' 			=> $rules_tipptime,
	'L_WM_STATS_SPECIAL'    => $lang['l_wm_nav_stats_special'],
	'U_WM_STATS_SPECIAL'     => append_sid("./wm_stats_special.".$phpEx),
	'U_WM_MOD'               => append_sid("./privmsg.".$phpEx."?mode=post&u=".$admin_id),
	'L_WM_MOD'               => $lang['l_wm_nav_mod'],
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

$template->assign_block_vars('round1', array());

// Check if tippforum is enabled
if ( $wm_config['wm_forum_id'] != 0 )
{
	$template->assign_block_vars('forum_enabled', array());
	if ( $wm_config['wm_forum_special_id'] != 0 )
	{
		$template->assign_block_vars('forum_enabled.special_enabled', array(
			'L_WM_FORUM_SPECIAL'     => $lang['l_wm_nav_forum_special'],
			'U_WM_FORUM_SPECIAL'=> append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_special_id']),
			)
		);
	}
}

if ( $wm_config['wm_special'] == 1 )
{
	$template->assign_block_vars('special_enabled', array());
}

if ( $wm_config['stats_general'] == 1 )
{
	$template->assign_block_vars('stats_general', array());
}

$template->pparse('body');

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>