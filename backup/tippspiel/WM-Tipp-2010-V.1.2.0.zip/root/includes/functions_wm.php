<?php
/***************************************************************************
 *                       functions_wm.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Get all config data
function get_wm_config()
{
	global $db;
	//
	// Get config data
	//
	$sql = "SELECT * FROM " . WM_CONFIG_TABLE;
	if(!$result = $db->sql_query($sql))
	{
		message_die(GENERAL_ERROR, "Could not query config information in wm configuration", "", __LINE__, __FILE__, $sql);
	}
	else
	{
		while( $row = $db->sql_fetchrow($result) )
		{
			$config_name = $row['config_name'];
			$config_value = $row['config_value'];
			$new[$config_name] = $config_value;
		}
	}
	$db->sql_freeresult($result);
	return $new;
}
// Get wm users data and points  up to yesterday
// for historical information
function get_wm_user_points_up_to_yesterday()
{
	global $db;
	// Load Config
	$wm_config    = array();  // Config values
	$wm_config    = get_wm_config();
	$timestamp_last_game_before_this_day = get_timestamp_for_ranking_history();
	//
	// Get users data
	//
	$sql = "SELECT A.tipp_user , sum( A.tipp_points ) AS user_points,
		count( A.tipp_points ) AS user_total_tipps,
		count( B.tipp_points ) AS user_points_tendency,
		count( C.tipp_points ) AS user_points_difference,
		count( D.tipp_points ) AS user_points_result
		FROM  " . WM_TIPPS_TABLE . " A
		LEFT JOIN " . WM_TIPPS_TABLE . " B ON A.tipp_id = B.tipp_id AND A.tipp_points = " . $wm_config['points_tendency'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " C ON A.tipp_id = C.tipp_id AND A.tipp_points = " . $wm_config['points_tordiff'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " D ON A.tipp_id = D.tipp_id AND A.tipp_points >= " . $wm_config['points_match'] . "
		inner join (Select game_id, Game_time FROM " . WM_GAMES_TABLE . " Union Select game_id, Game_time FROM " . WM_FINALS_TABLE . ") as E on E.game_id = A.tipp_game and E.game_time  < ". intval($timestamp_last_game_before_this_day) ."
		GROUP BY A.tipp_user ORDER BY user_points DESC, user_points_result DESC, user_points_difference DESC, user_points_tendency DESC, tipp_user ASC";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get historical user tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_user_points_up_to_yesterday = array();
	$int_userposabsolute = 0;
	$int_pktalt = -1;
	$i = 1;
	while ( $row = $db->sql_fetchrow($result) )
	{
		$int_userposabsolute = ($row['user_points'] != $int_pktalt) ? $i : $int_userposabsolute;
		$wm_user_points_up_to_yesterday[$row['tipp_user']] = $int_userposabsolute;
		$int_pktalt = $row['user_points'];
		$i = $i + 1;
	}
	$db->sql_freeresult($result);
	return $wm_user_points_up_to_yesterday;
}

// Get wm users data and points up to yesterday
// for historical information
function get_wm_user_points_up_to_yesterday_special()
{
	global $db;
	// Load Config
	$wm_config    = array();  // Config values
	$wm_config    = get_wm_config();
	$timestamp_last_game_before_this_day = get_timestamp_for_ranking_history();
	//
	// Get users data
	//
	$sql = "SELECT A.tipp_user , sum( A.tipp_points ) AS user_points,
		count( A.tipp_points ) AS user_total_tipps,
		count( B.tipp_points ) AS user_points_tendency,
		count( C.tipp_points ) AS user_points_difference,
		count( D.tipp_points ) AS user_points_result
		FROM  " . WM_TIPPS_TABLE . " A
		LEFT JOIN " . WM_TIPPS_TABLE . " B ON A.tipp_id = B.tipp_id AND A.tipp_points = " . $wm_config['points_tendency'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " C ON A.tipp_id = C.tipp_id AND A.tipp_points = " . $wm_config['points_tordiff'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " D ON A.tipp_id = D.tipp_id AND A.tipp_points >= " . $wm_config['points_match'] . "
		LEFT JOIN " . USERS_TABLE . " F ON A.tipp_user = F.user_id
		inner join (Select game_id, Game_time FROM " . WM_GAMES_TABLE . " Union Select game_id, Game_time FROM " . WM_FINALS_TABLE . ") as E on E.game_id = A.tipp_game and   E.game_time  < ". intval($timestamp_last_game_before_this_day) ."
		where F.wm_special = 1 GROUP BY A.tipp_user ORDER BY user_points DESC, user_points_result DESC, user_points_difference DESC, user_points_tendency DESC, tipp_user ASC";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get historical user tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_user_points_up_to_yesterday = array();
	$int_userposabsolute = 0;
	$int_pktalt = -1;
	$i = 1;
	while ( $row = $db->sql_fetchrow($result) )
	{
		$int_userposabsolute = ($row['user_points'] != $int_pktalt) ? $i : $int_userposabsolute;
		$wm_user_points_up_to_yesterday[$row['tipp_user']] = $int_userposabsolute;
		$int_pktalt = $row['user_points'];
		$i = $i + 1;
	}
	$db->sql_freeresult($result);
	return $wm_user_points_up_to_yesterday;
}

//gr�sste Anstosszeit der Spiele mit Ergebnissen holen
function get_timestamp_for_ranking_history()
{
	global $db;
	$sql = "SELECT  max(Games.game_time) as MaxTime
      FROM  " . WM_RESULTS_TABLE . " Res inner join (Select game_id, game_time from  " . WM_GAMES_TABLE . " union  SELECT  game_id, game_time  FROM  " . WM_FINALS_TABLE . " ) as Games
      on Games.game_id = Res.result_game";
	if( !($result_times = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get playing times of today', '', __LINE__, __FILE__, $sql);
	}
	$row_times = $db->sql_fetchrow($result_times);
	$timestamp_first_game_of_today = $row_times['MaxTime'];
	return $timestamp_first_game_of_today;
}

// Get wm teams data
function get_wm_teams($team_id = 0)
{
	global $db;
	//
	// Get teams data
	//
	if( $team_id == 0 )
	{
		$sql = "SELECT * FROM  " . WM_TEAMS_TABLE . " ORDER BY team_id ASC";
	}
	else
	{
		$sql = "SELECT * FROM  " . WM_TEAMS_TABLE . " WHERE team_id = $team_id";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get teams data', '', __LINE__, __FILE__, $sql);
	}
	$wm_teams = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$wm_teams[$row['team_id']] = $row;
	}
	$db->sql_freeresult($result);
	return $wm_teams;
}

// Get wm users data
function get_wm_users()
{
	global $db;
	// Load Config
	$wm_config    = array();  // Config values
	$wm_config    = get_wm_config();
	//
	// Get users data
	//
	$sql = "SELECT A. * , E.user_avatar_type, E.user_allowavatar, E.user_avatar, sum( A.tipp_points ) AS user_points,
		count( A.tipp_points ) AS user_total_tipps,
		count( B.tipp_points ) AS user_points_tendency,
		count( C.tipp_points ) AS user_points_difference,
		count( D.tipp_points ) AS user_points_result
		FROM  " . WM_TIPPS_TABLE . " A
		LEFT JOIN " . WM_TIPPS_TABLE . " B ON A.tipp_id = B.tipp_id AND A.tipp_points = " . $wm_config['points_tendency'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " C ON A.tipp_id = C.tipp_id AND A.tipp_points = " . $wm_config['points_tordiff'] . "
		LEFT JOIN " . WM_TIPPS_TABLE . " D ON A.tipp_id = D.tipp_id AND A.tipp_points = " . $wm_config['points_match'] . "
		LEFT JOIN " . USERS_TABLE . " E ON A.tipp_user = E.user_id
		GROUP BY A.tipp_user ORDER BY user_points DESC, user_points_result DESC, user_points_difference DESC, user_points_tendency DESC, username";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get user tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_users = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$wm_users[] = $row;
	}
	$db->sql_freeresult($result);
	return $wm_users;
}

// Get wm users data from Special group
function get_wm_usersspecial()
{
	global $db;
	// Load Config
	$wm_config = array();  // Config values
	$wm_config = get_wm_config();
	//
	// Get users data
	//
	$sql = "SELECT A. * , E.user_avatar_type, E.user_allowavatar, E.user_avatar, sum( A.tipp_points ) AS user_points,
                        count( A.tipp_points ) AS user_total_tipps,
                        count( B.tipp_points ) AS user_points_tendency,
                        count( C.tipp_points ) AS user_points_difference,
                        count( D.tipp_points ) AS user_points_result
                     FROM  " . WM_TIPPS_TABLE . " A
                     LEFT JOIN " . WM_TIPPS_TABLE . " B ON A.tipp_id = B.tipp_id AND A.tipp_points = " . $wm_config['points_tendency'] . "
                     LEFT JOIN " . WM_TIPPS_TABLE . " C ON A.tipp_id = C.tipp_id AND A.tipp_points = " . $wm_config['points_tordiff'] . "
                     LEFT JOIN " . WM_TIPPS_TABLE . " D ON A.tipp_id = D.tipp_id AND A.tipp_points = " . $wm_config['points_match'] . "
                     LEFT JOIN " . USERS_TABLE . " E ON A.tipp_user = E.user_id
                     where E.wm_special = 1 GROUP BY A.tipp_user ORDER BY user_points DESC, user_points_result DESC, user_points_difference DESC, user_points_tendency DESC, username";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get user tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_users = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$wm_users[] = $row;
	}
	$db->sql_freeresult($result);
	return $wm_users;
}

// Get all users data
function get_all_the_users()
{
	global $db;
	//
	// Get users data
	//
	$sql = "SELECT user_id, username FROM  " . USERS_TABLE;
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
	}
	$users = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$users[$row['user_id']] = $row['username'];
	}
	$db->sql_freeresult($result);
	return $users;
}

// Get wm teams data order by groups
function get_wm_teamids_by_groups()
{
	global $db;
	//
	// Get teams data
	//
	$sql = "SELECT * FROM  " . WM_TEAMS_TABLE . " ORDER BY team_id ASC";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get teams data', '', __LINE__, __FILE__, $sql);
	}
	$wm_teams = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$wm_teams[$row['team_group']][] = $row['team_id'];
	}
	$db->sql_freeresult($result);
	return $wm_teams;
}

// Get wm tipps data
function get_wm_tipps($calculate = 0, $user_id = 0)
{
	global $db;
	//
	// Get tipps data
	//
	if ( $user_id == 0 )
	{
		$sql = "SELECT * FROM  " . WM_TIPPS_TABLE . " ORDER BY tipp_id ASC";
	}
	else
	{
		$sql = "SELECT * FROM  " . WM_TIPPS_TABLE . " WHERE tipp_user = $user_id ORDER BY tipp_id ASC";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_tipps = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		if ( $calculate == 0 )
		{
			$wm_tipps[$row['tipp_user']][$row['tipp_game']] = $row;
		}
		else
		{
			$wm_tipps[$row['tipp_game']][] = $row;
		}
	}
	$db->sql_freeresult($result);
	return $wm_tipps;
}

// Get wm games data
function get_wm_games($team_home = 0, $team_away = 0, $by_row = 0)
{
	global $db;
	// Get all teams
	$teamsdata = get_wm_teams();
	//
	// Get games data
	//
	if ( $team_home == 0 )
	{
		$sql = "SELECT * FROM  " . WM_GAMES_TABLE . " ORDER BY game_time ASC";
	}
	else
	{
		$sql = "SELECT * FROM  " . WM_GAMES_TABLE . " WHERE (game_home = $team_home AND game_away = $team_away) OR (game_home = $team_away AND game_away = $team_home)";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get games data', '', __LINE__, __FILE__, $sql);
	}
	$gamesdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		if ( $team_home == 0 && $by_row == 0)
		{
			$row['game_group'] = $teamsdata[$row['game_home']]['team_group'];
			$gamesdata[$row['game_group']][] = $row;
		}
		else
		{
			$gamesdata[] = $row;
		}
	}
	$db->sql_freeresult($result);
	ksort($gamesdata);
	return $gamesdata;
}

// Get wm finals data
function get_wm_finalgames()
{
	global $db, $lang;
	// Get all teams
	$resultsdata = get_wm_results();
	$configdata  = get_wm_config();
	//
	// Get games data
	//
	$sql = "SELECT * FROM  " . WM_FINALS_TABLE . " ORDER BY game_time ASC";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get finals data', '', __LINE__, __FILE__, $sql);
	}
	$gamesdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		if ( $row['game_id'] < 57 )
		{
			$pseudo_group = $lang['l_wm_achtelfinale'];
			$row['game_home'] = ( $configdata[$row['game_home']] != '' ) ? $configdata[$row['game_home']] : 0;
			$row['game_away'] = ( $configdata[$row['game_away']] != '' ) ? $configdata[$row['game_away']] : 0;
		}
		else if ( $row['game_id'] < 61 )
		{
			$pseudo_group = $lang['l_wm_viertelfinale'];
			$row['game_home'] = ( isset($resultsdata[$row['game_home']]) ) ? $resultsdata[$row['game_home']]['final_winner'] : 0;
			$row['game_away'] = ( isset($resultsdata[$row['game_away']]) ) ? $resultsdata[$row['game_away']]['final_winner'] : 0;
		}
		else if ( $row['game_id'] < 63 )
		{
			$pseudo_group = $lang['l_wm_halbfinale'];
			$row['game_home'] = ( isset($resultsdata[$row['game_home']]) ) ? $resultsdata[$row['game_home']]['final_winner'] : 0;
			$row['game_away'] = ( isset($resultsdata[$row['game_away']]) ) ? $resultsdata[$row['game_away']]['final_winner'] : 0;
		}
		else if ( $row['game_id'] < 64 )
		{
			$pseudo_group = $lang['l_wm_kleinesfinale'];
			$row['game_home'] = ( isset($resultsdata[$row['game_home']]) ) ? $resultsdata[$row['game_home']]['final_loser'] : 0;
			$row['game_away'] = ( isset($resultsdata[$row['game_away']]) ) ? $resultsdata[$row['game_away']]['final_loser'] : 0;
		}
		else
		{
			$pseudo_group = $lang['l_wm_finale'];
			$row['game_home'] = ( isset($resultsdata[$row['game_home']]) ) ? $resultsdata[$row['game_home']]['final_winner'] : 0;
			$row['game_away'] = ( isset($resultsdata[$row['game_away']]) ) ? $resultsdata[$row['game_away']]['final_winner'] : 0;
		}
		$row['game_group'] = $pseudo_group;
		$gamesdata[$pseudo_group][] = $row;
	}
	$db->sql_freeresult($result);
	return $gamesdata;
}

// Get wm results data
function get_wm_results($game_id = 0, $by_row = 0)
{
	global $db;
	//
	// Get results data
	//
	if ( $game_id == 0 )
	{
		$sql = "SELECT * FROM  " . WM_RESULTS_TABLE . " ORDER BY result_game ASC";
	}
	else
	{
		$sql = "SELECT * FROM  " . WM_RESULTS_TABLE . " WHERE result_game = $game_id";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get results data', '', __LINE__, __FILE__, $sql);
	}
	$resultsdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		if ( $game_id == 0 && $by_row == 0)
		{
			$resultsdata[$row['result_game']] = $row;
		}
		else
		{
			$resultsdata[] = $row;
		}
	}
	$db->sql_freeresult($result);
	return $resultsdata;
}

// Get teams order by teamname as row
function get_wm_teams_as_row()
{
	global $db;
	//
	// Get teams data
	//
	$sql = "SELECT * FROM  " . WM_TEAMS_TABLE . " ORDER BY team_name";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get teams data', '', __LINE__, __FILE__, $sql);
	}
	$resultsdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$resultsdata[] = $row;
	}
	$db->sql_freeresult($result);
	return $resultsdata;
}

// Saves a users WM tipp
function save_wm_tipp($user_id, $tipped_winner,$tipped_scorer)
{
	global $db, $lang;
	$first_game      = get_first_game();
	$first_game_time = $first_game[0]['game_time'];
	$current_time = time();
	$wm_config    = array();  // Config values
	$wm_config    = get_wm_config();
	$wmtipp_delay = $wm_config['wmtipp_delay'];
	if ( $current_time < $first_game_time + $wmtipp_delay * 86400 )
	{
		//
		// Delete old wm tipp
		//
		$sql = "DELETE FROM " . WM_TIPPS_TABLE . " WHERE tipp_user = $user_id AND tipp_game = 65";
		if( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not delete wm tip', '', __LINE__, __FILE__, $sql);
		}
		$sql = "DELETE FROM " . WM_TJAEGERTIPPS_TABLE . " WHERE userid = $user_id";
		if( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not delete wm scorer', '', __LINE__, __FILE__, $sql);
		}
		//
		// Insert wm tipp
		//
		if ( $tipped_winner != 0 && $tipped_scorer != 0 )
		{
			$sql = "INSERT INTO " . WM_TIPPS_TABLE . " (tipp_user,tipp_game,tipp_home, game_time, tipp_time) VALUES ($user_id, 65, $tipped_winner, $first_game_time, $current_time)";
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not insert wm tip', '', __LINE__, __FILE__, $sql);
			}
		}
		if ( $tipped_winner != 0 && $tipped_scorer != 0 )
		{
			$sql = "INSERT INTO " . WM_TJAEGERTIPPS_TABLE . " (userid, spielerid) VALUES ($user_id, $tipped_scorer)";
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not insert wm scorer', '', __LINE__, __FILE__, $sql);
			}
		}
	}
}

// Get first games data
function get_first_game()
{
	global $db;
	//
	// Get games data
	//
	$sql = "SELECT * FROM  " . WM_GAMES_TABLE . " ORDER BY game_time ASC LIMIT 1";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get games data', '', __LINE__, __FILE__, $sql);
	}
	$resultsdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$resultsdata[] = $row;
	}
	$db->sql_freeresult($result);
	return $resultsdata;
}

// Clear results table
function clear_result($game_id)
{
	global $db;
	//
	// Clear results data
	//
	$sql = "DELETE FROM " . WM_RESULTS_TABLE . " WHERE result_game = " . $game_id;
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not reset result data', '', __LINE__, __FILE__, $sql);
	}
}

// Clear tipps table for a user
function clear_tipps($user_id, $finals = 0)
{
	global $db;
	$current_time = time();
	//
	// Clear usertipps data
	//
	if ( $finals == 0 )
	{
		$sql = "DELETE FROM " . WM_TIPPS_TABLE . " WHERE tipp_user = $user_id AND tipp_game < 49 AND game_time > $current_time";
	}
	else
	{
		$sql = "DELETE FROM " . WM_TIPPS_TABLE . " WHERE tipp_user = $user_id AND tipp_game > 48 AND tipp_game <> 65 AND game_time > $current_time";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not reset usertipps data', '', __LINE__, __FILE__, $sql);
	}
}

// Save wm results data
function save_result($game_id, $home_val, $away_val, $winner = 0, $loser = 0, $status = 0)
{
	global $db;
	//
	// Update results data
	//
	if ( $winner == 0 )
	{
		$sql = "INSERT INTO " . WM_RESULTS_TABLE . " (result_game,result_home,result_away,result_status) VALUES ($game_id,$home_val,$away_val,$status)";
	}
	else
	{
		$sql = "INSERT INTO " . WM_RESULTS_TABLE . " (result_game,result_home,result_away,final_winner,final_loser,result_status  ) VALUES ($game_id,$home_val,$away_val,$winner,$loser,$status)";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update results data', '', __LINE__, __FILE__, $sql);
	}
}

// Save teams points and goals
function save_points($teampoints, $teamgoals, $teamgotgoals)
{
	global $db;
	$teams_data = get_wm_teams();
	for ( $h = 0; $h < count($teams_data); $h++ )
	{
		//
		// Update teams data
		//
		if ( isset($teampoints[$teams_data[$h]['team_id']]) )
		{
			$sql = "UPDATE " . WM_TEAMS_TABLE . "
		SET team_points = " . $teampoints[$teams_data[$h]['team_id']] . ", team_goals = " . $teamgoals[$teams_data[$h]['team_id']] . ", team_gotgoals = " . $teamgotgoals[$teams_data[$h]['team_id']] . "
		WHERE team_id = " . $teams_data[$h]['team_id'];
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not update teams data', '', __LINE__, __FILE__, $sql);
			}
		}
	}
}

// Save user tipps data
function save_tipp($game_id, $user_id, $home_val, $away_val, $tipp_time, $game_time)
{
	global $db;
	//
	// Update tipps data
	//
	$sql = "INSERT INTO " . WM_TIPPS_TABLE . " (tipp_game,game_time,tipp_time,tipp_user,tipp_home,tipp_away) VALUES ($game_id,$game_time,$tipp_time,$user_id,$home_val,$away_val)";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update tipps data', '', __LINE__, __FILE__, $sql);
	}
}

// Sorts a grouparray for the standings
function sort_standings($teams, $teams_data, $results_data, $games_data)
{
	$sorted_teams = array();
	for ( $z = 0; $z < count($teams); $z++ )
	{
		$sorted_teams = insert_team($sorted_teams, $teams[$z], $teams_data, $games_data, $results_data);
	}
	return $sorted_teams;
}

// Inserts a team (needed for sort_standings())
function insert_team($standings_array, $team_id, $teams_data, $games_data, $results_data)
{
	$new_standings_array = array();
	for ( $k = 0; $k < count($standings_array); $k++ )
	{
		$team_id_old     = $standings_array[$k];
		$team_id_new     = $team_id;
		$team_data_old   = $teams_data[$team_id_old];
		$team_data_new   = $teams_data[$team_id_new];
		$team_points_old = $team_data_old['team_points'];
		$team_points_new = $team_data_new['team_points'];
		if ( $team_points_old < $team_points_new )
		{
			$team_id = $team_id_old;
			$standings_array[$k] = $team_id_new;
		}
		else if ( $team_points_old == $team_points_new )
		{
			$new_standings_array = find_winner_on_deuce($team_id_new, $team_id_old, $games_data, $results_data, $teams_data);
			$team_id = $new_standings_array[1];
			$standings_array[$k] = $new_standings_array[0];
		}
	}
	$standings_array[] = $team_id;
	return $standings_array;
}

// Filters games array
function get_wm_spec_game($team_home, $team_away, $games_data)
{
	for ( $t = 0; $t < 49; $t++ )
	{
		if ( ($games_data[$t]['game_home'] == $team_home && $games_data[$t]['game_away'] == $team_away) || ($games_data[$t]['game_home'] == $team_away && $games_data[$t]['game_away'] == $team_home) )
		{
			return $games_data[$t];
		}
	}
	return array();
}

// Sorts a grouparray for the standings
function find_winner_on_deuce($team_id_new, $team_id_old, $games_data, $results_data, $teams_data)
{
	$game_data    = get_wm_spec_game($team_id_new, $team_id_old, $games_data);
	$game_results = $results_data[$game_data['game_id']];
	$team_in_order = array();
	if ( $game_results['result_home'] > $game_results['result_away']  )
	{
		$team_in_order[] = $game_data['game_home'];
		$team_in_order[] = $game_data['game_away'];
	}
	else if ( $game_results['result_home'] < $game_results['result_away']  )
	{
		$team_in_order[] = $game_data['game_away'];
		$team_in_order[] = $game_data['game_home'];
	}
	else
	{
		$teamdata_home = $teams_data[$game_data['game_home']];
		$teamdata_away = $teams_data[$game_data['game_away']];
		if ( ($teamdata_home['team_goals']-$teamdata_home['team_gotgoals']) > ($teamdata_away['team_goals']-$teamdata_away['team_gotgoals'])  )
		{
			$team_in_order[] = $game_data['game_home'];
			$team_in_order[] = $game_data['game_away'];
		}
		else if ( ($teamdata_home['team_goals']-$teamdata_home['team_gotgoals']) < ($teamdata_away['team_goals']-$teamdata_away['team_gotgoals'])  )
		{
			$team_in_order[] = $game_data['game_away'];
			$team_in_order[] = $game_data['game_home'];
		}
		else
		{
			if ( $teamdata_home['team_goals'] > $teamdata_away['team_goals']  )
			{
				$team_in_order[] = $game_data['game_home'];
				$team_in_order[] = $game_data['game_away'];
			}
			else if ( $teamdata_home['team_goals'] < $teamdata_away['team_goals']  )
			{
				$team_in_order[] = $game_data['game_away'];
				$team_in_order[] = $game_data['game_home'];
			}
			else
			{
				// When this code is reached, the UEFA has to define winners by a random selection. I just use defaults in here.
				// Correct gorup winners in ACP.
				$team_in_order[] = $team_id_old;
				$team_in_order[] = $team_id_new;
			}
		}
	}
	return $team_in_order;
}

// Checks and sets group winners to config
function check_group_winners()
{
	global $wm_config, $table_teams, $teams_data, $results_data, $games_for_sort;
	$groups_row   = array();
	$groups_row[] = 'A';
	$groups_row[] = 'B';
	$groups_row[] = 'C';
	$groups_row[] = 'D';
	$groups_row[] = 'E';
	$groups_row[] = 'F';
	$groups_row[] = 'G';
	$groups_row[] = 'H';
	$statusA = true;
	$statusB = true;
	$statusC = true;
	$statusD = true;
	$statusE = true;
	$statusF = true;
	$statusG = true;
	$statusH = true;
	for ( $g = 1; $g < 49; $g++ )
	{
		if ( $g < 7 )
		{
			$statusA = ( !isset($results_data[$g]) ) ? false : $statusA;
		}
		else if ( $g < 13 )
		{
			$statusB = ( !isset($results_data[$g]) ) ? false : $statusB;
		}
		else if ( $g < 19 )
		{
			$statusC = ( !isset($results_data[$g]) ) ? false : $statusC;
		}
		else if ( $g < 25 )
		{
			$statusD = ( !isset($results_data[$g]) ) ? false : $statusD;
		}
		else if ( $g < 31 )
		{
			$statusE = ( !isset($results_data[$g]) ) ? false : $statusE;
		}
		else if ( $g < 37 )
		{
			$statusF = ( !isset($results_data[$g]) ) ? false : $statusF;
		}
		else if ( $g < 43 )
		{
			$statusG = ( !isset($results_data[$g]) ) ? false : $statusG;
		}
		else if ( $g < 49 )
		{
			$statusH = ( !isset($results_data[$g]) ) ? false : $statusH;
		}
	}
	if ( $statusA )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[0]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wa'] !=  $sorted_table_teams[0] || $wm_config['ra'] !=  $sorted_table_teams[1] )
		{
			set_winner('wa', 'ra', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wa'] !=  '' || $wm_config['ra'] !=  '' )
		{
			clear_winner('wa', 'ra');
		}
	}
	if ( $statusB )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[1]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wb'] !=  $sorted_table_teams[0] || $wm_config['rb'] !=  $sorted_table_teams[1] )
		{
			set_winner('wb', 'rb', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wb'] !=  '' || $wm_config['rb'] !=  '' )
		{
			clear_winner('wb', 'rb');
		}
	}
	if ( $statusC )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[2]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wc'] !=  $sorted_table_teams[0] || $wm_config['rc'] !=  $sorted_table_teams[1] )
		{
			set_winner('wc', 'rc', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wc'] !=  '' || $wm_config['rc'] !=  '' )
		{
			clear_winner('wc', 'rc');
		}
	}
	if ( $statusD )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[3]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wd'] !=  $sorted_table_teams[0] || $wm_config['rd'] !=  $sorted_table_teams[1] )
		{
			set_winner('wd', 'rd', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wd'] !=  '' || $wm_config['rd'] !=  '' )
		{
			clear_winner('wd', 'rd');
		}
	}
	if ( $statusE )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[4]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['we'] !=  $sorted_table_teams[0] || $wm_config['re'] !=  $sorted_table_teams[1] )
		{
			set_winner('we', 're', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['we'] !=  '' || $wm_config['re'] !=  '' )
		{
			clear_winner('we', 're');
		}
	}
	if ( $statusF )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[5]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wf'] !=  $sorted_table_teams[0] || $wm_config['rf'] !=  $sorted_table_teams[1] )
		{
			set_winner('wf', 'rf', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wf'] !=  '' || $wm_config['rf'] !=  '' )
		{
			clear_winner('wf', 'rf');
		}
	}
	if ( $statusG )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[6]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wg'] !=  $sorted_table_teams[0] || $wm_config['rg'] !=  $sorted_table_teams[1] )
		{
			set_winner('wg', 'rg', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wg'] !=  '' || $wm_config['rg'] !=  '' )
		{
			clear_winner('wg', 'rg');
		}
	}
	if ( $statusH )
	{
		$sorted_table_teams = sort_standings($table_teams[$groups_row[7]], $teams_data, $results_data, $games_for_sort);
		if ( $wm_config['wh'] !=  $sorted_table_teams[0] || $wm_config['rh'] !=  $sorted_table_teams[1] )
		{
			set_winner('wh', 'rh', $sorted_table_teams[0], $sorted_table_teams[1]);
		}
	}
	else
	{
		if ( $wm_config['wh'] !=  '' || $wm_config['rh'] !=  '' )
		{
			clear_winner('wh', 'rh');
		}
	}
}

// Clears group winners from config
function clear_winner($short_winner, $short_second)
{
	global $db;
	//
	// Update group winners data
	//
	$sql  = "UPDATE " . WM_CONFIG_TABLE . "
	SET config_value = ''
	WHERE config_name = '$short_winner'";
	$sql2 = "UPDATE " . WM_CONFIG_TABLE . "
	SET config_value = ''
	WHERE config_name = '$short_second'";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update config data', '', __LINE__, __FILE__, $sql);
	}
	if( !($result = $db->sql_query($sql2)) )
	{
		message_die(GENERAL_ERROR, 'Could not update config data', '', __LINE__, __FILE__, $sql);
	}
}

// Clears group winners from config
function set_winner($short_winner, $short_second, $winner_id, $second_id)
{
	global $db;
	//
	// Update group winners data
	//
	$sql  = "UPDATE " . WM_CONFIG_TABLE . "
	SET config_value = '$winner_id'
	WHERE config_name = '$short_winner'";
	$sql2 = "UPDATE " . WM_CONFIG_TABLE . "
	SET config_value = '$second_id'
	WHERE config_name = '$short_second'";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update config data', '', __LINE__, __FILE__, $sql);
	}
	if( !($result = $db->sql_query($sql2)) )
	{
		message_die(GENERAL_ERROR, 'Could not update config data', '', __LINE__, __FILE__, $sql);
	}
}

// Generates the group winner comboboxes for wm config
function build_group_winner_combo($game_ac, $selected_entry, $teams_data, $str_group = "")
{
	global $lang;
	$selected = ( $selected_entry == '' ) ? ' selected' : '';
	$entries = '<option value="" ' . $selected . '>' . $lang['wm_acp_not_found'] . '</option>';
	for ( $u = 0; $u < count($teams_data); $u++ )
	{
		if (empty($str_group) || $str_group == $teams_data[$u]['team_group'])
		{
			$selected = ( $teams_data[$u]['team_id'] == $selected_entry ) ? ' selected' : '';
			$entries .= '<option value="' . $teams_data[$u]['team_id'] . '" ' . $selected . '>' . $teams_data[$u]['team_name'] . '</option>';
		}
	}
	$combo  = '<select name="' . $game_ac . '">';
	$combo .= $entries;
	$combo .= '</select>';
	return $combo;
}

// Get wm auth status
function get_wm_auth()
{
	global $db, $wm_config, $userdata;
	$access_group = $wm_config['restrict_to'];
	$sql = "SELECT g.group_id FROM " . GROUPS_TABLE . " g, " . USER_GROUP_TABLE . " ug
	WHERE g.group_id = ug.group_id
	AND ug.user_id = " . $userdata['user_id'] . "
	AND ug.user_pending <> " . TRUE . "
	AND g.group_single_user <> " . TRUE . "
	AND g.group_id = $access_group";
	if ( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, 'Could not get wm auth data', '', __LINE__, __FILE__, $sql);
	}
	$check_wm_auth = $db->sql_numrows($result);
	$db->sql_freeresult($result);
	if ( $check_wm_auth != 0 )
	{
		return TRUE;
	}
	return FALSE;
}

// Calculate user points
function calculate_user_points($user_id = 0)
{
	global $db, $wm_config;
	// Reset all tippoints
	if ( $user_id == 0 )
	{
		$sql = "UPDATE " . WM_TIPPS_TABLE . " SET tipp_points = 0";
	}
	else
	{
		$sql = "UPDATE " . WM_TIPPS_TABLE . " SET tipp_points = 0 WHERE tipp_user = $user_id";
	}
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not update tipps data', '', __LINE__, __FILE__, $sql);
	}
	$wm_results = get_wm_results(0,1);
	$wm_tipps   = get_wm_tipps(1, $user_id);
	for ( $i = 0; $i < count($wm_results); $i++ )
	{
		$trefferalone =  array();
		unset($trefferalone) ;
		$current_game_id = $wm_results[$i]['result_game'];
		$result_home     = $wm_results[$i]['result_home'];
		$result_away     = $wm_results[$i]['result_away'];
		for ( $u = 0; $u < count($wm_tipps[$current_game_id]); $u++ )
		{
			$tipp_home   = $wm_tipps[$current_game_id][$u]['tipp_home'];
			$tipp_away   = $wm_tipps[$current_game_id][$u]['tipp_away'];
			$tipp_points = $wm_tipps[$current_game_id][$u]['tipp_points'];
			$tipp_new_points = 0;
			if ( $current_game_id != 65 )
			{
				if ( $tipp_home == $result_home && $tipp_away == $result_away )
				{
					$tipp_new_points = $wm_config['points_match'];
					$trefferalone[] = $wm_tipps[$current_game_id][$u]['tipp_id'];
				}
				else if ( $tipp_home - $tipp_away == $result_home - $result_away )
				{
					$tipp_new_points = $wm_config['points_tordiff'];
				}
				else if ( ($tipp_home > $tipp_away && $result_home > $result_away) || ($tipp_home < $tipp_away && $result_home < $result_away) )
				{
					$tipp_new_points = $wm_config['points_tendency'];
				}
			}
			else
			{
				$tipp_new_points=0;
				if ( $tipp_home == $result_home )
				{
					$tipp_new_points = $wm_config['points_winner'];
				}
				//Torj�ger
				$torjaegerpoints = 0;
				$sql = "SELECT userid FROM " . WM_TJAEGERTIPPS_TABLE . " u, " . WM_TJAEGER_TABLE . " t, " . WM_TIPPS_TABLE . " v WHERE u.spielerid = t.spielerid AND 
                        u.userid = v.tipp_user AND v.tipp_id = " . $wm_tipps[$current_game_id][$u]['tipp_id'] . " AND t.isking = 1";
				if( !$result = $db->sql_query($sql) )
				{ 
					message_die(GENERAL_ERROR, $lang['tipp_Sql_Error'], $lang['Error'], __LINE__, __FILE__, $sql);
				} 
				if ($db->sql_numrows($result) > 0) 
				{ 
					$tipp_new_points = $tipp_new_points + $wm_config['points_winnerscorer']; 
				}
			}
			if ( $tipp_new_points != $tipp_points )
			{
				$sql = "UPDATE " . WM_TIPPS_TABLE . " SET tipp_points = $tipp_new_points WHERE tipp_id = " . $wm_tipps[$current_game_id][$u]['tipp_id'];
				if( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update tipps data', '', __LINE__, __FILE__, $sql);
				}
			}
		}
		if (count($trefferalone) == 1 && $wm_config['user_trefferalone'] && $user_id == 0)
		{
			$sql = "UPDATE " . WM_TIPPS_TABLE . " SET tipp_points = tipp_points + " . $wm_config['points_trefferalone'] . "	WHERE tipp_id = " . $trefferalone[0];
			if( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not update tipps data', '', __LINE__, __FILE__, $sql);
			}
		}
	}
}

// get users wm winner tipp
function get_wm_winner($user_id)
{
	global $db;
	$sql = "SELECT * FROM " . WM_TIPPS_TABLE . " WHERE tipp_game = 65 AND tipp_user = " . $user_id;
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get tipps data', '', __LINE__, __FILE__, $sql);
	}
	$winnerdata = 0;
	while ( $row = $db->sql_fetchrow($result) )
	{
		$winnerdata = $row['tipp_home'];
	}
	$db->sql_freeresult($result);
	return $winnerdata;
}

function get_wm_champion_tipps()
{
	global $db;
	$sql = "SELECT * FROM " . WM_TIPPS_TABLE . " WHERE tipp_game = 65";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get tipps data', '', __LINE__, __FILE__, $sql);
	}
	$championsdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$championsdata[$row['tipp_user']] = $row['tipp_home'];
	}
	$db->sql_freeresult($result);
	return $championsdata;
}

function get_wm_scorer_tipps()
{
	global $db;
	$sql = "SELECT userid, concat(Vorname, ' ', Name) as Name FROM " . WM_TJAEGERTIPPS_TABLE . " inner join " . WM_TJAEGER_TABLE . "  on " . WM_TJAEGER_TABLE . ".spielerid =  " . WM_TJAEGERTIPPS_TABLE . ".spielerid";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get tipps data', '', __LINE__, __FILE__, $sql);
	}
	$scorerdata = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$scorerdata[$row['userid']] = $row['Name'];
	}
	$db->sql_freeresult($result);
	return $scorerdata;
}

function get_first_gametime($boo_finals = false)
{
	global $db;
	$str_table = ($boo_finals) ? WM_FINALS_TABLE : WM_GAMES_TABLE;
	$sql = "SELECT game_time FROM  " . $str_table . " ORDER BY game_time LIMIT 1";
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get game data', '', __LINE__, __FILE__, $sql);
	}
	$row = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);
	return $row['game_time'];
}
?>