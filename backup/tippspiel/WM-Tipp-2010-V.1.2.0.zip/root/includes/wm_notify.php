<?php
/***************************************************************************
 *                       wm_notify.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) B.Funke (buegelfalte)
 *   URL              : http://forum.beehave.de
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

/* This MOD uses the "insert_post"-function, written by Adrian Cockburn, see below for details */


if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
}
// include phpBB-functions
include_once($phpbb_root_path.'includes/bbcode.'.$phpEx);
include_once($phpbb_root_path.'includes/functions_post.'.$phpEx);
include_once($phpbb_root_path.'includes/functions_search.'.$phpEx);

// include WM-MOD-functions & language
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);
include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

// Init arrays
$wm_config     = array();  // Config values
$wm_users_data = array();  // All userdata from users with at least 1 WM point
$all_user_data = array();

// Load data
$wm_config     = get_wm_config();
$wm_users_data = get_wm_users();
$wm_users_data_special = get_wm_usersspecial();
$all_user_data = get_all_the_users();

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

// check which table/path to use
$str_dbtable = (date("Ymd") < $wm_config['notify_finalstart']) ? WM_GAMES_TABLE : WM_FINALS_TABLE;

// create path to the MOD
$server_protocol = ($board_config['cookie_secure']) ? 'https://' : 'http://';
$server_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['server_name']));
$server_port = ($board_config['server_port'] <> 80) ? ':' . trim($board_config['server_port']) . '/' : '/';
$script_name = preg_replace('#^\/?(.*?)\/?$#', '\1', trim($board_config['script_path']));
$script_name = ($script_name != '') ? $script_name . '/' : '/';
$str_wmpath = $server_protocol . $server_name . $server_port . $script_name;
$str_wmpath .= (date("Ymd") < $wm_config['notify_finalstart']) ? 'wm_round1.'.$phpEx : 'wm_finals.'.$phpEx;

// delete tipps of deleted users ?
if ($wm_config['delete_tipps'])
{
	$str_userids = "";
	$sql = "SELECT user_id FROM " . USERS_TABLE;
	if (!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
	}
	while ($row = $db->sql_fetchrow($result))
	{
		$str_userids .= (empty($str_userids)) ? $row['user_id'] : ",".$row['user_id'];
	}
	$sql = "DELETE FROM " . WM_TIPPS_TABLE . " WHERE tipp_user NOT IN (".$str_userids.")";
	if (!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
	}
	$str_display .= $db->sql_affectedrows()." tips of deleted users have been removed.<br />";
	$sql = "DELETE FROM " . WM_TJAEGERTIPPS_TABLE . " WHERE userid NOT IN (".$str_userids.")";
	if (!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
	}
	$str_display .= $db->sql_affectedrows()." Torj�ger-tips of deleted users have been removed.<br />";
}

$subject = str_replace("%a%", date("d.m.Y") , $lang['notify_subject']);
$rangintro = str_replace("%b%", date("d.m.Y H:i") , $lang['notify_rangintro']);
$rangoutro = str_replace("%c%", $wm_config['notify_ranksize'] , $lang['notify_rangoutro']);
$rangintro_special = str_replace("%d%", date("d.m.Y H:i") , $lang['notify_rangintro_special']);
$rangoutro_special = str_replace("%e%", $wm_config['notify_ranksize'] , $lang['notify_rangoutro_special']);

// post ranklist ?
if (($wm_config['notify_post_rankmsg']) && ($wm_config['wm_forum_id'] != 0))
{
	// check for new games since the last posting
	$sql = "SELECT wg.game_id FROM ".WM_GAMES_TABLE." wg, ".WM_FINALS_TABLE." wf WHERE (wg.game_time > ".intval($wm_config['notify_last_ranklist'])." AND wg.game_time < ".time().") OR (wf.game_time > ".intval($wm_config['notify_last_ranklist'])." AND wf.game_time < ".time().") LIMIT 0,1";
	if (!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
	}
	if ($db->sql_numrows($result) > 0)
	{
		$str_message = $rangintro.'[code]'.$lang['l_wm_stats_pos'].'   '.$lang['l_wm_stats_points'].'   '.$lang['l_wm_stats_user'].'
';
		// Users loop
		$int_userpkt = -1;
		$int_userpos = 0;
		for($i=0;$i<min($wm_config['notify_ranksize'],count($wm_users_data));$i++)
		{
			$int_userposalt = $int_userpos;
			$int_userpos = ($int_userpkt != $wm_users_data[$i]['user_points']) ? $i + 1 : $int_userpos;
			$str_message .= str_repeat(" ",3-strlen($int_userpos));
			$str_message .= ($int_userpos != $int_userposalt) ? $int_userpos : str_repeat(" ",strlen($int_userpos));
			$str_message .= str_repeat(" ",strlen($lang['l_wm_stats_pos'])+3).$wm_users_data[$i]['user_points'];
			$str_message .= str_repeat(" ",strlen($lang['l_wm_stats_points'])-strlen($wm_users_data[$i]['user_points'])+2).$all_user_data[$wm_users_data[$i]['tipp_user']].'
';
			$int_userpkt = $wm_users_data[$i]['user_points'];
		}
		$str_message .= '[/code]'.$rangoutro;
		insert_post($str_message, $subject, $wm_config['wm_forum_id'], $admin_id, $all_user_data[$admin_id], true, 0, $wm_config['notify_reply_topic'], POST_NORMAL, true, true, '', 0, 1, 0);
		$str_display = "Ranklist has been posted.<br />";
		// remember posting-date
		if (!empty($wm_config['notify_last_ranklist']))
		{
			$sql = "UPDATE ".WM_CONFIG_TABLE." SET config_value = ".time()." WHERE config_name = 'notify_last_ranklist'";
		}
		else
		{
			$sql = "INSERT INTO ".WM_CONFIG_TABLE." (config_name, config_value) VALUES ('notify_last_ranklist', ".time().")";
		}
		if (!($result = $db->sql_query($sql)))
		{
			message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
		}
	}
	else
	{
		$str_display = "No new games since last ranklist-posting<br />";
	}
}

// post ranklist for special group?
if (($wm_config['notify_post_rankmsg']) && ($wm_config['wm_forum_special_id'] != 0))
{
	// check for new games since the last posting
	$sql = "SELECT wg.game_id FROM ".WM_GAMES_TABLE." wg, ".WM_FINALS_TABLE." wf
	WHERE (wg.game_time > ".intval($wm_config['notify_last_ranklist'])." AND wg.game_time < ".time().") OR
	(wf.game_time > ".intval($wm_config['notify_last_ranklist'])." AND wf.game_time < ".time().")
	LIMIT 0,1";
	if (!($result = $db->sql_query($sql)))
	{
		message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
	}
	if ($db->sql_numrows($result) > 0)
	{
		$str_message = $rangintro_special.'[code]'.$lang['l_wm_stats_pos'].'   '.$lang['l_wm_stats_points'].'   '.$lang['l_wm_stats_user'].'
';
		// Users loop
		$int_userpkt = -1;
		$int_userpos = 0;
		for($i=0;$i<min($wm_config['notify_ranksize'],count($wm_users_data_special));$i++)
		{
			$int_userposalt = $int_userpos;
			$int_userpos = ($int_userpkt != $wm_users_data_special[$i]['user_points']) ? $i + 1 : $int_userpos;
			$str_message .= str_repeat(" ",3-strlen($int_userpos));
			$str_message .= ($int_userpos != $int_userposalt) ? $int_userpos : str_repeat(" ",strlen($int_userpos));
			$str_message .= str_repeat(" ",strlen($lang['l_wm_stats_pos'])+3).$wm_users_data_special[$i]['user_points'];
			$str_message .= str_repeat(" ",strlen($lang['l_wm_stats_points'])-strlen($wm_users_data_special[$i]['user_points'])+2).$all_user_data[$wm_users_data_special[$i]['tipp_user']].'
';
			$int_userpkt = $wm_users_data_special[$i]['user_points'];
		}
		$str_message .= '[/code]'.$rangoutro_special;
		insert_post($str_message, $subject, $wm_config['wm_forum_special_id'], $admin_id, $all_user_data[$admin_id], true, 0, $wm_config['notify_reply_special_topic'], POST_NORMAL, true, true, '', 0, 1, 0);
		$str_display .= "Special-Ranklist has been posted.<br />";
		// remember posting-date
		if (!empty($wm_config['notify_last_ranklist']))
		{
			$sql = "UPDATE ".WM_CONFIG_TABLE." SET config_value = ".time()." WHERE config_name = 'notify_last_ranklist'";
		}
		else
		{
			$sql = "INSERT INTO ".WM_CONFIG_TABLE." (config_name, config_value) VALUES ('notify_last_ranklist', ".time().")";
		}
		if (!($result = $db->sql_query($sql)))
		{
			message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
		}
	}
	else
	{
		$str_display = "No new games since last ranklist-posting.<br />";
	}
}

// remind users with an eMail ?
if ($wm_config['notify_write_mails'])
{
	// games today ?
	$today_start	= mktime(0, 0, 1, date("m"), date("d"), date("Y"));
	$today_end		= $today_start + 86398;
	if ($wm_config['notify_last_reminder'] < $today_start)
	{
		$sql = "SELECT game_id FROM ".$str_dbtable." WHERE game_time >= ".$today_start." AND game_time <= ".$today_end;
		if (!($result = $db->sql_query($sql)))
		{
			message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
		}
		if ($db->sql_numrows($result) > 0)
		{
			$count_emails = 0;
			$game_ids = "";
			$int_gameanz = $db->sql_numrows($result);
			while ($row = $db->sql_fetchrow($result))
			{
				$game_ids .= (empty($game_ids)) ? $row['game_id'] : ','.$row['game_id'];
			}
			if (!class_exists('emailer'))
			{
				include($phpbb_root_path . 'includes/emailer.'.$phpEx);
			}
			// get moderators name & email-address
			$sql = "SELECT username, user_email FROM " . USERS_TABLE . " WHERE user_id = ".$admin_id;
			if (!($result = $db->sql_query($sql)))
			{
				message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
			}
			$row_wmmod = $db->sql_fetchrow($result);
			// get all users in WM-group
			$sql = "SELECT u.user_id, u.username, u.user_email, u.user_lang FROM " . USERS_TABLE . " u, " . GROUPS_TABLE . " g, " . USER_GROUP_TABLE . " ug WHERE 
			g.group_id = '".$wm_config['restrict_to']."' AND ug.group_id = g.group_id AND u.user_id = ug.user_id AND ug.user_pending = 0";
			if (!($result = $db->sql_query($sql)))
			{
				message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
			}
			while ($row = $db->sql_fetchrow($result))
			{
				// tipps placed for todays games ?
				$sql_tipp = "SELECT tipp_id FROM ".WM_TIPPS_TABLE."	WHERE tipp_game IN (".$game_ids.") AND tipp_user = ".$row['user_id'];
				if (!($result_tipp = $db->sql_query($sql_tipp)))
				{
					message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_tipp);
				}
				if ($db->sql_numrows($result_tipp) < $int_gameanz)
				{
					$count_emails++;
					$emailer = new emailer($board_config['smtp_delivery']);
					$emailer->from($row_wmmod['user_email']);
					$emailer->use_template("wmnotify", stripslashes($row['user_lang']));
					$emailer->email_address($row['user_email']);
					$emailer->assign_vars(array(
					'FORUM_NAME' => $board_config['sitename'],
					'USERNAME' => wmnotify_prepare_smusername($row['username']),
					'MODNAME' => $row_wmmod['username'],
					'MODLINK' => $str_wmpath,
					'EMAIL_SIG' => (!empty($board_config['board_email_sig'])) ? str_replace('<br />', "\n", "-- \n" . $board_config['board_email_sig']) : '')
					);
					$emailer->send();
					$emailer->reset();
				}
			}
			if ($count_emails)
			{
				$str_display .= $count_emails." eMails have been sent.<br />";
				// remember last mail
				if (!empty($wm_config['notify_last_reminder']))
				{
					$sql = "UPDATE ".WM_CONFIG_TABLE." SET config_value = ".time()." WHERE config_name = 'notify_last_reminder'";
				}
				else
				{
					$sql = "INSERT INTO ".WM_CONFIG_TABLE." (config_name, config_value) VALUES ('notify_last_reminder', ".time().")";
				}
				if (!($result = $db->sql_query($sql)))
				{
					message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql);
				}
			}
		}
	}
	else
	{
		$str_display .= "eMails have alredy been sent today.<br />";
	}
}

// exit with status message of what has been done
message_die(GENERAL_MESSAGE, $str_display);

// returns HTML-username back to normal
function wmnotify_prepare_smusername($username)
{
	$username = preg_replace("/&gt;/i", ">", $username);
	$username = preg_replace("/&lt;/i", "<", $username);
	$username = preg_replace("/&quot;/i", "\"", $username);
	$username = preg_replace("/&amp;/i", "&", $username);
	return $username;
}

// gets an email-address
function wmnotify_get_emails()
{
	global $db;
	//
	// Get users data
	//
	$sql = "SELECT user_id, username
	FROM  " . USERS_TABLE;
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
	}
	$users = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$users[$row['user_id']] = $row['username'];
	}
	$db->sql_freeresult($result);
	return $users;
}

/***************************************************************************
 *                             insert_post
 *                         -------------------
 *   Author         :   netclectic - Adrian Cockburn - adrian@netclectic.com
 *                          thanks to wineknow for the suggestion of adding the current_time parameter
 *   Version        :   1.0.7
 *   Created 		: 	Monday, Sept 23, 2002
 *   Last Updated   :   Friday, July 11, 2003
 *
 *   Description    :   This functions is used to insert a post into your phpbb forums. 
 *                      It handles all the related bits like updating post counts, 
 *                      indexing search words, etc.
 *                      The post is inserted for a specific user, so you will have to 
 *                      already have a user setup which you want to use with it.
 *
 *                      If you're using the POST method to input data then you should call stripslashes on
 *                      your subject and message before calling insert_post - see test_insert_post for example.
 *
 *   Parameters     :   $message            - the message that will form the body of the post
 *                      $subject            - the subject of the post
 *                      $forum_id           - the forum the post is to be added to
 *                      $user_id            - the id of the user for the post
 *                      $user_name          - the username of the user for the post
 *                      $user_attach_sig    - should the user's signature be attached to the post
 *
 *   Options Params :   $topic_id           - if topic_id is passed then the post will be 
 *                                              added as a reply to this topic
 *                      $topic_type         - defaults to POST_NORMAL, can also be
 *                                              POST_STICKY, POST_ANNOUNCE or POST_GLOBAL_ANNOUNCE
 *                      $do_notification    - should users be notified of new posts (only valid for replies)
 *                      $notify_user        - should the 'posting' user be signed up for notifications of this topic
 *                      $current_time       - should the current time be used, if not then you should supply a posting time
 *                      $error_die_function - can be used to supply a custom error function.
 *                      $html_on = false    - should html be allowed (parsed) in the post text.
 *                      $bbcode_on = true   - should bbcode be allowed (parsed) in the post text.
 *                      $smilies_on = true  - should smilies be allowed (parsed) in the post text.
 *
 *   Returns        :   If the function succeeds without an error it will return an array containing
 *                      the post id and the topic id of the new post. Any error along the way will result in either
 *                      the normal phpbb message_die function being called or a custom die function determined
 *                      by the $error_die_function parameter.
 ***************************************************************************/
function insert_post(
	$message, 
	$subject, 
	$forum_id, 
	$user_id, 
	$user_name, 
	$user_attach_sig, 
	$current_time = 0, 
	$topic_id = NULL, 
	$topic_type = POST_NORMAL, 
	$do_notification = false, 
	$notify_user = true, 
	$error_die_function = '', 
	$html_on = 0, 
	$bbcode_on = 1, 
	$smilies_on = 1 )
{
	global $db, $board_config, $user_ip;
	// initialise some variables
	$topic_vote = 0; 
	$poll_title = '';
	$poll_options = '';
	$poll_length = '';
	$mode = 'reply'; 
	$bbcode_uid = ($bbcode_on) ? make_bbcode_uid() : ''; 
	$error_die_function = ($error_die_function == '') ? "message_die" : $error_die_function;
	$current_time = ($current_time == 0) ? time() : $current_time;
	// parse the message and the subject (belt & braces :)
	$message = addslashes(unprepare_message($message));
	$message = prepare_message(trim($message), $html_on, $bbcode_on, $smilies_on, $bbcode_uid);
	$subject = addslashes(unprepare_message(trim($subject)));
	$username = addslashes(unprepare_message(trim($user_name)));
	// fix for \" in username - wineknow.com
	$username = str_replace("\\\"","\"", $username);    
	// if this is a new topic then insert the topic details
	if ( $topic_id == 0 )
	{
		$mode = 'newtopic'; 
		$sql = "INSERT INTO " . TOPICS_TABLE . " (topic_title, topic_poster, topic_time, forum_id, topic_status, topic_type, topic_vote) VALUES ('$subject', " . $user_id . ", $current_time, $forum_id, " . TOPIC_UNLOCKED . ", $topic_type, $topic_vote)";
		if ( !$db->sql_query($sql, BEGIN_TRANSACTION) )
		{
			$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
		}
		$topic_id = $db->sql_nextid();
	}
	// insert the post details using the topic id
	$sql = "INSERT INTO " . POSTS_TABLE . " (topic_id, forum_id, poster_id, post_username, post_time, poster_ip, enable_bbcode, enable_html, enable_smilies, enable_sig) VALUES ($topic_id, $forum_id, " . $user_id . ", '$username', $current_time, '$user_ip', $bbcode_on, $html_on, $smilies_on, $user_attach_sig)";
	if ( !$db->sql_query($sql, BEGIN_TRANSACTION) )
	{
		$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
	}
	$post_id = $db->sql_nextid();
	// insert the actual post text for our new post
	$sql = "INSERT INTO " . POSTS_TEXT_TABLE . " (post_id, post_subject, bbcode_uid, post_text) VALUES ($post_id, '$subject', '$bbcode_uid', '$message')";
	if ( !$db->sql_query($sql, BEGIN_TRANSACTION) )
	{
	$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
	}
	// update the post counts etc.
	$newpostsql = ($mode == 'newtopic') ? ',forum_topics = forum_topics + 1' : '';
	$sql = "UPDATE " . FORUMS_TABLE . " SET 
			forum_posts = forum_posts + 1,
			forum_last_post_id = $post_id
			$newpostsql 	
		WHERE forum_id = $forum_id";
	if ( !$db->sql_query($sql, BEGIN_TRANSACTION) )
	{
		$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
	}
	// update the first / last post ids for the topic
	$first_post_sql = ( $mode == 'newtopic' ) ? ", topic_first_post_id = $post_id  " : ' , topic_replies=topic_replies+1'; 
	$sql = "UPDATE " . TOPICS_TABLE . " SET 
			topic_last_post_id = $post_id 
		$first_post_sql
		WHERE topic_id = $topic_id";
	if ( !$db->sql_query($sql, BEGIN_TRANSACTION) )
	{
		$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
	}
	// update the user's post count and commit the transaction
	$sql = "UPDATE " . USERS_TABLE . " SET 
			user_posts = user_posts + 1
		WHERE user_id = $user_id";
	if ( !$db->sql_query($sql, END_TRANSACTION) )
	{
		$error_die_function(GENERAL_ERROR, 'Error in posting', '', __LINE__, __FILE__, $sql);
	}
	// add the search words for our new post
	switch ($board_config['version'])
	{
		case '.0.0' : 
		case '.0.1' : 
		case '.0.2' : 
		case '.0.3' : 
		add_search_words($post_id, stripslashes($message), stripslashes($subject));
		break;
		default :
		add_search_words('', $post_id, stripslashes($message), stripslashes($subject));
		break;
	}
	// do we need to do user notification
	if ( ($mode == 'reply') && $do_notification )
	{
		$post_data = array();
		user_notification($mode, $post_data, $subject, $forum_id, $topic_id, $post_id, $notify_user);
	}
	// if all is well then return the id of our new post
	return array('post_id' => $post_id, 'topic_id' => $topic_id);
}
?>