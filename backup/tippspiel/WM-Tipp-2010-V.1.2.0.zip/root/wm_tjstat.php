<?php
/***************************************************************************
 *                       wm_tjstat.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) B.Funke (buegelfalte)
 *   URL              : http://forum.beehave.de
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Start
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

// Start session management
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
// End session management

include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

if ( !$userdata['session_logged_in'] )
{
   redirect(append_sid("login.$phpEx?redirect=wm_tjstat.$phpEx"));
}

// load config
$wm_config	= array();
$wm_config	= get_wm_config();

$arr_teamlinks = array();
$arr_teamlinks = get_team_links();

// filter disallowed users
if (!empty($wm_config['disallow_users']))
{
	$arr_disallowusers = array();
	$arr_disallowusers = explode(",", $wm_config['disallow_users']);
	if (in_array($userdata['user_id'], $arr_disallowusers))
	{
		message_die(GENERAL_MESSAGE, 'You are not allowed here.', '', '', '', '');
	}
}

If ($userdata['user_level'] == ADMIN && $wm_config['admin_sees_all'] == 1)
{
	$admin_sees_all = true;
}
If ($userdata['user_level'] != ADMIN && $wm_config['user_see_all'] == 1)
{
	$user_see_all = true;
}

If ($admin_sees_all == true || $user_see_all == true)
{
	$show_tipps = true;
}

// Set pagetitle, pageheader and templatefile
$page_title = $lang['wm_title_home'];

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'wm_tjstat.tpl')
);

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}

// get tipps
$int_timefirst = get_first_gametime();

$sql_tips = "SELECT j.*, COUNT(*) AS anzahl FROM " . WM_TJAEGERTIPPS_TABLE . " t, " . WM_TJAEGER_TABLE . " j WHERE t.spielerid = j.spielerid GROUP BY spielerid ORDER BY isking DESC, ";
$sql_tips .= ($int_timefirst > time()) ? " anzahl DESC, Name, Vorname " : " tore DESC, anzahl DESC, Name, Vorname ";
if( !($result_tips = $db->sql_query($sql_tips)) )
{
	message_die(GENERAL_ERROR, 'Could not get player data', '', __LINE__, __FILE__, $sql_tips);
}

$arr_data = array();
$anz_tips = 0;
$anz_goals = 0;

$int_max = 0;
$str_spielerids = "";
while ( $row_tips = $db->sql_fetchrow($result_tips) )
{
	$arr_data[] = $row_tips;
	$anz_tips += $row_tips['anzahl'];
	$anz_goals += $row_tips['tore'];
	$int_max = max($row_tips['anzahl'], $int_max);
	$str_spielerids .= (empty($str_spielerids)) ? $row_tips['spielerid'] : ",".$row_tips['spielerid'];
}

if ($anz_tips == 0)
{
	message_die(GENERAL_MESSAGE, 'Es wurden noch keine Torj�ger-Tipps abgegeben!', '', __LINE__, __FILE__, '');
}

$sql_tips = "SELECT * FROM " . WM_TJAEGER_TABLE . " WHERE isking = 1 AND spielerid NOT IN (" . $str_spielerids . ") ORDER BY Name, Vorname";
if( !($result_tips = $db->sql_query($sql_tips)) )
{
	message_die(GENERAL_ERROR, 'Could not get player data', '', __LINE__, __FILE__, $sql_tips);
}
while ( $row_tips = $db->sql_fetchrow($result_tips) )
{
	array_unshift($arr_data, $row_tips);
}

$int_faktor = round($wm_config['votebarsize']/($int_max/$anz_tips));
foreach($arr_data as $key => $value)
{
	$str_url = '<a href="' . $arr_teamlinks[$value['verein']] . '" target="_blank">' . $value['verein'] . '</a>';
	$str_img = ($value['isking'] == 1) ? '&nbsp;&nbsp;<img src="./images/wm/king.gif" alt="Torsch�tzenk�nig" title="Torsch�tzenk�nig" border="0" />' : '';
	$template->assign_block_vars('playerrow', array(
		'PLAYER_POS'	=> ($key+1),
		'PLAYER_NAME'	=> (($int_timefirst < time()) || $show_tipps) ? $value['Vorname'].' '.$value['Name'].$str_img : $lang['Hidden_email'],
		'PLAYER_TEAM'	=> (($int_timefirst < time()) || $show_tipps) ? $str_url : $lang['Hidden_email'],
		'PLAYER_ANZ'	=> intval($value['anzahl']),
		'PLAYER_GOALS'	=> $value['tore'],
		'PLAYER_IMG'	=> (($int_timefirst < time()) || $show_tipps) ? (!empty($value['link'])) ? '<img src="' . $value['link'] . '" width="30" height="40" alt="' . $value['Vorname'].' '.$value['Name'] . '" />' : '&nbsp;' : '&nbsp;',
		'POLL_IMGWIDTH'	=> ($value['anzahl']/$anz_tips*$int_faktor),
		'POLL_PERCENT'	=> sprintf("%.1d%%", ($value['anzahl']/$anz_tips*100))
		)
	);
}
$db->sql_freeresult($result_tips);

// Assign vars
$template->assign_vars(array(
	'L_WM_WELCOME_TITLE'=> $lang['l_wm_round1_welcome_title'],
	'L_WM_TITLE'		=> 'Torj�ger-Tipps',
	'L_WM_STATS_POS'	=> $lang['l_wm_stats_pos'],
	'L_WM_ROUND1'		=> $lang['l_wm_nav_round1'],
	'L_WM_FINALS'		=> $lang['l_wm_nav_finals'],
	'L_WM_STATS_COMPLETE'		=> $lang['l_wm_nav_stats_complete'],
	'L_WM_FORUM'		=> $lang['l_wm_nav_forum'],
	'L_WM_WINNERSTAT'   => $lang['wm_st_winnertips'],
	'L_WM_TJSTAT'   	=> 'Torj�ger-Tipps',
	'L_WM_MOD'			=> $lang['l_wm_nav_mod'],
	'U_WM_MOD'			=> append_sid("./privmsg.".$phpEx."?mode=post&u=".$admin_id),
	'U_WM_FORUM'		=> append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_id']),
	'U_WM_FINALS'		=> append_sid("./wm_finals.".$phpEx),
	'U_WM_STATS'		=> append_sid("./wm_stats.".$phpEx),
	'U_WM_WINNERSTAT'	=> append_sid("./wm_winnerstat.".$phpEx),
	'U_WM_TJSTAT'		=> append_sid("./wm_tjstat.".$phpEx),
	'U_WM_ROUND1'		=> append_sid("./wm_round1.".$phpEx),
	'U_WM_MORESTATS'	=> append_sid("./wm_morestats.".$phpEx),
	'L_WM_MORESTATS'	=> $lang['l_wmms_title'],
	'L_PLAYER'			=> $lang['l_wm_stats_user'],
	'L_ANZAHL'			=> $lang['wm_st_number'],
	'L_NUMGOALS'		=> $anz_goals,
	'L_NUMTIPPS'      => $anz_tips,
	'POLL_IMG'			=> $images['voting_graphic'][0],
	'POLL_IMGL'			=> $images['voting_graphicl'],
	'POLL_IMGR'			=> $images['voting_graphicr'],
	'U_SHOWLIST'		=> $wm_config['tjlist_link'],
	'L_WM_RULES'		=> $lang['wm_rules'],
	'U_WM_RULES'			=> append_sid("./wm_rules.".$phpEx),
	'L_WM_STATS_SPECIAL'    => $lang['l_wm_nav_stats_special'],
	'U_WM_STATS_SPECIAL'     => append_sid("./wm_stats_special.".$phpEx),
	'L_WM_EXP'           => $lang['l_wm_stats_exp_tj'],
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

$template->assign_block_vars('round1', array());

// Check if tippforum is enabled
if ( $wm_config['wm_forum_id'] != 0 )
{
	$template->assign_block_vars('forum_enabled', array());
	if ( $wm_config['wm_forum_special_id'] != 0 )
	{
		$template->assign_block_vars('forum_enabled.special_enabled', array(
			'L_WM_FORUM_SPECIAL'     => $lang['l_wm_nav_forum_special'],
			'U_WM_FORUM_SPECIAL'     => append_sid("./viewforum.".$phpEx."?f=".$wm_config['wm_forum_special_id']),
			)
		);
	}
}

if ( $wm_config['wm_special'] == 1 )
{
	$template->assign_block_vars('special_enabled', array());
}

if ( $wm_config['stats_general'] == 1 )
{
	$template->assign_block_vars('stats_general', array());
}

if ($wm_config['tjlist_show'])
{
	$template->assign_block_vars('switch_tjlist', array());
}

$template->pparse('body');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

function get_team_links()
{
	global $db;
	$sql = "SELECT team_name, team_link FROM " . WM_TEAMS_TABLE;
	if( !($result = $db->sql_query($sql)) )
	{
		message_die(GENERAL_ERROR, 'Could not get teams data', '', __LINE__, __FILE__, $sql);
	}
	$arr_teamlinks = array();
	while ( $row = $db->sql_fetchrow($result) )
	{
		$arr_teamlinks[$row['team_name']] = $row['team_link'];
	}
	return $arr_teamlinks;
}
?>