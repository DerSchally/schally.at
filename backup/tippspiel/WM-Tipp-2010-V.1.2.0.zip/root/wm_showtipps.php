<?php
/***************************************************************************
 *                       wm_showtipps.php
 *                       -------------------
 *   title              : WM Tipp
 *   version          : 1.2
 *   begin            : 22. Mai 2010
 *   copyright      : (C) 2006 AceVentura
 *   update          : (C) 2010 Matti
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Start
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/functions_wm.'.$phpEx);

$gen_simple_header = TRUE;

// Start session management
$userdata = session_pagestart($user_ip, PAGE_WM);
init_userprefs($userdata);
// End session management

include($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/lang_wm.'.$phpEx);

$int_gameid = min(64,max(1,intval($HTTP_GET_VARS['game_id'])));

// logged in?
if ( !$userdata['session_logged_in'] )
{
	message_die(GENERAL_ERROR, "Please login.");
}

// load config
$wm_config = array();
$wm_config = get_wm_config();

// filter disallowed users
if (!empty($wm_config['disallow_users']))
{
	$arr_disallowusers = array();
	$arr_disallowusers = explode(",", $wm_config['disallow_users']);
	if (in_array($userdata['user_id'], $arr_disallowusers))
	{
		message_die(GENERAL_MESSAGE, 'You are not allowed here.', '', '', '', '');
	}
}

//check if MOD-ID ist set else use admin-id
$sql = "SELECT user_id FROM  " . USERS_TABLE . " order by user_level desc limit 0,1";
if( !($result = $db->sql_query($sql)) )
{
	message_die(GENERAL_ERROR, 'Could not get users data', '', __LINE__, __FILE__, $sql);
}
while ( $row = $db->sql_fetchrow($result) )
{
	$admin = $row['user_id'];
}

if ($wm_config['wm_mod_id'] == 0)
{
	$admin_id = $admin;
}
else
{
	$admin_id = $wm_config['wm_mod_id'];
}
// check auth status
if ( $wm_config['restrict_to'] != 0 && !get_wm_auth() && $userdata['user_level'] != ADMIN && $userdata['user_id'] != $admin_id )
{
	$auth_msg = sprintf($lang['wm_access_denied'], '<a href="' . append_sid("groupcp.$phpEx?g=".$wm_config['restrict_to']) . '" class="gen">', '</a>', '<a href="'.append_sid("index.$phpEx").'" class="gen">', '</a>');
	message_die(GENERAL_MESSAGE, $auth_msg);
}

// check for illegal calls
$str_table = ($int_gameid > 48) ? WM_FINALS_TABLE : WM_GAMES_TABLE;
$sql_match = "SELECT * FROM ".$str_table." WHERE game_id = ".$int_gameid;
if (!($result_match = $db->sql_query($sql_match)))
{
	message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_match);
}
$row_match = $db->sql_fetchrow($result_match);

If ($userdata['user_level'] == ADMIN && $wm_config['admin_sees_all'] == 1)
{
	$admin_sees_all = true;
}
If ($userdata['user_level'] != ADMIN && $wm_config['user_see_all'] == 1)
{
	$user_see_all = true;
}

If ($admin_sees_all == true || $user_see_all == true)
{
	$show_tipps = true;
}

if (($row_match['game_time'] - ($wm_config['end_tipptime'] * 60) > time()) && !$show_tipps)
{
	message_die(GENERAL_MESSAGE, "Tipps sind sichtbar ab ".create_date($board_config['default_dateformat'], $row_match['game_time'], $board_config['board_timezone']));
}
// load results
$results_data = array();
$results_data = get_wm_results();

if ($int_gameid > 48)
{
	$str_winner = ($int_gameid == 63) ? 'final_loser' : 'final_winner';
	$row_match['game_home'] = ($int_gameid > 56) ? $results_data[$row_match['game_home']][$str_winner] : $wm_config[$row_match['game_home']];
	$row_match['game_away'] = ($int_gameid > 56) ? $results_data[$row_match['game_away']][$str_winner] : $wm_config[$row_match['game_away']];
}

// load teams
$wm_teams	= array();
$wm_teams	= get_wm_teams();

// load result
$sql_result = "SELECT * FROM ".WM_RESULTS_TABLE." WHERE result_game = ".$int_gameid;
if (!($result_result = $db->sql_query($sql_result)))
{
	message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_result);
}
$row_result = $db->sql_fetchrow($result_result);

// Generate the page
$page_title = $lang['wm_title_home'];
include($phpbb_root_path . 'includes/page_header.'.$phpEx);
$template->set_filenames(array(
	'body' => 'wm_showtipps.tpl'
	)
);

// get tips
$sql_tips = "SELECT t.tipp_home, t.tipp_away, t.tipp_points, t.tipp_time, u.username FROM ".WM_TIPPS_TABLE." t, ".USERS_TABLE." u WHERE t.tipp_game = ".$int_gameid." AND t.tipp_user = u.user_id
				ORDER BY t.tipp_points DESC, u.username";
if (!($result_tips = $db->sql_query($sql_tips)))
{
	message_die(GENERAL_ERROR, '', '', __LINE__, __FILE__, $sql_tips);
}

$int_count = 0;
$int_winhome = 0;
$int_winaway = 0;
$int_tie = 0;
$int_max = 0;
$int_maxhome = 0;
$int_maxaway = 0;
$int_minhome = 0;
$int_minaway = 0;
$int_sumhome = 0;
$int_sumaway = 0;
$int_sumpoints = 0;
$arr_results = array();
$arr_counthomehigh = array();
$arr_counthomelow = array();
$arr_countawayhigh = array();
$arr_countawaylow = array();
while ($row_tips = $db->sql_fetchrow($result_tips))
{
	$int_count++;
	$int_winhome = ($row_tips['tipp_home'] > $row_tips['tipp_away']) ? $int_winhome + 1 : $int_winhome;
	$int_winaway = ($row_tips['tipp_home'] < $row_tips['tipp_away']) ? $int_winaway + 1 : $int_winaway;
	$int_tie = ($row_tips['tipp_home'] == $row_tips['tipp_away']) ? $int_tie + 1 : $int_tie;
	$int_maxhome = max($int_maxhome, $row_tips['tipp_home']);
	$int_maxaway = max($int_maxaway, $row_tips['tipp_away']);
	$int_minhome = ($int_count == 1) ? $row_tips['tipp_home'] : min($int_minhome, $row_tips['tipp_home']);
	$int_minaway = ($int_count == 1) ? $row_tips['tipp_away'] : min($int_minaway, $row_tips['tipp_away']);
	$int_sumhome += $row_tips['tipp_home'];
	$int_sumaway += $row_tips['tipp_away'];
	$int_sumpoints += $row_tips['tipp_points'];
	$str_result = $row_tips['tipp_home'].':'.$row_tips['tipp_away'];
	$arr_results[$str_result]++;
	$arr_counthomehigh[$row_tips['tipp_home']]++;
	$arr_counthomelow[$row_tips['tipp_home']]++;
	$arr_countawayhigh[$row_tips['tipp_away']]++;
	$arr_countawaylow[$row_tips['tipp_away']]++;
	$template->assign_block_vars('tipps_row', array(
		'ROW_USERNAME' => ($userdata['username'] == $row_tips['username']) ? '<strong>'.$row_tips['username'].'</strong>' : $row_tips['username'],
		'ROW_TIPPTIME' => create_date($board_config['default_dateformat'], $row_tips['tipp_time'], $board_config['board_timezone']),
		'ROW_TIPPHOME' => $row_tips['tipp_home'],
		'ROW_TIPPAWAY' => $row_tips['tipp_away'],
		'ROW_POINTS' => ($wm_config['points_grafical'] == 0) ? $row_tips['tipp_points'] : str_repeat('<img src="./images/wm/euro_cup_small.png" alt="Teamgeist" border="0" />', $row_tips['tipp_points']),
		'ROW_ALIGN' => ($wm_config['points_grafical'] == 0) ? 'center' : 'left'
		)
	);
}

if ($int_count == 0)
{
	message_die(GENERAL_ERROR, "no tips");
}
foreach($arr_results as $value)
{
	$int_max = max($int_max, $value);
}
$int_faktor = round($wm_config['votebarsize']/($int_max/$int_count));
arsort($arr_results);
foreach($arr_results as $key => $value)
{
	// calculate points for tips
	$int_points = 0;
	if (is_array($row_result))
	{
		$arr_tip = explode(":", $key);
		if (($arr_tip[0] == $row_result['result_home']) && ($arr_tip[1] == $row_result['result_away']))
		{
			$int_points = ($wm_config['user_trefferalone'] && $value == 1) ? $wm_config['points_match'] + $wm_config['points_trefferalone'] : $wm_config['points_match']; 
		}
		else if (($arr_tip[0] - $arr_tip[1]) == ($row_result['result_home'] - $row_result['result_away']))
		{
			$int_points = $wm_config['points_tordiff'];
		}
		else if ((($arr_tip[0] > $arr_tip[1]) && ($row_result['result_home'] > $row_result['result_away'])) || (($arr_tip[0] < $arr_tip[1]) && ($row_result['result_home'] < $row_result['result_away'])))
		{
			$int_points = $wm_config['points_tendency'];
		}
	}
	$template->assign_block_vars('stats_row', array(
		'ROW_TIPP' => $key,
		'ROW_NUMBER' => $value,
		'ROW_POINTS' => ($wm_config['points_grafical'] == 0) ? $int_points : str_repeat('<img src="./images/wm/euro_cup_small.png" alt="Teamgeist" border="0" />', $int_points),
		'ROW_ALIGN' => ($wm_config['points_grafical'] == 0) ? 'center' : 'left',
		'POLL_IMG' => $images['voting_graphic'][0],
		'POLL_IMGL'	=> $images['voting_graphicl'],
		'POLL_IMGR'	=> $images['voting_graphicr'],
		'POLL_IMGWIDTH' => ($int_count > 0) ? ($value/$int_count*$int_faktor) : 0,
		'POLL_PERCENT' => sprintf("%.1d%%", ($value/$int_count*100))
		)
	);
}

$int_faktortips = round($wm_config['votebarsize']/(max($int_winhome, $int_winaway, $int_tie)/$int_count));

// assign variables
$template->assign_vars(array(
	'L_MATCH' => $lang['l_wm_round1_event'],
	'L_DETAILS' => '<a href="'.$row_match['game_loclink'].'" target="_blank">'.$row_match['game_loc'].'</a> - '.create_date($board_config['default_dateformat'], $row_match['game_time'], $board_config['board_timezone']),
	'L_FLAGHOME' => $wm_teams[$row_match['game_home']]['team_img'],
	'L_TEAMHOME' => '<a href="'.$wm_teams[$row_match['game_home']]['team_link'].'" target="_blank">'.$wm_teams[$row_match['game_home']]['team_name'].'</a>',
	'L_TEAMNAMEHOME' => $wm_teams[$row_match['game_home']]['team_name'],
	'L_FLAGAWAY' => $wm_teams[$row_match['game_away']]['team_img'],
	'L_TEAMAWAY' => '<a href="'.$wm_teams[$row_match['game_away']]['team_link'].'" target="_blank">'.$wm_teams[$row_match['game_away']]['team_name'].'</a>',
	'L_TEAMNAMEAWAY' => $wm_teams[$row_match['game_away']]['team_name'],
	'L_POINTS' => $lang['l_wm_table_points'],
	'L_TIPPTIME' => $lang['l_wm_tipp_time'],
	'L_TIPP' => $lang['l_wm_round1_tipp'],
	'L_TIPPS' => $lang['l_wm_stats_made_tipps'],
	'L_USER' => $lang['Username'],
	'L_WINNER' => $lang['wm_st_winner'],
	'L_TIE' => $lang['wm_st_tie'],
	'L_MAX' => $lang['wm_st_max'],
	'L_MIN' => $lang['wm_st_min'],
	'L_AVERAGE' => $lang['wm_st_average'],
	'L_NUMBER' => $lang['wm_st_number'],
	'L_VPOINTS' => $lang['wm_st_vpoints'],
	'L_PPUSER' => $lang['wm_st_ppuser'],
	'N_RESULTHOME' => $row_result['result_home'],
	'N_RESULTAWAY' => $row_result['result_away'],
	'N_WINHOME' => $int_winhome,
	'N_WINHOMEPCT' => ($int_count > 0) ? sprintf("%.1d%%", ($int_winhome/$int_count*100)) : 0,
	'N_WINAWAY' => $int_winaway,
	'N_WINAWAYPCT' => ($int_count > 0) ? sprintf("%.1d%%", ($int_winaway/$int_count*100)) : 0,
	'N_WINTIE' => $int_tie,
	'N_WINTIEPCT' => ($int_count > 0) ? sprintf("%.1d%%", ($int_tie/$int_count*100)) : 0,
	'POLL_IMG' => $images['voting_graphic'][0],
	'POLL_IMGL'	=> $images['voting_graphicl'],
	'POLL_IMGR'	=> $images['voting_graphicr'],
	'POLL_IMGWIDTHOME' => ($int_count > 0) ? ($int_winhome/$int_count*$int_faktortips) : 0,
	'POLL_IMGWIDTAWAY' => ($int_count > 0) ? ($int_winaway/$int_count*$int_faktortips) : 0,
	'POLL_IMGWIDTHTIE' => ($int_count > 0) ? ($int_tie/$int_count*$int_faktortips) : 0,
	'N_TIPPS' => $int_count,
	'N_MAXHOME' => $int_maxhome,
	'N_MAXAWAY' => $int_maxaway,
	'N_MINHOME' => $int_minhome,
	'N_MINAWAY' => $int_minaway,
	'N_HOMEHIGH' => $arr_counthomehigh[$int_maxhome],
	'N_HOMELOW' => $arr_counthomelow[$int_minhome],
	'N_AWAYHIGH' => $arr_countawayhigh[$int_maxaway],
	'N_AWAYLOW' => $arr_countawaylow[$int_minaway],
	'N_AVERAGE' => ($int_count > 0) ? round($int_sumhome/$int_count).':'.round($int_sumaway/$int_count) : '-',
	'N_VPOINTS' => $int_sumpoints,
	'N_PPUSER' => ($int_count > 0) ? round($int_sumpoints/$int_count,1) : 0,
	"L_COPYRIGHT" => $lang['tipp_copyright']
	)
);

if (is_array($row_result))
{
	 $template->assign_block_vars('switch_result', array());
}
$template->pparse('body');
?>