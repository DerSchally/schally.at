<?php
/***************************************************************************
 *                               db_install.php
 *                            -------------------
 *   for MOD           : WM Webtipp
 *   version              : 1.2
 *   begin                : 22. Mai 2010
 *
 *
 ***************************************************************************/

/***************************************************************************
 *                               db_install.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_config`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_config` (
  `config_name` varchar(255) NOT NULL default '',
  `config_value` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_winner', '20')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_match', '5')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_tordiff', '3')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_tendency', '2')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_grafical', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('user_see_all', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wa', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wb', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wc', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wd', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('we', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wf', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wg', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wh', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('ra', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rb', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rc', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rd', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('re', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rf', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rg', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('rh', '')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('restrict_to', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wm_forum_id', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_trefferalone', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('user_trefferalone', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('points_winnerscorer', '8')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('admin_sees_all', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wm_special', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_last_ranklist', '1262300400')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wm_mod_id', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wm_forum_special_id', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_general', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_bestloser', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_rainbowcup', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_goals', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_correct_goals', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_wrong_tips', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_worst_tips', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_tips_voted', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_tips_voted2', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_tips_voted_user', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_results', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_most_results2', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_points_tipp', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_points_nowrong_tipp', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('stats_ranksize', '15')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_ranksize', '50')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_finalstart', '20100626')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_reply_topic', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_post_rankmsg', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_write_mails', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_reply_special_topic', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_code', 'deincode')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('tjlist_show', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('tjlist_link', 'http://www.kicker.de/news/fussball/wm/spielplan/weltmeisterschaft/2010/1/torjaeger-der-saison.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('votebarsize', '200')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('show_allteams', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('delete_tipps', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('notify_last_reminder', '1262300400')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('end_tipptime', '60')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('finals_result', '1')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('wmtipp_delay', '0')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_config` (`config_name`, `config_value`) VALUES('user_see_set', '0')";

$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_finals`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_finals` (
  `game_id` mediumint(8) NOT NULL auto_increment,
  `game_time` int(11) NOT NULL default '0',
  `game_home` varchar(8) NOT NULL default '',
  `game_away` varchar(8) NOT NULL default '',
  `game_loc` varchar(255) NOT NULL default '',
  `game_loclink` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(49, 1277560800, 'wa', 'rb', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(50, 1277577000, 'wc', 'rd', 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(51, 1277647200, 'wd', 'rc', 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(52, 1277663400, 'wb', 'ra', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(53, 1277733600, 'we', 'rf', 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(54, 1277749800, 'wg', 'rh', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(55, 1277820000, 'wf', 're', 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(56, 1277836200, 'wh', 'rg', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(57, 1278079200, '53', '54', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(58, 1278095400, '49', '50', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(59, 1278165600, '51', '52', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(60, 1278181800, '55', '56', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(61, 1278441000, '57', '58', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(62, 1278527400, '59', '60', 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(63, 1278786600, '61', '62', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(64, 1278873000, '61', '62', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_games`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_games` (
  `game_id` mediumint(8) NOT NULL auto_increment,
  `game_time` int(11) NOT NULL default '0',
  `game_home` mediumint(8) NOT NULL default '0',
  `game_away` mediumint(8) NOT NULL default '0',
  `game_loc` varchar(255) NOT NULL default '',
  `game_loclink` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(1, 1276264800, 1, 2, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(2, 1276281000, 3, 4, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(3, 1276713000, 1, 3, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(4, 1276799400, 4, 2, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(5, 1277215200, 2, 3, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(6, 1277215200, 4, 1, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(7, 1276351200, 5, 6, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(8, 1276342200, 7, 8, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(9, 1276783200, 8, 6, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(10, 1276774200, 5, 7, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(11, 1277231400, 6, 7, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(12, 1277231400, 8, 5, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(13, 1276367400, 9, 10, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(14, 1276428600, 11, 12, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(15, 1276869600, 12, 10, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(16, 1276885800, 9, 11, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(17, 1277301600, 12, 9, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(18, 1277301600, 10, 11, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(19, 1276453800, 13, 14, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(20, 1276437600, 15, 16, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(21, 1276860600, 13, 15, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(22, 1276956000, 16, 14, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(23, 1277317800, 16, 13, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(24, 1277317800, 14, 15, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(25, 1276515000, 17, 18, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(26, 1276524000, 19, 20, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(27, 1276947000, 17, 19, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(28, 1276972200, 20, 18, 'Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(29, 1277404200, 18, 19, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(30, 1277404200, 20, 17, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(31, 1276540200, 21, 22, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(32, 1276601400, 23, 24, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(33, 1277033400, 24, 22, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(34, 1277042400, 21, 23, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(35, 1277388000, 24, 21, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(36, 1277388000, 22, 23, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(37, 1276610400, 27, 28, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(38, 1276626600, 25, 26, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(39, 1277058600, 25, 27, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(40, 1277119800, 28, 26, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(41, 1277474400, 28, 25, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(42, 1277474400, 26, 27, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(43, 1276687800, 31, 32, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(44, 1276696800, 29, 30, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(45, 1277128800, 32, 30, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(46, 1277145000, 29, 31, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(47, 1277490600, 32, 29, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html')";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES(48, 1277490600, 30, 31, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_results`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_results` (
  `result_id` mediumint(8) NOT NULL auto_increment,
  `result_game` mediumint(8) NOT NULL default '0',
  `result_home` mediumint(8) NOT NULL default '0',
  `result_away` mediumint(8) NOT NULL default '0',
  `final_winner` mediumint(8) NOT NULL default '0',
  `final_loser` mediumint(8) NOT NULL default '0',
  `result_status` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`result_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_teams`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_teams` (
  `team_id` mediumint(8) NOT NULL auto_increment,
  `team_name` varchar(255) NOT NULL default '',
  `team_img` varchar(255) NOT NULL default '',
  `team_link` varchar(255) NOT NULL default '',
  `team_group` varchar(5) NOT NULL default '',
  `team_points` mediumint(4) NOT NULL default '0',
  `team_goals` mediumint(8) NOT NULL default '0',
  `team_gotgoals` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`team_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(1, 'S�dafrika', 'Suedafrika.gif', 'http://de.fifa.com/worldcup/teams/team=43883/index.html', 'A', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(2, 'Mexiko', 'Mexiko.gif', 'http://de.fifa.com/worldcup/teams/team=43911/index.html', 'A', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(3, 'Uruguay', 'Uruguay.gif', 'http://de.fifa.com/worldcup/teams/team=43930/index.html', 'A', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(4, 'Frankreich', 'Frankreich.gif', 'http://de.fifa.com/worldcup/teams/team=43946/index.html', 'A', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(5, 'Argentinien', 'Argentinien.gif', 'http://de.fifa.com/worldcup/teams/team=43922/index.html', 'B', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(6, 'Nigeria', 'Nigeria.gif', 'http://de.fifa.com/worldcup/teams/team=43876/index.html', 'B', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(7, 'S�dkorea', 'Suedkorea.gif', 'http://de.fifa.com/worldcup/teams/team=43822/index.html', 'B', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(8, 'Griechenland', 'Griechenland.gif', 'http://de.fifa.com/worldcup/teams/team=43949/index.html', 'B', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(9, 'England', 'England.gif', 'http://de.fifa.com/worldcup/teams/team=43942/index.html', 'C', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(10, 'USA', 'USA.gif', 'http://de.fifa.com/worldcup/teams/team=43930/index.html', 'C', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(11, 'Algerien', 'Algerien.gif', 'http://de.fifa.com/worldcup/teams/team=43843/index.html', 'C', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(12, 'Slowenien', 'Slowenien.gif', 'http://de.fifa.com/worldcup/teams/team=43968/index.html', 'C', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(13, 'Deutschland', 'Deutschland.gif', 'http://de.fifa.com/worldcup/teams/team=43948/index.html', 'D', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(14, 'Australien', 'Australien.gif', 'http://de.fifa.com/worldcup/teams/team=43976/index.html', 'D', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(15, 'Serbien', 'Serbien.gif', 'http://de.fifa.com/worldcup/teams/team=1902465/index.html', 'D', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(16, 'Ghana', 'Ghana.gif', 'http://de.fifa.com/worldcup/teams/team=43860/index.html', 'D', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(17, 'Niederlande', 'Niederlande.gif', 'http://de.fifa.com/worldcup/teams/team=43960/index.html', 'E', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(18, 'D�nemark', 'Daenemark.gif', 'http://de.fifa.com/worldcup/teams/team=43941/index.html', 'E', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(19, 'Japan', 'Japan.gif', 'http://de.fifa.com/worldcup/teams/team=43819/index.html', 'E', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(20, 'Kamerun', 'Kamerun.gif', 'http://de.fifa.com/worldcup/teams/team=43849/index.html', 'E', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(21, 'Italien', 'Italien.gif', 'http://de.fifa.com/worldcup/teams/team=43954/index.html', 'F', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(22, 'Paraguay', 'Paraguay.gif', 'http://de.fifa.com/worldcup/teams/team=43928/index.html', 'F', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(23, 'Neuseeland', 'Neuseeland.gif', 'http://de.fifa.com/worldcup/teams/team=43978/index.html', 'F', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(24, 'Slowakei', 'Slowakei.gif', 'http://de.fifa.com/worldcup/teams/team=44002/index.html', 'F', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(25, 'Brasilien', 'Brasilien.gif', 'http://de.fifa.com/worldcup/teams/team=43924/index.html', 'G', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(26, 'Nordkorea', 'Nordkorea.gif', 'http://de.fifa.com/worldcup/teams/team=43821/index.html', 'G', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(27, 'Elfenbeink�ste', 'Elfenbein.gif', 'http://de.fifa.com/worldcup/teams/team=43854/index.html', 'G', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(28, 'Portugal', 'Portugal.gif', 'http://de.fifa.com/worldcup/teams/team=43963/index.html', 'G', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(29, 'Spanien', 'Spanien.gif', 'http://de.fifa.com/worldcup/teams/team=43969/index.html', 'H', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(30, 'Schweiz', 'Schweiz.gif', 'http://de.fifa.com/worldcup/teams/team=43971/index.html', 'H', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(31, 'Honduras', 'Honduras.gif', 'http://de.fifa.com/worldcup/teams/team=43909/index.html', 'H', 0, 0, 0)";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES(32, 'Chile', 'Chile.gif', 'http://de.fifa.com/worldcup/teams/team=43925/index.html', 'H', 0, 0, 0)";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_tipps`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_tipps` (
  `tipp_id` mediumint(8) NOT NULL auto_increment,
  `tipp_game` mediumint(8) NOT NULL default '0',
  `game_time` int(11) NOT NULL default '0',
  `tipp_time` int(11) NOT NULL default '0',
  `tipp_user` mediumint(8) NOT NULL default '0',
  `tipp_home` mediumint(8) NOT NULL default '0',
  `tipp_away` mediumint(8) NOT NULL default '0',
  `tipp_points` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`tipp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=133";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_torschuetzen`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_torschuetzen` (
  `spielerid` int(2) NOT NULL auto_increment,
  `Name` varchar(30) NOT NULL default '',
  `Vorname` varchar(30) default NULL,
  `verein` varchar(30) NOT NULL default '0',
  `tore` int(2) NOT NULL default '0',
  `link` varchar(250) default 'http://www.ets-arena.de/forum/userpix/2_nopic_1.jpg',
  `isking` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`spielerid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_torschuetzen_user`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_torschuetzen_user` (
  `userid` varchar(4) NOT NULL default '0',
  `spielerid` int(4) NOT NULL default '0',
  `berechnet` int(2) NOT NULL default '0',
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$sql[] = "ALTER TABLE `" . $table_prefix . "users` 
ADD `wm_special` INT(2) NOT NULL default '0'";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfull</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">Installation is now finished. Please be sure to delete this file now.<br />If you have run into any errors, please visit the <a href="http://www.phpbbsupport.co.uk" target="_phpbbsupport">phpBBSupport.co.uk</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Have a nice day</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>