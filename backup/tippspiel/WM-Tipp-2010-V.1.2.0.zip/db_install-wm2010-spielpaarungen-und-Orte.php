<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_finals`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_finals` (
  `game_id` mediumint(8) NOT NULL auto_increment,
  `game_time` int(11) NOT NULL default '0',
  `game_home` varchar(8) NOT NULL default '',
  `game_away` varchar(8) NOT NULL default '',
  `game_loc` varchar(255) NOT NULL default '',
  `game_loclink` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES
(49, 1277560800, 'wa', 'rb', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(50, 1277577000, 'wc', 'rd', 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(51, 1277647200, 'wd', 'rc', 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html'),
(52, 1277663400, 'wb', 'ra', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(53, 1277733600, 'we', 'rf', 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(54, 1277749800, 'wg', 'rh', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(55, 1277820000, 'wf', 're', 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(56, 1277836200, 'wh', 'rg', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(57, 1278079200, '53', '54', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(58, 1278095400, '49', '50', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(59, 1278165600, '51', '52', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(60, 1278181800, '55', '56', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(61, 1278441000, '57', '58', 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(62, 1278527400, '59', '60', 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(63, 1278786600, '61', '62', 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(64, 1278873000, '61', '62', 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html')";
$sql[] = "DROP TABLE IF EXISTS `" . $table_prefix . "wm_games`";
$sql[] = "CREATE TABLE `" . $table_prefix . "wm_games` (
  `game_id` mediumint(8) NOT NULL auto_increment,
  `game_time` int(11) NOT NULL default '0',
  `game_home` mediumint(8) NOT NULL default '0',
  `game_away` mediumint(8) NOT NULL default '0',
  `game_loc` varchar(255) NOT NULL default '',
  `game_loclink` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51";
$sql[] = "INSERT INTO `" . $table_prefix . "wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES
(1, 1276264800, 1, 2, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(2, 1276281000, 3, 4, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(3, 1276713000, 1, 3, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(4, 1276799400, 4, 2, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html'),
(5, 1277215200, 2, 3, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(6, 1277215200, 4, 1, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html'),
(7, 1276351200, 5, 6, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(8, 1276342200, 7, 8, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(9, 1276783200, 8, 6, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html'),
(10, 1276774200, 5, 7, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(11, 1277231400, 6, 7, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(12, 1277231400, 8, 5, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html'),
(13, 1276367400, 9, 10, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(14, 1276428600, 11, 12, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html'),
(15, 1276869600, 12, 10, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(16, 1276885800, 9, 11, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(17, 1277301600, 12, 9, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(18, 1277301600, 10, 11, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(19, 1276453800, 13, 14, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(20, 1276437600, 15, 16, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(21, 1276860600, 13, 15, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(22, 1276956000, 16, 14, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(23, 1277317800, 16, 13, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(24, 1277317800, 14, 15, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html'),
(25, 1276515000, 17, 18, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(26, 1276524000, 19, 20, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html'),
(27, 1276947000, 17, 19, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(28, 1276972200, 20, 18, 'Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(29, 1277404200, 18, 19, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(30, 1277404200, 20, 17, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(31, 1276540200, 21, 22, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(32, 1276601400, 23, 24, 'Rustenburg', 'http://de.fifa.com/worldcup/destination/cities/city=40341/index.html'),
(33, 1277033400, 24, 22, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html'),
(34, 1277042400, 21, 23, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html'),
(35, 1277388000, 24, 21, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(36, 1277388000, 22, 23, 'Polokwane', 'http://de.fifa.com/worldcup/destination/cities/city=49568/index.html'),
(37, 1276610400, 27, 28, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(38, 1276626600, 25, 26, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(39, 1277058600, 25, 27, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(40, 1277119800, 28, 26, 'Green Point in Kapstadt', 'http://de.fifa.com/worldcup/destination/cities/city=19224/index.html'),
(41, 1277474400, 28, 25, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(42, 1277474400, 26, 27, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html'),
(43, 1276687800, 31, 32, 'Nelspruit', 'http://de.fifa.com/worldcup/destination/cities/city=57127/index.html'),
(44, 1276696800, 29, 30, 'Durban', 'http://de.fifa.com/worldcup/destination/cities/city=11915/index.html'),
(45, 1277128800, 32, 30, 'Port Elizabeth', 'http://de.fifa.com/worldcup/destination/cities/city=4961/index.html'),
(46, 1277145000, 29, 31, 'Johannesburg', 'http://de.fifa.com/worldcup/destination/cities/city=1268/index.html'),
(47, 1277490600, 32, 29, 'Loftus Versfeld in Pretoria', 'http://de.fifa.com/worldcup/destination/cities/city=20178/index.html'),
(48, 1277490600, 30, 31, 'Bloemfontein', 'http://de.fifa.com/worldcup/destination/cities/city=21556/index.html')";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfull</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">Installation is now finished. Please be sure to delete this file now.<br />If you have run into any errors, please visit the <a href="http://www.phpbbsupport.co.uk" target="_phpbbsupport">phpBBSupport.co.uk</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Have a nice day</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>