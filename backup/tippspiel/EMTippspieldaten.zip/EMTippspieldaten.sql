CREATE TABLE IF NOT EXISTS `phpbb_wm_finals` (
  `game_id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `game_time` int(11) NOT NULL DEFAULT '0',
  `game_home` varchar(8) NOT NULL DEFAULT '',
  `game_away` varchar(8) NOT NULL DEFAULT '',
  `game_loc` varchar(255) NOT NULL DEFAULT '',
  `game_loclink` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

INSERT INTO `phpbb_wm_finals` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES
(25, 1340304300, 'wa', 'rb', 'Warschau (POL)', ''),
(26, 1340390700, 'wb', 'ra', 'Gdansk (POL)', ''),
(27, 1340477100, 'wc', 'rd', 'Donezk (UKR)', ''),
(28, 1340563500, 'wd', 'rc', 'Kyiw (UKR)', ''),
(29, 1340822700, '25', '27', 'Donezk (UKR)', ''),
(30, 1340909100, '26', '28', 'Warschau (POL)', ''),
(31, 1341168300, '29', '30', 'Kyiw (UKR)', ''),
(32, 1341168300, '29', '30', 'Kyiw (UKR)', '');

CREATE TABLE IF NOT EXISTS `phpbb_wm_games` (
  `game_id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `game_time` int(11) NOT NULL DEFAULT '0',
  `game_home` mediumint(8) NOT NULL DEFAULT '0',
  `game_away` mediumint(8) NOT NULL DEFAULT '0',
  `game_loc` varchar(255) NOT NULL DEFAULT '',
  `game_loclink` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`game_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

INSERT INTO `phpbb_wm_games` (`game_id`, `game_time`, `game_home`, `game_away`, `game_loc`, `game_loclink`) VALUES
(1, 1339171200, 1, 2, 'Warschau (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3149/index.html'),
(2, 1339181100, 3, 4, 'Wroclaw (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3187/index.html'),
(3, 1339257600, 5, 6, 'Charkiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1943/index.html'),
(4, 1339267500, 7, 8, 'Lwiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=2152/index.html'),
(5, 1339344000, 9, 10, 'Gdansk (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=1677/index.html'),
(6, 1339353900, 11, 12, 'Poznan (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=2556/index.html'),
(7, 1339430400, 13, 14, 'Donezk (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1525/index.html'),
(8, 1339440300, 15, 16, 'Kyiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1947/index.html'),
(9, 1339516800, 2, 4, 'Wroclaw (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3187/index.html'),
(10, 1339526700, 1, 3, 'Warschau (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3149/index.html'),
(11, 1339603200, 6, 8, 'Lwiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=2152/index.html'),
(12, 1339613100, 5, 7, 'Charkiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1943/index.html'),
(13, 1339689600, 10, 12, 'Poznan (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=2556/index.html'),
(14, 1339699500, 9, 11, 'Gdansk (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=1677/index.html'),
(15, 1339785900, 16, 14, 'Kyiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1947/index.html'),
(16, 1339776000, 15, 13, 'Donezk (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1525/index.html'),
(17, 1339872300, 2, 3, 'Warschau (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3149/index.html'),
(18, 1339862400, 4, 1, 'Wroclaw (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=3187/index.html'),
(19, 1339958700, 8, 5, 'Charkiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1943/index.html'),
(20, 1339958700, 6, 7, 'Lwiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=2152/index.html'),
(21, 1340045100, 12, 9, 'Gdansk (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=1677/index.html'),
(22, 1340045100, 10, 11, 'Poznan (POL)', 'http://de.uefa.com/uefaeuro/hostcountries/poland/city=2556/index.html'),
(23, 1340131500, 16, 13, 'Kyiw (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1947/index.html'),
(24, 1340131500, 14, 15, 'Donezk (UKR)', 'http://de.uefa.com/uefaeuro/hostcountries/ukraine/city=1525/index.html');

CREATE TABLE IF NOT EXISTS `phpbb_wm_teams` (
  `team_id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(255) NOT NULL DEFAULT '',
  `team_img` varchar(255) NOT NULL DEFAULT '',
  `team_link` varchar(255) NOT NULL DEFAULT '',
  `team_group` varchar(5) NOT NULL DEFAULT '',
  `team_points` mediumint(4) NOT NULL DEFAULT '0',
  `team_goals` mediumint(8) NOT NULL DEFAULT '0',
  `team_gotgoals` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`team_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

INSERT INTO `phpbb_wm_teams` (`team_id`, `team_name`, `team_img`, `team_link`, `team_group`, `team_points`, `team_goals`, `team_gotgoals`) VALUES
(1, 'Polen', 'polen.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=109/index.html', 'A', 0, 0, 0),
(2, 'Griechenland', 'griechenland.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=49/index.html', 'A', 0, 0, 0),
(3, 'Russland', 'russland.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=57451/index.html', 'A', 0, 0, 0),
(4, 'Tschechische Republik', 'tschechien.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=58837/index.html', 'A', 0, 0, 0),
(5, 'Niederlande', 'niederlande.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=95/index.html', 'B', 0, 0, 0),
(6, 'Dänemark', 'daenemark.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=35/index.html', 'B', 0, 0, 0),
(7, 'Deutschland', 'deutschland.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=47/index.html', 'B', 0, 0, 0),
(8, 'Portugal', 'portugal.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=110/index.html', 'B', 0, 0, 0),
(9, 'Spanien', 'spanien.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=122/index.html', 'C', 0, 0, 0),
(10, 'Italien', 'italien.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=66/index.html', 'C', 0, 0, 0),
(11, 'Republik Irland', 'republikirland.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=64/index.html', 'C', 0, 0, 0),
(12, 'Kroatien', 'kroatien.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=56370/index.html', 'C', 0, 0, 0),
(13, 'Frankreich', 'frankreich.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=43/index.html', 'D', 0, 0, 0),
(14, 'England', 'grossbritanien.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=39/index.html', 'D', 0, 0, 0),
(15, 'Ukraine', 'ukraine.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=57166/index.html', 'D', 0, 0, 0),
(16, 'Schweden', 'schweden.gif', 'http://de.uefa.com/uefaeuro/season=2012/teams/team=127/index.html', 'D', 0, 0, 0);